---
name: calendario-editorial
description: Monta o calendário editorial do escritório — distribui pautas, pilares e formatos em dias/semanas/meses, equilibra tipos de conteúdo (autoridade/educação/conexão/conversão), integra datas sazonais e garante cadência sustentável. Use SEMPRE que o advogado mencionar: "calendário editorial", "planejar posts", "agenda de conteúdo", "o que postar cada dia", "cronograma de publicação", "distribuir pautas", "organizar posts da semana", "planejar mês de conteúdo", "calendário de redes sociais", "programar conteúdo", "grade editorial". Consolida banco de pautas + linha editorial em cronograma publicável.
---

# Calendário Editorial

Esta skill transforma **banco de pautas + linha editorial** em **calendário publicável** (semanal, quinzenal ou mensal), com dia, formato, pilar e pauta definidos para cada post.

## Por que isso importa

Escritório sem calendário posta por impulso. Posta muito numa semana, somem na outra. Mistura pilares sem critério. Perde oportunidade sazonal. Calendário = cérebro de produção.

## Pré-requisitos

Leia antes (na ordem):
- `linha-editorial.md` — pilares, formatos, proporções
- `banco-pautas.md` — pautas curadas e priorizadas
- `personas.md` — horários de maior atividade
- `produto-nicho.md` — eventuais sazonalidades do nicho

Sem linha editorial + banco de pautas, o calendário fica arbitrário.

## Workflow

### Bloco 1 — Definir horizonte e frequência

Pergunte ao advogado:
- **Horizonte:** 1 semana / 2 semanas / 1 mês / 1 trimestre?
- **Frequência:** quantos posts por semana por formato?
- **Dias de publicação:** quais dias? Segunda a sexta? Fim de semana também?
- **Horários:** baseados no comportamento da persona primária

**Default sugerido para escritório que está começando:**
- Horizonte: 1 mês
- Frequência: 3 posts/semana (1 carrossel + 1 reels + 1 stories educativo)
- Dias: seg/qua/sex

### Bloco 2 — Mapear datas sazonais e gatilhos

Datas fixas que sempre rendem conteúdo:
- **Fiscais:** prazo IR (março), 13º (nov/dez)
- **Previdenciárias:** aniversário do MEI, reajuste benefícios (jan)
- **Familiares:** dia das mães, pais, crianças
- **Institucionais:** Dia do Advogado (11/ago)
- **Específicas do nicho:** [lista com advogado]

Datas variáveis do próprio escritório:
- Aniversário do escritório
- Lançamento de novo serviço
- Webinar / live / evento próprio

### Bloco 3 — Distribuir pautas por semana

Para cada semana do horizonte:

1. **Escolher 1 pauta urgente** do banco (se houver) → vai pro primeiro dia
2. **Escolher 1-2 pautas evergreen** para os outros dias
3. **Verificar proporção** (autoridade/educação/conexão/conversão):
   - A semana tem pelo menos 1 post educativo?
   - A semana tem 1 post de autoridade?
   - Faz tempo que não posta conversão? Encaixa 1
   - Faz tempo que não posta conexão/bastidor? Encaixa 1
4. **Distribuir pelos formatos** da linha editorial

### Bloco 4 — Amarrar com datas sazonais

Para cada pauta sazonal mapeada no Bloco 2:
- Agende produção **com 2 semanas de antecedência** (mínimo)
- Publique **na janela certa** (ex: IR → entre março e abril)

### Bloco 5 — Revisar proporção final

Checklist do calendário fechado:
- [ ] Proporção de tipos respeitou a linha editorial (±5%)?
- [ ] Pilares temáticos estão equilibrados (nenhum ficou de fora)?
- [ ] Cadência é sustentável pro tempo de produção disponível?
- [ ] Datas sazonais estão cobertas?
- [ ] Tem folga pra pauta urgente de última hora?

## Gerando o entregável

Use `references/template-calendario-editorial.md`. Gere `calendario-editorial.md` com:
- Grade visual semana a semana (dia / formato / pilar / pauta / CTA)
- Lista de pautas sazonais programadas
- Indicadores de proporção (% por tipo, % por pilar)
- Observações de produção

## Cadência de atualização

- **Semanal (15 min):** ajustes pontuais, plug de pautas urgentes
- **Mensal (1h):** revisão completa, replan do mês seguinte
- **Trimestral (2h):** revisão de pilares e proporções junto com linha editorial

## Integração com skills downstream

O `calendario-editorial.md` alimenta:
- `criar-copy` (cada post vira briefing de copy)
- `roteiros-video` (cada reels/vídeo vira briefing de roteiro)
- `criar-criativos` (cada post vira briefing de design)
- `qa-performance` (compara publicado vs. planejado)

## Armadilha comum

**Calendário rígido demais.** Jurídico muda toda semana — nova súmula, decisão do STF, mudança legislativa. Reserve **20% dos slots do mês como flexíveis** pra encaixar pauta quente. Calendário 100% engessado vira sofrimento.
