# Calendário Editorial — [Nome do Escritório]

> Documento gerado pela skill `calendario-editorial`.
> Horizonte: [semana / quinzena / mês / trimestre]
> Período: [data início] a [data fim]
> Última atualização: [data]

---

## Parâmetros

- **Frequência:** [N] posts/semana
- **Formatos ativos:** [carrossel, reels, stories, artigo, ...]
- **Dias de publicação:** [seg/qua/sex / etc.]
- **Horários:** [horário por formato]

---

## Grade Semanal

### Semana 1 ([data] a [data])

| Dia | Formato | Pilar | Pauta | Tipo | CTA | Status |
|---|---|---|---|---|---|---|
| Seg | Carrossel | [Pilar X] | [título] | Educação | [ação] | 🟡 produção |
| Qua | Reels 60s | [Pilar Y] | [título] | Autoridade | [ação] | 🟡 produção |
| Sex | Stories | [Pilar Z] | [título] | Conexão | [ação] | ⚪ planejado |

**Legenda status:** ⚪ planejado | 🟡 em produção | 🟢 pronto | ✅ publicado | ⏸️ pausado

---

### Semana 2 ([data] a [data])
[repetir grade]

---

### Semana 3
[repetir]

---

### Semana 4
[repetir]

---

## Pautas Sazonais Programadas

| Data | Pauta | Formato | Antecedência produção | Status |
|---|---|---|---|---|
| [data] | [ex: IR 2026 - últimos dias] | Carrossel | 14 dias antes | ⚪ |
| [data] | [ex: Dia das Mães] | Reels emocional | 10 dias antes | ⚪ |

---

## Indicadores de Proporção (verificação)

### Por tipo de conteúdo (alvo × real)

| Tipo | % alvo | % no calendário |
|---|---|---|
| Autoridade | 25% | __% |
| Educação | 35% | __% |
| Conexão | 20% | __% |
| Conversão | 20% | __% |

### Por pilar temático

| Pilar | Posts no período |
|---|---|
| Pilar 1 | [N] |
| Pilar 2 | [N] |
| Pilar 3 | [N] |
| Pilar 4 | [N] |
| Pilar 5 | [N] |

**Atenção:** se algum pilar ficar com 0 posts no mês, replanejar.

---

## Slots Flexíveis (20%)

Reservar [N] slots sem pauta fixa para encaixar pauta urgente que surgir na curadoria semanal.

| Slot | Dia | Formato | Status |
|---|---|---|---|
| 1 | [dia] | [formato] | 🆓 livre |
| 2 | [dia] | [formato] | 🆓 livre |

---

## Observações de Produção

- Responsável pelo carrossel: [nome]
- Responsável pelo reels: [nome]
- Designer: [nome]
- Prazo interno: peça pronta **2 dias antes** da publicação
