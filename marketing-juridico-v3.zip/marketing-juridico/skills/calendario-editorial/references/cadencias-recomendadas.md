# Cadências Recomendadas por Perfil de Escritório

Não existe cadência ideal universal. Existe cadência **viável** pro tempo do escritório.

---

## Perfil 1 — Escritório solo, começando do zero

**Realidade:** 1 advogado(a) + ajudante ocasional. 5-8h/semana pra marketing.

**Cadência sugerida:** 3 posts/semana
- 1 carrossel educativo (2-3h produção)
- 1 reels 60s (2-3h produção)
- 1 stories de bastidor/autoridade (30 min)

**Proporção:**
- 50% educação / 30% autoridade / 20% conexão
- Conversão: 1x a cada 2 semanas (não sobrecarregar)

**Armadilha:** tentar postar todo dia. Queima em 45 dias.

---

## Perfil 2 — Escritório pequeno com estrutura de marketing

**Realidade:** 2-4 advogados + freelancer de marketing/designer. 15-20h/semana em conteúdo.

**Cadência sugerida:** 5 posts/semana + stories diário
- 2 carrosséis educativos
- 2 reels (1 de 30s + 1 de 60-90s)
- 1 artigo de blog (SEO)
- Stories: 1-3 por dia

**Proporção:**
- 35% educação / 25% autoridade / 20% conexão / 20% conversão

**Adicional:** 1 live mensal + 1 email de newsletter mensal

---

## Perfil 3 — Escritório médio/grande com time dedicado

**Realidade:** 5+ advogados, time de marketing interno (social media + designer + videomaker). 40h+/semana.

**Cadência sugerida:** 7-10 posts/semana
- 3 carrosséis
- 3-4 reels
- 2 artigos de blog
- 1 vídeo YouTube longo (semanal ou quinzenal)
- Stories diários estruturados

**Proporção:**
- 30% educação / 25% autoridade / 20% conexão / 25% conversão

**Adicional:** live quinzenal, email semanal, LinkedIn ativo (B2B)

---

## Perfil 4 — Foco SEO/autoridade longo prazo

**Realidade:** escritório que prioriza Google e YouTube sobre redes sociais.

**Cadência sugerida:**
- 2 artigos de blog/semana (3000+ palavras, SEO)
- 1 vídeo YouTube longo/semana
- 2 reels derivados (cortes do vídeo longo)
- Stories 2x/semana

**Proporção:**
- 60% educação / 30% autoridade / 10% conexão
- Conversão: estratégia SEO (landing page + CTA no artigo)

---

## Perfil 5 — Foco relacionamento (B2B, tributário, empresarial)

**Realidade:** poucos clientes de ticket alto, decisão racional longa.

**Cadência sugerida:**
- 1 artigo técnico/semana
- 1 post LinkedIn/semana
- 1 email newsletter quinzenal
- 1 webinar/mês
- Instagram secundário (2x/semana)

**Proporção:**
- 50% autoridade / 30% educação / 20% conversão
- Conexão: pouco relevante (B2B)

---

## Sinais de cadência errada

**Sintoma:** "não consigo postar essa semana"
→ Cadência está além do tempo real. Reduzir.

**Sintoma:** "fiquei sem ideia do que postar"
→ Banco de pautas está vazio. Parar de postar, curar pautas.

**Sintoma:** "posto mas ninguém interage"
→ Não é cadência, é posicionamento ou formato errado. Voltar pra persona + linha editorial.

**Sintoma:** "postei muito na semana X e sumi na Y"
→ Produção por impulso, não por calendário. Reinstalar o cronograma.

---

## Regra de ouro

**Menos post com qualidade > mais post sem qualidade.**

Escritório que posta 3x/semana por 12 meses vence escritório que posta 7x/semana por 2 meses e some.
