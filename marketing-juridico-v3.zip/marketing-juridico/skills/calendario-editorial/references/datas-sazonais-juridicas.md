# Datas Sazonais para Escritórios de Advocacia

Calendário de gatilhos que rendem conteúdo todo ano. Use pra antecipar produção.

---

## Janeiro

- **01/01** — Reajuste do salário mínimo (afeta benefícios previdenciários, pensão alimentícia, cálculos trabalhistas)
- **01/01** — Novos tetos INSS e reajuste de benefícios
- Início da folha de salários → pauta sobre reajuste salarial, data-base
- Férias escolares → guarda compartilhada, convivência parental

---

## Fevereiro

- Carnaval → acidentes de trânsito, direitos do consumidor em viagens
- Volta às aulas → pensão alimentícia (material escolar, matrícula)
- IR 2026 começa a ser discutido

---

## Março

- **Prazo IR Pessoa Física** (entrega em março/abril) → tributário
- **08/03 Dia da Mulher** → direitos da mulher (assédio, Maria da Penha, divisão de bens)
- Auditoria de aposentadorias (INSS costuma rever benefícios)

---

## Abril

- **Fim do prazo IR** → tributário emergencial
- Páscoa → direitos do consumidor (golpes, produtos)
- **01/05 Dia do Trabalhador** (prep em abril) → trabalhista

---

## Maio

- **01/05 Dia do Trabalhador** → direitos trabalhistas
- **Dia das Mães (2º domingo)** → família, pensão, guarda
- Período de dissídios coletivos em vários setores

---

## Junho

- Férias escolares de julho se aproximando → guarda, viagens de menores
- Festa junina → acidentes, consumidor

---

## Julho

- Férias escolares → guarda compartilhada, autorização de viagem
- Meio do ano fiscal → revisão tributária

---

## Agosto

- **11/08 Dia do Advogado**
- **Dia dos Pais (2º domingo)** → família, paternidade socioafetiva
- Volta às aulas (segundo semestre)

---

## Setembro

- **07/09 Feriado** → rotina, acidentes
- Aniversário de muitos escritórios (começo do segundo ciclo)

---

## Outubro

- **12/10 Dia das Crianças** → guarda, alienação parental, direitos da criança
- **Dia do Servidor Público (28/10)** → servidor público, aposentadoria especial

---

## Novembro

- **Black Friday** → consumidor (golpes, propaganda enganosa)
- **15/11 Consciência Negra** → direitos, discriminação
- 13º salário → trabalhista e previdenciário

---

## Dezembro

- **13º salário** → trabalhista
- Festas → consumidor, trânsito, família (divórcio pós-festas é recorrente)
- Balanço anual → recuperação de créditos, planejamento 2027
- Férias coletivas → trabalhista

---

## Datas específicas por nicho

### Previdenciário
- **Janeiro:** reajuste de benefícios
- **Todo mês:** aniversariante do mês (revisão, planejamento)
- **Dez/Jan:** 13º salário do aposentado

### Trabalhista
- **Maio:** Dia do Trabalhador
- **Data-base de cada categoria** (varia)
- **Dezembro:** 13º, férias coletivas

### Tributário
- **Março-Abril:** IR PF
- **Julho:** IR PJ (mid-year)
- **Dezembro:** planejamento ano seguinte

### Família
- **Maio:** Dia das Mães
- **Agosto:** Dia dos Pais
- **Outubro:** Dia das Crianças
- **Pós-festas (jan, dez):** picos de divórcio

### Consumidor
- **Black Friday** (novembro)
- **Natal** (dezembro)
- **Dia do Consumidor** (15/03)

---

## Regra de antecedência

| Tipo de pauta | Antecedência de produção |
|---|---|
| Data fixa anual | 14-21 dias antes |
| Data móvel (mães, pais, páscoa) | 10-14 dias antes |
| Evento reativo (decisão, lei nova) | 48-72h |
| Evento próprio (live, lançamento) | 21-30 dias antes |

Produção atrasada = post publicado depois da onda passar. Planeje com folga.
