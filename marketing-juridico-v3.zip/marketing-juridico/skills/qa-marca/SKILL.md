---
name: qa-marca
description: Audita peças de marketing jurídico contra o manual de marca do escritório — tom de voz, identidade visual, vocabulário, padrões editoriais. Verifica se a peça "tem a cara do escritório" antes de publicar. Use quando o advogado mencionar: "revisar marca", "está na nossa voz", "parece do escritório", "conferir identidade", "QA de marca", "padronização", "isso tá na nossa linha", "consistência de marca", "brand check". Roda DEPOIS de qa-etico-oab.
---

# QA de Marca — Consistência de Voz e Visual

Depois que a peça passou no QA ético, ela precisa passar no QA de marca. Peça conforme OAB mas fora da voz do escritório = ruído de marca.

## Por que existe

Escritórios com marketing inconsistente:
- Perdem reconhecimento de marca
- Parecem "terceirizados" ou "genéricos"
- Não acumulam autoridade ao longo do tempo
- Cliente não identifica quem está falando

## Pré-requisitos

**Crítico:** Manual de marca existente (`manual-marca.md`). Sem manual, essa skill não funciona — rodar `manual-marca` antes.

Leia:
- `manual-marca.md` — tom, voz, vocabulário, visual
- `personas.md` — para quem falamos
- Peça a auditar

## Workflow

### Bloco 1 — Tom de voz

Conferir contra manual:
- [ ] Tom está alinhado (ex: próximo-profissional, não acadêmico)
- [ ] Formalidade adequada (você/senhor)
- [ ] Ritmo das frases respeitado (curtas vs longas)
- [ ] Nível de informalidade calibrado
- [ ] Humor/emoção na dose certa

### Bloco 2 — Vocabulário

- [ ] Termos preferidos do escritório usados
- [ ] Termos proibidos ausentes
- [ ] Juridiquês desnecessário traduzido
- [ ] Siglas explicadas na primeira menção
- [ ] Gírias/regionalismos consistentes com manual

### Bloco 3 — Identidade visual (se peça visual)

- [ ] Paleta de cores correta
- [ ] Tipografia oficial
- [ ] Logo aplicado corretamente
- [ ] Fotografia dentro do estilo (iluminação, enquadramento)
- [ ] Templates do escritório respeitados
- [ ] Sem elementos dissonantes

### Bloco 4 — Estrutura editorial

- [ ] Abertura/gancho no padrão do escritório
- [ ] Assinatura/encerramento padronizada
- [ ] CTA dentro do vocabulário de marca
- [ ] Hashtags alinhadas (se social)

### Bloco 5 — Posicionamento

- [ ] Reforça pilares de conteúdo definidos
- [ ] Não contradiz posicionamento público
- [ ] Alinhado ao nicho/área de atuação
- [ ] Consistente com peças anteriores

### Bloco 6 — Gerar relatório

Use `references/template-relatorio-qa-marca.md`. Formato:
- **Status:** ALINHADO / AJUSTAR / FORA DA MARCA
- **Desvios encontrados:** [lista]
- **Reescrita sugerida:** [lado a lado]

## Integração com skills

**Roda DEPOIS de:** `qa-etico-oab`
**Alimenta:** fluxo de publicação

## Armadilhas comuns

1. **Copiar tom de concorrente.** Cada peça deve reforçar identidade própria, não imitar.
2. **Mudar tom entre canais.** Escritório no Instagram "descolado" e no site "rebuscado" = marca fragmentada.
3. **Ceder ao autor.** Cada advogado escrevendo do jeito dele = marca não existe.
4. **Ignorar manual "só dessa vez".** Erosão silenciosa.
