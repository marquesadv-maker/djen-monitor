# Dimensões de Consistência de Marca

Checklist estendido de onde marca jurídica costuma "escorregar".

---

## 1. Voz escrita

- Pessoa gramatical (eu / nós / o escritório)
- Tratamento do leitor (você / senhor / vocês)
- Tamanho médio de frase
- Uso de perguntas retóricas (sim/não)
- Uso de exemplos concretos vs abstratos

## 2. Vocabulário técnico

- Lista de termos preferidos
- Lista de termos banidos
- Regras de tradução de juridiquês
- Siglas: explica na primeira vez? sempre?

## 3. Estrutura

- Padrão de abertura
- Padrão de fechamento
- Uso de listas vs parágrafos
- Tamanho de posts/legendas/roteiros

## 4. Visual

- Cores primária/secundária/apoio
- Hierarquia tipográfica
- Estilo fotográfico
- Uso de ícones/ilustrações
- Assinatura visual do escritório

## 5. Pessoas em cena

- Quais advogados aparecem
- Como são referidos (Dr./Dra./nome)
- Estilo de foto (formal/casual)
- Enquadramento padrão

## 6. Canais

- Instagram: [padrão]
- LinkedIn: [padrão]
- YouTube: [padrão]
- Site/blog: [padrão]
- WhatsApp: [padrão]
- Email: [padrão]

## 7. Posicionamento

- Temas prioritários (pilares)
- Temas evitados
- Posição em polêmicas públicas
- Política sobre decisões recentes

---

## Sinais de marca inconsistente

1. Post no Instagram em tom casual + site em tom acadêmico
2. Advogado A escreve formal, Advogado B escreve casual, sem identidade comum
3. Mudança de paleta a cada 3 meses
4. Cada peça parece feita por fornecedor diferente
5. Cliente não reconhece a marca em peças sem logo
