# Relatório QA de Marca

> Gerado pela skill `qa-marca`.
> Data: [...]
> Peça analisada: [...]
> Manual de marca usado: versão [X]

---

## Status

**[ ALINHADO / AJUSTAR / FORA DA MARCA ]**

---

## 1. Tom de voz

| Dimensão | Padrão (manual) | Peça | Status |
|---|---|---|---|
| Formalidade | [...] | [...] | [...] |
| Proximidade | [...] | [...] | [...] |
| Ritmo | [...] | [...] | [...] |

---

## 2. Vocabulário

**Termos corretos usados:** [lista]
**Termos proibidos encontrados:** [lista]
**Juridiquês não traduzido:** [lista]

---

## 3. Visual (se aplicável)

| Item | Padrão | Peça | Status |
|---|---|---|---|
| Paleta | [...] | [...] | [...] |
| Tipografia | [...] | [...] | [...] |
| Logo | [...] | [...] | [...] |

---

## 4. Desvios principais

1. [desvio 1]
2. [desvio 2]

---

## 5. Reescrita sugerida

| Original | Corrigido |
|---|---|
| [...] | [...] |

---

## 6. Próxima ação

- [ ] Ajustar e revalidar
- [ ] Publicar
- [ ] Atualizar manual de marca (se desvio for sistemático)
