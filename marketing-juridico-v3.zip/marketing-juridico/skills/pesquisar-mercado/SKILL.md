---
name: pesquisar-mercado
description: Mapeia a concorrência e identifica oportunidades de posicionamento para o escritório de advocacia no nicho escolhido. Analisa concorrentes diretos (mesma região + mesmo nicho), saturação de palavras-chave, gaps de conteúdo, padrões de comunicação da concorrência e brechas para diferenciação. Use SEMPRE que o advogado mencionar: "pesquisar mercado", "analisar concorrência", "quem são meus concorrentes", "como estão anunciando", "onde meu concorrente aparece", "tá saturado meu nicho", "como me diferenciar", "tem espaço pra mim nesse mercado", "benchmark de escritórios", "o que os concorrentes postam", "análise competitiva", "saturação de mercado", "gap de oportunidade", "vale a pena entrar nesse nicho". Também acione depois de `definir-produto-nicho` + `mapear-personas` para validar se o nicho escolhido tem espaço competitivo saudável.
---

# Pesquisar Mercado e Concorrência Jurídica

Esta skill mapeia **como a concorrência do escritório está se comunicando** no nicho escolhido — e encontra as brechas que o escritório pode ocupar.

## Por que isso importa

Escolher nicho sem olhar concorrência é como entrar numa briga vendado. Pode dar certo, mas quase sempre o escritório descobre tarde que:
- O nicho tá saturado de conteúdo (nenhum post seu é visto)
- Os concorrentes compram as palavras-chave que ele precisaria
- Existe um **ângulo** que ninguém ocupa — e esse era o ouro

A pesquisa de mercado **não é pra copiar o concorrente**. É pra encontrar o espaço vazio que ninguém tá preenchendo.

## Pré-requisito

Antes de rodar esta skill, precisa ter:
- `produto-nicho.md` (gerado por `definir-produto-nicho`) — define o nicho que vai ser analisado
- `personas.md` (gerado por `mapear-personas`) — define o cliente que está sendo disputado

Se qualquer um não existir, **pare** e recomende rodar primeiro.

## Workflow

A pesquisa tem **3 frentes**. O advogado não precisa responder nada — ele fornece o contexto (região + nicho) e a skill guia a análise, idealmente com WebSearch/WebFetch quando disponível.

### Frente 1 — Mapeamento de concorrentes diretos

Identifique 5-8 escritórios que competem **pelo mesmo cliente**, no mesmo nicho, na mesma região (ou na mesma praça digital).

Fontes para identificar:
- Google: "advogado [nicho] [cidade]"
- Instagram: busca por hashtags do nicho + região
- Google Maps: escritórios locais no nicho
- YouTube: advogados do nicho com canal ativo
- Ads no Meta/Google: concorrentes pagando por palavras-chave do nicho

Para cada concorrente, levante:
- Nome do escritório / advogado
- Site e redes principais
- Presença digital estimada (número de seguidores, frequência de post)
- Tom de voz (formal / informal / didático / agressivo)
- Tipo de conteúdo principal (vídeo / carrossel / artigo)
- Oferta aparente (consulta gratuita? whatsapp direto? funil?)
- Proposta de valor declarada (o que eles dizem que fazem de diferente)

Use `references/fontes-pesquisa-mercado.md` para checklist de onde buscar.

### Frente 2 — Análise de saturação de palavras-chave

Para as 10-15 buscas que você levantou em `personas.md` (Bloco 3), faça análise rápida:

Para cada busca:
1. Digite no Google (ou use ferramenta de SEO)
2. Conte quantos resultados são de **escritórios de advocacia** nos 10 primeiros
3. Classifique a saturação:
   - **Alta** (7+ escritórios): difícil competir organicamente, precisa diferenciar muito ou pagar anúncio
   - **Média** (3-6 escritórios): há espaço, mas exige consistência
   - **Baixa** (0-2 escritórios): oportunidade clara — conteúdo novo rankeia rápido

Priorize as buscas de **saturação baixa e média** como foco inicial de conteúdo do escritório.

### Frente 3 — Identificação de gaps

Agora vem a parte de descobrir **o espaço vazio**.

Com base nos concorrentes mapeados (Frente 1), identifique:

**Gap de tom:** Todos falam formal? Oportunidade pra falar informal (e vice-versa).
**Gap de formato:** Todos fazem carrossel? Oportunidade pra vídeo (e vice-versa).
**Gap de tema:** Todos falam de X e Y? Oportunidade em Z (mesmo nicho, ângulo lateral).
**Gap de público:** Todos falam pra empresário? Oportunidade pra falar pra pessoa física.
**Gap de profundidade:** Todos fazem conteúdo raso de atração? Oportunidade pra autoridade técnica (ou ao contrário).
**Gap geográfico:** Todos são de capital? Oportunidade pra atender interior.
**Gap temporal:** Ninguém posta no fim de semana? Oportunidade ali.

Use `references/ganchos-diferenciacao.md` para 8 estratégias específicas de posicionamento diferenciado.

## Gerando o entregável

Use `references/template-pesquisa-mercado.md`. Gere `pesquisa-mercado.md` com:
- Concorrentes diretos (mini-fichas)
- Mapa de saturação das palavras-chave
- Gaps identificados
- **Recomendação estratégica**: onde o escritório deve se posicionar

## Recomendação estratégica (seção mais importante)

Não entregue só dados. Termine com uma **recomendação direta** do tipo:

> "A concorrência no nicho de previdenciário em Belo Horizonte é alta em volume, mas todo mundo fala do mesmo jeito: formal, técnico, usando juridiquês, foco em 'ganhar do INSS'. O escritório da Dra. Marina tem espaço claro ocupando o ângulo **acolhedor-didático**, falando como um filho explica pros pais. Gap forte: **planejamento previdenciário antes da aposentadoria** (só 1 concorrente fala disso). Recomendação: posicionar como 'advogada que explica antes de você precisar' — conteúdo educacional preventivo, tom acolhedor, público filhos-de-pré-aposentados."

Essa recomendação vai alimentar `editorial-linha` e toda a estratégia de conteúdo depois.

## Quando NÃO tem WebSearch/WebFetch disponível

Oriente o advogado a fazer a pesquisa **ele mesmo** com guia estruturado:
- Entregue o roteiro do `fontes-pesquisa-mercado.md`
- Peça que ele colete dados brutos (prints, links) e traga de volta
- Você estrutura e analisa

Em qualquer caso, mantenha o rigor da análise — concorrência mapeada mal leva a decisão de posicionamento errada.

## Próximos passos

Depois de `pesquisa-mercado.md` pronto, a skill natural é `editorial-linha` (construir a linha editorial usando o gap identificado como ângulo).
