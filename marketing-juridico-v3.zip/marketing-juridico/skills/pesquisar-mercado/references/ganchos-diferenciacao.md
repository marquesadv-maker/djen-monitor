# 8 Estratégias de Diferenciação para Escritórios de Advocacia

Quando o mercado está saturado, imitar é suicídio. Estas são 8 estratégias testadas para encontrar posicionamento único no mesmo nicho.

---

## 1. Diferenciação por Ângulo (ângulo lateral do mesmo tema)

**Lógica:** todos falam do tema X. Fale do **subtema** que ninguém cobre.

**Exemplo — Previdenciário:**
- Todos falam de "como dar entrada no INSS"
- Gap: **"planejamento previdenciário ANTES de você se aposentar"**
- Público: filhos que cuidam dos pais (45-55 anos) — decisor B2C inesperado

**Exemplo — Família:**
- Todos falam de divórcio
- Gap: **"o que fazer ANTES de casar pra não virar divórcio"** (pacto antenupcial, planejamento)

---

## 2. Diferenciação por Persona (público que o nicho esqueceu)

**Lógica:** todos falam com o cliente padrão. Fale com o **cliente secundário** invisível.

**Exemplo — Trabalhista:**
- Todos falam pro empregado CLT demitido
- Gap: **motorista de app, entregador, trabalhador uberizado**

**Exemplo — Consumidor:**
- Todos falam com o consumidor que quer indenização
- Gap: **pessoa idosa que foi enganada por televenda**

---

## 3. Diferenciação por Tom (contracultura do mercado)

**Lógica:** se todo mundo é formal, seja informal. Se todo mundo é agressivo, seja acolhedor.

**Exemplo — Bancário:**
- Todos usam tom combativo ("processe o banco!")
- Gap: **tom educacional calmo ("entenda seus direitos antes de agir")**

**Exemplo — Criminal:**
- Todos usam tom dramático/sensacionalista
- Gap: **tom técnico-tranquilo, sem espetáculo**

---

## 4. Diferenciação por Formato (canal ou mídia)

**Lógica:** onde o concorrente **não está**.

**Exemplo:**
- Todos fazem Reels → **aposte em carrossel didático longo**
- Todos fazem Instagram → **aposte em YouTube Shorts**
- Todos fazem post escrito → **aposte em vídeo-responde-comentário**
- Ninguém faz podcast → **aposte em podcast** (nicho de autoridade B2B)

---

## 5. Diferenciação por Profundidade

**Lógica:** se todos são rasos, seja profundo. Se todos são profundos, seja acessível.

**Exemplo — Tributário:**
- Todos fazem conteúdo raso ("dicas para pagar menos imposto")
- Gap: **conteúdo de autoridade técnica denso** para decisor B2B que precisa confiar

**Exemplo — Família:**
- Todos fazem conteúdo técnico complexo
- Gap: **conteúdo ultra-acessível** para leigo em crise emocional

---

## 6. Diferenciação por Jornada do Cliente

**Lógica:** a maioria fala com cliente **pronto pra contratar**. Fale com cliente em **fase anterior**.

**Exemplo — Divórcio:**
- Todos falam com quem já decidiu se separar
- Gap: **conteúdo para quem ainda está decidindo** (terapia de casal vs. divórcio, sinais)

**Exemplo — Previdenciário:**
- Todos falam com quem já recebeu negativa
- Gap: **conteúdo preventivo** — "organize seus documentos antes de pedir"

---

## 7. Diferenciação por Especialização Extrema

**Lógica:** em vez de "advogado previdenciário", seja **"advogado do BPC-LOAS"**.

**Exemplo:**
- "Advogado previdenciário" → 50.000 concorrentes
- "Advogada de BPC-LOAS" → 500 concorrentes
- "Advogada de BPC-LOAS para pessoas com deficiência" → 50 concorrentes → vitória

**Risco:** pode limitar volume. Balanço ideal: nicho principal ultra-específico + nicho secundário ampliando catchment.

---

## 8. Diferenciação por Narrativa Pessoal

**Lógica:** o advogado traz uma história pessoal que nenhum concorrente pode copiar.

**Exemplos:**
- Advogada trabalhista que **foi vítima de assédio moral** e virou especialista na área
- Advogado previdenciário **filho de aposentado** que passou pela experiência com o pai
- Advogada de família que **é mediadora familiar certificada** (além de advogada)

Narrativa autêntica cria conexão emocional impossível de imitar.

**Atenção OAB:** narrativa pessoal é permitida desde que não vire prova de resultado ou exposição de cliente.

---

## Como escolher qual gancho usar

Depois de fazer a análise de mercado, responda:

1. **Qual gap é maior?** (onde há menos concorrência)
2. **Qual gancho o advogado consegue sustentar por 2 anos?** (alinhado ao fit)
3. **Qual gancho o cliente-persona valoriza mais?** (o advogado acha legal o gancho, mas o cliente quer isso?)

Recomende **1 gancho principal + 1 secundário** no `pesquisa-mercado.md`. Evite misturar 3+ — dilui posicionamento.

---

## Armadilha: "vou fazer tudo diferente"

Tentar se diferenciar em **tom + formato + público + ângulo** ao mesmo tempo confunde o mercado. Posicionamento claro = **uma diferença marcante** + entrega excelente no resto. Escolha UMA diferença principal e capriche.
