# Pesquisa de Mercado — [Nome do Escritório]

> Documento gerado pela skill `pesquisar-mercado`.
> Nicho analisado: [nicho primário do escritório]
> Região analisada: [cidade/estado]
> Data: [data]

---

## 1. Resumo Executivo

**Nível de saturação do mercado:** [baixa / média / alta]
**Oportunidade principal identificada:** [frase curta com o gap mais claro]
**Risco principal identificado:** [frase curta com o maior obstáculo]

---

## 2. Concorrentes Diretos

### Concorrente 1 — [Nome]
- **Site/redes:** [links]
- **Presença digital:** [seguidores / frequência de post]
- **Tom de voz:** [formal / informal / didático / combativo / acolhedor]
- **Formato principal:** [vídeo / carrossel / artigo / reels]
- **Oferta aparente:** [consulta grátis / whatsapp / funil / etc.]
- **Proposta de valor declarada:** [o que eles dizem que fazem diferente]
- **Pontos fortes:** [o que fazem bem]
- **Pontos fracos:** [brecha que deixam aberta]

### Concorrente 2 — [Nome]
[Repetir estrutura]

### Concorrente 3 — [Nome]
[Repetir estrutura]

[Continuar até 5-8 concorrentes]

---

## 3. Análise de Saturação — Palavras-Chave

| Busca | Saturação | Escritórios no top 10 | Oportunidade |
|---|---|---|---|
| [busca 1] | [baixa/média/alta] | [N] | [sim / não / parcial] |
| [busca 2] | | | |
| [busca 3] | | | |
| [busca 4] | | | |
| [busca 5] | | | |

**Buscas-oportunidade (saturação baixa/média):**
- [busca X]
- [busca Y]
- [busca Z]

**Buscas-competição (saturação alta, exige anúncio pago ou conteúdo muito diferenciado):**
- [busca A]
- [busca B]

---

## 4. Gaps Identificados

### Gap de Tom
[Descrição: como todos falam vs. onde há espaço]

### Gap de Formato
[Descrição]

### Gap de Tema / Ângulo
[Descrição — qual assunto do nicho ninguém está cobrindo]

### Gap de Público
[Descrição]

### Gap de Profundidade
[Descrição]

### Gap Geográfico
[Descrição]

### Gap Temporal (horários/dias)
[Descrição]

---

## 5. Recomendação Estratégica

**Posicionamento sugerido para o escritório:**

[Frase clara no estilo: "A [cliente] que [situação] está precisando de [promessa] que ninguém está entregando. O escritório deve ocupar [ângulo X] porque [justificativa]."]

**Ângulo de comunicação:**

[Descreva o tom + formato + tema + público ideal para o escritório]

**Primeiros 5 temas de conteúdo recomendados:**

1. [tema]
2. [tema]
3. [tema]
4. [tema]
5. [tema]

**Alerta estratégico:**

[Qualquer risco ou atenção — ex: "concorrente X está escalando anúncio no nicho, vai ficar mais caro em 6 meses"]

---

## 6. Próximos Passos

- [ ] Rodar `editorial-linha` usando esta recomendação como base
- [ ] Validar os 5 temas iniciais com o advogado antes de começar produção
- [ ] Reavaliar este documento em 6 meses (mercado muda)
