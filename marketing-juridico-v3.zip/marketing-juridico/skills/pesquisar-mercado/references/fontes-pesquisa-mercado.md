# Fontes de Pesquisa de Mercado Jurídico

Checklist de onde buscar dados de concorrência para advogados brasileiros.

---

## Fontes gratuitas (essenciais)

### Google — busca orgânica
- **O que fazer:** digite "advogado [nicho] [cidade]" e anote os 10 primeiros resultados
- **O que observar:** quem aparece, com que site, qual oferta na meta description
- **Variações importantes:**
  - "melhor advogado [nicho] [cidade]" (saturada, mas mostra quem tá investindo)
  - "[problema da persona] [cidade]" (ex: "fui demitido sem justa causa belo horizonte")
  - "[nicho] perto de mim"

### Google Ads (parte paga, visível)
- **O que fazer:** pesquise termos do nicho e veja quais escritórios estão **pagando** por eles
- **Sinal forte:** escritório que aparece em anúncio pago está investindo R$ reais → sério concorrente
- **Ferramenta gratuita de apoio:** Google Trends para ver sazonalidade do nicho

### Google Maps
- **O que fazer:** busque "[nicho] de advocacia" na sua região
- **O que observar:** escritórios físicos, avaliações (notas e comentários), fotos
- **Insight:** comentários revelam dor e objeção real dos clientes

### Instagram
- **O que fazer:** busque hashtags do nicho + localização + perfis
  - #advogadoprevidenciario + #bh
  - #direitodefamilia + #saopaulo
- **O que observar:** engajamento real (curtidas, comentários), frequência de post, tom, formato dominante (reels? carrossel?)
- **Ferramenta de apoio:** guarde 5 perfis principais e observe por 1 semana

### YouTube
- **O que fazer:** busque termos do nicho
- **O que observar:** quem tem canal ativo no nicho, quantas inscrições, qual abordagem (cases? dúvidas frequentes? entrevistas?)
- **Insight:** advogado com YouTube ativo é concorrente sério em autoridade

### TikTok
- **O que fazer:** busque "advogado [nicho]"
- **O que observar:** nicho crescente em tráfego orgânico jurídico, tom mais leve
- **Atenção:** muitos vídeos de TikTok jurídico flertam com o limite OAB — observe o que funciona **e** o que é eticamente seguro

### LinkedIn
- **O que fazer:** busque advogados do nicho na região
- **O que observar:** quem está ativo, que tipo de artigo publica, se atende B2B
- **Uso específico:** nichos B2B (tributário, empresarial, startup, societário)

---

## Fontes pagas (opcionais, mas poderosas)

### Semrush / Ahrefs / Ubersuggest
- Mostra quem ranqueia para cada palavra-chave
- Mostra volume de busca mensal
- Mostra dificuldade de ranking
- **Versão gratuita limitada serve** para pesquisa pontual

### Meta Ads Library (grátis)
- **Link:** facebook.com/ads/library
- **O que fazer:** busque o nome do concorrente ou a fanpage
- **O que vê:** todos os anúncios que ele está rodando agora, com criativo e copy completos
- **Uso:** espia direto o que o concorrente está testando em ads

### SimilarWeb (grátis básico)
- Mostra tráfego estimado do site do concorrente
- Mostra de onde vem o tráfego (orgânico, pago, social, direto)

---

## Fontes setoriais jurídicas

### CNJ — Conselho Nacional de Justiça
- Dados de demanda por tipo de ação
- **Link:** cnj.jus.br/datajud

### OAB estadual
- Quantidade de advogados por nicho na região (em alguns estados)

### Google Trends (grátis)
- Sazonalidade de buscas
- Crescimento/declínio de interesse em termos jurídicos
- Variação regional

---

## Roteiro mínimo (30-40 minutos)

Se o tempo é curto, faça pelo menos isso:

1. **Google search** para os 3 termos principais da persona (10 min)
2. **Instagram search** por hashtag do nicho + cidade (10 min)
3. **Meta Ads Library** para 2-3 concorrentes identificados (10 min)
4. **Google Maps** do seu nicho na cidade (5 min)
5. **Anote tudo** no `pesquisa-mercado.md` em tempo real (contínuo)

---

## O que NÃO fazer

- ❌ Copiar a linha editorial do concorrente
- ❌ Usar criativo do concorrente (plágio, risco OAB)
- ❌ Mencionar concorrente por nome em conteúdo próprio
- ❌ Guerra de preço aberta
- ❌ Fazer "apenas o que o maior do nicho faz" — quem é segundo copiando não vence

O objetivo é **encontrar o que falta no mercado**, não imitar quem já está.
