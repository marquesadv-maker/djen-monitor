# Especificações Técnicas por Plataforma

Dimensões, pesos e safe zones atualizados. Use pra dimensionar criativos.

---

## Instagram

| Formato | Dimensão | Proporção | Obs |
|---|---|---|---|
| Feed quadrado | 1080×1080 | 1:1 | Básico, menos prioridade do algoritmo |
| Feed retrato | 1080×1350 | 4:5 | **Preferido** — ocupa mais tela |
| Stories | 1080×1920 | 9:16 | Safe zone: 250px topo + 310px base |
| Reels (capa/cover) | 1080×1920 | 9:16 | Ícone do user cobre canto inferior esq |
| Carrossel | 1080×1350 | 4:5 | Mesma dimensão para todos os slides |

**Peso máximo:** 30MB por imagem
**Fonte mínima:** 28pt em stories, 22pt em feed

---

## TikTok

| Formato | Dimensão | Obs |
|---|---|---|
| Vídeo vertical | 1080×1920 | 9:16 |
| Capa do vídeo | 1080×1920 | Trecho do vídeo ou imagem estática |

**Safe zone:** evitar texto nos 150px inferiores (ícones do app)

---

## YouTube

| Formato | Dimensão | Obs |
|---|---|---|
| Thumbnail | 1280×720 | 16:9, ≤2MB |
| Shorts thumbnail | 1080×1920 | 9:16 |
| Banner canal | 2560×1440 | Safe zone 1546×423 |
| Foto perfil | 800×800 | Circular |

**Texto no thumbnail:** máximo 5-7 palavras, fonte 80-120pt

---

## LinkedIn

| Formato | Dimensão | Obs |
|---|---|---|
| Post single image | 1200×1200 | 1:1 ou 1200×628 (1.9:1) |
| Post vídeo | 1080×1080 ou 1080×1920 | Quadrado performa melhor |
| Carrossel (documento PDF) | 1080×1080 ou 1080×1350 | PDF multi-página |
| Capa empresa | 1128×191 | Cuidado com crop mobile |
| Capa pessoal | 1584×396 | Safe zone central |

**Texto no post:** mais formal, usar pouco emoji

---

## Facebook

| Formato | Dimensão | Obs |
|---|---|---|
| Post single image | 1200×630 | 1.91:1 |
| Post carrossel | 1080×1080 | Quadrado |
| Capa página | 820×312 desktop / 640×360 mobile | Cuidado crop |
| Stories | 1080×1920 | 9:16 |

---

## WhatsApp Business

| Formato | Dimensão | Obs |
|---|---|---|
| Status | 1080×1920 | 9:16, igual story |
| Catálogo imagem | 1080×1080 | 1:1, máximo 10MB |
| Figurinha | 512×512 | PNG transparente, máx 100KB |

---

## Blog / Site

| Formato | Dimensão | Obs |
|---|---|---|
| Banner de artigo | 1200×630 | OG image padrão |
| Miniatura interna | 800×450 | 16:9 |
| Imagem de destaque | 1920×1080 | Hero |

**Peso máximo recomendado:** 200KB (compactar sempre, usar WebP)

---

## Email / Newsletter

| Formato | Dimensão | Obs |
|---|---|---|
| Header | 600×200 | Largura máxima de email |
| Banner interno | 600×300 | Não ultrapassar largura |
| Imagem inline | até 600px largura | |

**Peso:** manter total do email < 1MB

---

## Regras transversais

### Safe zones (áreas sem texto crítico)
- **Instagram Stories/Reels:** 250px topo + 310px base
- **TikTok:** 150px base + 100px direita (icons)
- **YouTube Thumbnail:** evitar canto inferior direito (duração do vídeo)

### Contraste WCAG AA
- Texto normal: ≥ 4.5:1
- Texto grande (18pt+ bold, 24pt+ regular): ≥ 3:1

### Otimização de peso
- JPG: fotos, 80% qualidade
- PNG: ícones, texto, transparência
- WebP: sempre que possível no blog
- SVG: logos e ícones vetoriais

### Tamanho mínimo de fonte (legibilidade mobile)
- Display: 32pt+
- Subtítulo: 24pt+
- Corpo: 18pt+
- Nunca abaixo de 14pt

### Logo
- Tamanho: ≥ 5% da maior dimensão
- Posição: canto fixo por peça (consistência)
- Versão: sempre ter branca, preta e colorida
