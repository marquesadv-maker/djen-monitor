# Compliance Visual com OAB (Prov. 205/2021)

Checklist visual específico pra advocacia. Design bonito que fere ética = prejuízo.

---

## O que DEVE aparecer nas peças

### Identificação profissional
- **Nome do advogado responsável** com OAB e UF (ex: "Fulana de Tal — OAB/SP 123.456")
- Pode aparecer no slide de assinatura, no canto, ou no perfil vinculado
- Em peças sem identificação direta (ex: slide educativo), o **perfil da conta** já cumpre essa exigência

### Informação institucional (quando há CTA)
- Endereço do escritório ou meio de contato formal
- WhatsApp institucional (não pessoal)

---

## O que NÃO pode aparecer

### 1. Promessa de resultado visual
❌ Imagem de "cofre cheio de dinheiro" + texto "seu dinheiro de volta"
❌ "Após a ação: R$ 50.000" com foto de cliente sorrindo
❌ Cédulas, moedas, notas em destaque (visual mercantil)

### 2. Comparação com concorrente
❌ "Escritório X vs. Escritório Y" (tabela comparativa)
❌ Nome/logo de concorrente aparecendo na peça
❌ "Somos melhores que..."

### 3. Exposição de cliente
❌ Foto do cliente real (mesmo com autorização — evitar)
❌ Depoimento com foto e nome (fere sigilo profissional)
❌ Print de WhatsApp de cliente (mesmo anonimizado, perigoso)

### 4. Captação mercantilizada
❌ "Cupom de desconto em consulta"
❌ "Promoção de processos trabalhistas"
❌ "Seu processo por R$ X"
❌ QR code "agende agora e ganhe [brinde]"

### 5. Sensacionalismo visual
❌ Fontes em caixa alta gritantes (ALL CAPS o tempo todo)
❌ Cores de "alerta choque" sem propósito
❌ Efeitos de "explosão" ou urgência falsa
❌ Emoji de fogo, dinheiro, balão de grito em excesso

### 6. Símbolos jurídicos mercantilizados
❌ Balança da justiça estilizada com notas de dinheiro
❌ Martelo de juiz com cifrão
❌ Estátua da Justiça piscando ou em fundo neon

---

## O que PODE aparecer (boas práticas)

### Símbolos jurídicos sóbrios
✅ Balança da justiça discreta (ícone clean)
✅ Livros, códigos, leis
✅ Tribunal, fórum (em fotos contidas)

### Ambiente profissional
✅ Foto real do advogado no escritório
✅ Mesa com caderno, caneta, código
✅ Estante com livros jurídicos

### Ícones e gráficos
✅ Ícones de check, X, seta, info
✅ Infográficos com dados reais
✅ Gráficos de evolução (ex: reajuste histórico de benefício)

### Cenário didático
✅ Ilustrações genéricas (personagens fictícios, cenários)
✅ Timeline explicativa
✅ Passo a passo visual

---

## Aprovação visual — passo a passo

**Antes de publicar, confirme:**

1. **Olhe 3 segundos.** O que salta? Se é dinheiro, número de indenização ou "promessa" → refaz.
2. **Leia os textos.** Tem garantia, promessa, comparação? → refaz.
3. **Quem aparece?** É advogado ou cliente identificável? Cliente → refaz.
4. **A cor choca sem razão?** → revisa.
5. **O logo/OAB está visível no conjunto?** Não precisa estar em cada peça, mas no perfil + assinatura.

---

## Quando a dúvida persiste

Em caso de dúvida sobre uma peça:
- **Consulte o TED (Tribunal de Ética e Disciplina)** da sua seccional
- **Use versão conservadora:** se em dúvida, tire o elemento questionável
- **Arquive referência:** guarde registro de que seguiu orientação do TED (proteção futura)

---

## Provimento 205/2021 — resumo visual aplicável

O que o Provimento **permite**:
- Informar áreas de atuação
- Publicar artigos e conteúdo educativo
- Exibir OAB, formação, especialização
- Apresentar casos (de forma genérica, sem identificação)

O que o Provimento **proíbe**:
- Mercantilização
- Captação indevida
- Promessa de resultado
- Comparação com colegas
- Sensacionalismo
- Oferta de serviço em formato comercial/varejo

**Regra de bolso visual:** se a arte pareceria adequada num **outdoor de banco**, provavelmente está OK. Se parece **outdoor de Black Friday**, refaz.
