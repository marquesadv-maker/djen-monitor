# Briefing Visual — [Título da Peça]

> Gerado pela skill `criar-criativos`.
> Peça: [carrossel / capa reels / thumbnail / post feed / story / banner / anúncio]
> Dimensão: [1080x1350 / 1080x1920 / 1280x720 / etc.]
> Quantidade: [N peças / slides]

---

## Texto-fonte

[Copy ou trecho de roteiro aprovado — cole aqui]

---

## Hierarquia Visual

- **Primário (1s):** [o que chama atenção]
- **Secundário:** [contexto]
- **Terciário:** [marca, CTA]

---

## Identidade Aplicada

- **Paleta:**
  - Primária: [cor + hex]
  - Secundária: [cor + hex]
  - Texto: [cor + hex]
  - Fundo: [cor + hex]

- **Tipografia:**
  - Display (títulos): [fonte + peso]
  - Corpo: [fonte + peso]

- **Logo:**
  - Posição: [canto superior direito / inferior esquerdo / ...]
  - Tamanho: [% relativo]

- **Elemento gráfico recorrente:**
  - [linha, forma, ícone do manual]

---

## Especificação por Slide/Peça

### Slide 1 (capa)
- **Texto principal:** [texto]
- **Fonte e tamanho:** [Display 80pt]
- **Cor dominante:** [primária]
- **Elementos:** [logo no canto, elemento gráfico X]

### Slide 2
- **Texto:** [...]
- **Elemento visual:** [...]

### Slide N
[repetir]

### Slide de CTA
- **Texto CTA:** [ação]
- **Contato institucional:** [site + inscrição OAB]

---

## Checklist de Acessibilidade e OAB

- [ ] Contraste texto/fundo ≥ 4.5:1
- [ ] Tamanho mínimo de fonte legível em mobile
- [ ] Número OAB visível onde exigido
- [ ] Sem imagem de cliente identificável
- [ ] Sem símbolos mercantilizadores (dinheiro, martelo exagerado)
- [ ] Sem comparação visual com concorrente
- [ ] Sem sensacionalismo visual (cor choque sem propósito)

---

## Referências Visuais (inspiração, não cópia)

- **Ref 1:** [descrição do layout de referência]
- **Ref 2:** [descrição]
- **Evitar:** [estilos que não funcionam para essa peça]

---

## Observações para Designer

- [Ajustes específicos]
- [Assets disponíveis no manual]
- [Prazos de entrega]

---

## Formato do arquivo final

- **Exportar em:** [PNG / JPG / PDF]
- **Versões necessárias:** [Instagram feed, Instagram stories, LinkedIn, etc.]
