---
name: criar-criativos
description: Define briefing visual de criativos (carrosséis, capas, thumbnails, artes de post, banners) para escritórios de advocacia. Aplica manual de marca, hierarquia visual, acessibilidade e restrições OAB. Entrega briefing estruturado que o designer ou ferramenta (Canva, Figma) executa. Use SEMPRE que o advogado mencionar: "criar arte", "design do post", "arte do carrossel", "criativo", "capa do reels", "thumbnail", "banner", "criar visual", "layout do slide", "arte para anúncio", "identidade visual do post", "como ficar o design". Vincula copy/roteiro aprovado com execução visual coerente.
---

# Criar Criativos (Briefing Visual)

Esta skill gera **briefing visual estruturado** a partir de copy/roteiro aprovado. Entrega não é arte final — é a especificação que designer, advogado ou ferramenta (Canva/Figma) usa pra executar com consistência de marca.

## Por que briefing separado de design final

Mesma copy vira 3 artes diferentes dependendo de quem faz. Briefing elimina essa variância: paleta, tipografia, hierarquia, grid, elementos fixos, elementos variáveis.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — paleta, tipografia, logo, regras visuais
- `linha-editorial.md` — formatos recorrentes e regras de consistência
- Copy ou roteiro já finalizado (skills `criar-copy` ou `roteiros-video`)

Sem manual de marca definido, o briefing sai genérico.

## Workflow

### Bloco 1 — Identificar a peça

Confirme:
- **Tipo:** carrossel / capa reels / thumbnail YouTube / post feed / story / banner blog / anúncio?
- **Dimensão:** [conforme tipo]
- **Quantidade:** 1 peça ou série (ex: 10 slides)?
- **Texto-fonte:** qual copy/roteiro vai aplicar?

### Bloco 2 — Definir hierarquia visual

Para cada peça, determine:
- **Elemento primário** (o que chama atenção em 1s)
- **Elemento secundário** (contexto)
- **Elemento terciário** (marca, CTA secundário)

Regra: **no máximo 3 níveis de hierarquia por peça**. Mais que isso = poluição.

### Bloco 3 — Aplicar identidade da marca

Do manual de marca, extraia:
- **Paleta principal** (cor primária, secundária, neutras)
- **Tipografia principal** (display + corpo)
- **Posição do logo** (canto fixo)
- **Margens/safe zone** (definir respiros)
- **Elementos gráficos recorrentes** (linha, forma, ícones)

### Bloco 4 — Especificar por slide/peça

**Carrossel (exemplo 8 slides):**
- Slide 1 (capa): grande texto de gancho, cor primária dominante
- Slide 2-7: texto médio + 1 número/ícone apoiando
- Slide 8 (CTA): ação clara + contato institucional
- Cada slide: máximo 15-20 palavras

**Capa Reels / Thumbnail:**
- Texto de 3-7 palavras
- Rosto do advogado (se aparecer no vídeo)
- Contraste alto
- 1 ícone/elemento visual de apoio

**Post feed:**
- 1 imagem/ilustração + texto curto
- Frase-âncora em destaque
- Logo discreto no canto

**Story:**
- Texto grande (32pt+)
- 1 elemento interativo (enquete, caixinha)
- Branding discreto no topo

**Banner blog / Thumbnail YouTube:**
- Título legível em mobile (teste no tamanho real)
- Foto do advogado preferencialmente
- 2-3 cores da paleta

### Bloco 5 — Acessibilidade e OAB

Checklist visual:
- [ ] Contraste texto/fundo ≥ 4.5:1 (WCAG AA)
- [ ] Logo e OAB/número da inscrição visíveis onde exigido
- [ ] Sem imagem de cliente identificável
- [ ] Sem símbolos mercantilizadores (dinheiro exagerado, balança kitsch)
- [ ] Sem comparativos visuais com concorrente
- [ ] Se usa tom de urgência, não sensacionalista

### Bloco 6 — Sugerir referências visuais

Liste 2-3 **referências de composição** (não copiar):
- Layouts que funcionam pro tema
- Estilos a evitar

## Gerando o entregável

Use `references/template-briefing-visual.md`. Estruture:
- Metadados (peça, dimensão, qtd)
- Hierarquia visual
- Paleta e tipografia aplicadas
- Especificação por slide/peça
- Checklist de acessibilidade e OAB
- Observações para designer

## Integração com skills downstream

Briefing visual alimenta:
- Execução direta do designer ou advogado no Canva/Figma
- `qa-marca` (checa se arte final bateu com briefing)
- `qa-etico-oab` (checa elementos visuais problemáticos)

## Armadilha comum

**Briefing que descreve arte e não intenção.** "Coloque um fundo azul" é fraco. "Fundo azul-marinho (cor primária) para criar autoridade institucional, porque a pauta é sobre decisão do STF" é bom. Designer bom executa direção, não descrição.
