# Estruturas de Roteiro por Duração

Referência rápida para distribuir blocos dentro do tempo certo.

---

## Story vídeo (7-15s)

**Estrutura:**
- 0-2s: gancho (1 frase)
- 2-10s: informação principal (1 ideia só)
- 10-15s: CTA (arrasta / DM / caixinha)

**Palavras totais:** 20-35

**Uso típico:**
- Dica rápida
- Bastidor comentado
- Mito-verdade instantâneo

---

## Reels curto (15-30s)

**Estrutura:**
- 0-3s: gancho forte
- 3-25s: 1 ideia com 2 pontos de apoio
- 25-30s: CTA simples

**Palavras totais:** 40-75

**Uso típico:**
- 1 dica específica
- 1 mito derrubado
- 1 lembrete de direito

---

## Reels médio (45-90s)

**Estrutura:**
- 0-3s: gancho
- 3-15s: contextualização do problema
- 15-60s: desenvolvimento (3 pontos)
- 60-75s: exemplo concreto (cenário genérico)
- 75-90s: CTA

**Palavras totais:** 100-225

**Uso típico:**
- Explicação completa de 1 direito
- Passo a passo de 3 etapas
- Análise de 1 decisão

---

## YouTube médio (3-8 min)

**Estrutura:**
- 0-15s: gancho + preview do que o vídeo entrega
- 15-30s: quem fala (credencial curta)
- 30s-X: desenvolvimento em 3-4 capítulos
- Capítulo 1 (X min)
- Capítulo 2 (X min)
- Capítulo 3 (X min)
- Últimos 30s: recap + CTA + sugestão do próximo vídeo

**Palavras totais:** 450-1200

**Uso típico:**
- Guia completo de 1 tema
- Resposta a 3-5 dúvidas relacionadas
- Explicação de 1 processo do começo ao fim

---

## YouTube longo (8-15 min)

**Estrutura:**
- 0-30s: gancho longo + stakes (por que importa)
- 30s-1min: intro formal
- 1min-Xmin: desenvolvimento em 4-6 capítulos com micro-ganchos
- Exemplo/case (cenário genérico)
- Recap
- CTA + next video

**Palavras totais:** 1200-2200

**Uso típico:**
- Guia exaustivo
- Resposta a múltiplas dúvidas
- Autoridade profunda em 1 tema

---

## Live (30-60 min)

**Estrutura:**
- 0-5 min: boas-vindas, apresentação, tema
- 5-15 min: conteúdo estruturado (apresentação)
- 15-50 min: Q&A aberto com público
- 50-60 min: recap + CTA

**Uso típico:**
- Relacionamento
- Conversão de lead quente
- Resposta a dúvidas coletivas

---

## Regra de ouro da conversão fala-para-tempo

**1 segundo = 2,5 palavras** (advogado falando em ritmo natural)

Para calcular:
- 30s → 75 palavras
- 60s → 150 palavras
- 90s → 225 palavras
- 5 min → 750 palavras
- 10 min → 1500 palavras

Se o roteiro ultrapassa em 20% → corta. Não tente acelerar a fala.

---

## Ganchos visuais por formato

**Story:** texto grande cobrindo tela, advogado movendo
**Reels curto:** texto pulsando, corte rápido, movimento
**Reels médio:** texto estático + advogado + b-roll
**YouTube:** advogado centralizado, thumbnail potente
**Live:** enquadramento estável, 1 cor dominante de fundo
