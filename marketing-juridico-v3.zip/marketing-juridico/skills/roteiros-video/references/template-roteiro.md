# Roteiro — [Título da Pauta]

> Gerado pela skill `roteiros-video`.
> Formato: [Reels 60s / Short 30s / YouTube 5 min / Story vídeo 15s]
> Pilar: [...]
> Tipo funil: [autoridade / educação / conexão / conversão]
> CTA: [...]
> Duração total alvo: [segundos/minutos]

---

## Ideia central (1 frase)

[O que o espectador deve levar desse vídeo]

---

## Roteiro principal

### 🎬 0s-3s — GANCHO
**Fala:**
> [texto exato]

**Cena:** [advogado frontal / texto na tela / b-roll]
**Ritmo:** [rápido / médio / com pausa pós-frase]

---

### 🎬 3s-XXs — DESENVOLVIMENTO

**Ponto 1 ([tempo])**
- Fala: "[texto]"
- Cena: [...]
- Corte: [jumpcut / sem corte]

**Ponto 2 ([tempo])**
- Fala: "[texto]"
- Cena: [...]

**Ponto 3 (se houver)**
- Fala: "[texto]"
- Cena: [...]

---

### 🎬 Últimos 10s — CTA
**Fala:**
> [texto do CTA]

**Cena:** [advogado frontal, olhar direto, texto reforçando na tela]

---

## Variantes de gancho (A/B)

**Variante A (fórmula: pergunta):**
> [texto]

**Variante B (fórmula: dado):**
> [texto]

---

## B-roll sugerido

- [tomada 1: o que mostrar]
- [tomada 2: o que mostrar]
- [tomada 3: o que mostrar]

---

## Checklist pré-gravação

- [ ] Roteiro cabe no tempo (N palavras × 2,5 = segundos)
- [ ] Gancho em até 3s
- [ ] Zero juridiquês (ou traduzido)
- [ ] Zero promessa / sensacionalismo
- [ ] CTA é ação concreta e orientativa
- [ ] Figurino e enquadramento definidos

---

## Legenda sugerida para acompanhar o post

[3-5 linhas de texto + hashtags]

---

## Observações de produção

- Tempo estimado de gravação: [X] min
- Precisa de teleprompter? [sim/não]
- Edição: [simples / média / com b-roll]
