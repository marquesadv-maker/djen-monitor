# Direção de Cena para Vídeos Jurídicos

Como enquadrar, cortar e compor vídeo de advogado sem parecer amador ou corporativo demais.

---

## Enquadramento

### Reels / TikTok / Shorts
- **Formato vertical (9:16)**
- Advogado ocupando **1/3 do quadro (terço superior-central)**
- Texto grande no terço inferior
- Espaço para legenda automática do Instagram (não cobrir)

### Stories
- 9:16
- Advogado pode ocupar metade ou tela inteira
- Texto grande (mínimo 28pt)

### YouTube
- **Formato horizontal (16:9)**
- Advogado centralizado
- Background neutro (estante, parede lisa, escritório real)
- Iluminação frontal suave

### Live
- 16:9 horizontal
- Enquadramento médio (da cintura pra cima)
- Sem movimento da câmera

---

## Iluminação mínima viável

- Luz natural de janela lateral funciona
- Se artificial: ring light OU softbox frontal + luz de apoio
- Evitar: luz de teto direta (sombra embaixo do olho)
- Fundo nunca mais iluminado que o rosto

---

## Figurino

**O que funciona:**
- Terno ou blazer em tons sólidos (azul-marinho, cinza, preto)
- Camisa social lisa
- Para feminino: blusa sólida + blazer opcional

**O que evita:**
- Estampas muito pequenas (moiré na câmera)
- Branco puro (estoura a imagem)
- Verde saturado (interfere em chroma se usar)
- Acessórios que chamam mais atenção que o rosto

---

## Cortes e ritmo

### Reels (alta retenção)
- **Jumpcut a cada 2-4 segundos** nos primeiros 15s
- Cortes secos (sem fade)
- Elimina respiração, "é...", "então..."

### YouTube
- Cortes mais longos (5-10s entre cortes)
- Permite pausas naturais
- B-roll a cada 20-30s

### Live
- Sem cortes
- Manter mesma posição
- Apoiar com câmera secundária (se tiver)

---

## B-roll sugerido para jurídico

Use para quebrar monotonia do "advogado falando":

- **Close de escrita** (advogado assinando papel, caneta no contrato)
- **Livros e códigos** (estante, folhas virando)
- **Recortes de tela** (texto de lei, decisão com trechos marcados)
- **Ambiente do escritório** (fachada, mesa de reunião vazia)
- **Gráfico/infográfico na tela** (dado estatístico mencionado)

**Evitar:**
- Imagens de martelo de juiz (batido demais)
- Stock de aperto de mão genérico
- Balança de justiça clichê

---

## Texto na tela

### Regras
- **Fonte legível:** sans-serif (Inter, Montserrat, Poppins)
- **Tamanho:** mínimo 32pt vertical, 40pt horizontal
- **Contraste:** texto claro em fundo escuro ou vice-versa
- **Duração:** no mínimo 2s por frase na tela
- **Posição:** fora da área de ícones do Instagram (safe zone)

### Boas práticas
- Sublinhar termo técnico enquanto traduz na fala
- Mostrar número mencionado ("5 anos", "R$ 2.900")
- Legenda integral para acessibilidade

---

## Pausas e ritmo da fala

- **Pausa curta (0,3-0,5s)** depois do gancho → deixa a promessa assentar
- **Pausa média (0,5-1s)** entre pontos principais
- **Pausa final antes do CTA** → prepara o espectador para a ação

---

## Erros comuns em vídeo jurídico

1. **Começar com "olá pessoal tudo bem?"** — queima os 3s de ouro
2. **Ler roteiro visível na tela** — quebra credibilidade
3. **Falar rápido demais** — leigo não acompanha termos novos
4. **Não olhar pra câmera** — reduz conexão
5. **Ambiente muito formal** — distancia
6. **Ambiente muito informal** — tira autoridade
7. **Muito corte no YouTube** — poluído
8. **Pouco corte no Reels** — cansa

---

## Estrutura visual mínima por formato

| Formato | Câmera | Iluminação | Edição |
|---|---|---|---|
| Story | Celular vertical | Natural | Legenda + 1 texto |
| Reels | Celular tripé | Ring ou natural | Jumpcuts + texto animado |
| YouTube | Celular/câmera tripé | Softbox ou natural | Corte a cada 5-10s + b-roll |
| Live | Celular/câmera fixa | Estável | Sem edição |
