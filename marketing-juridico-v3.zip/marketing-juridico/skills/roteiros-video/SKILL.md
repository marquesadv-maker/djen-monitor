---
name: roteiros-video
description: Escreve roteiros de vídeo (Reels 30-90s, Shorts, Stories em vídeo, YouTube longo, TikTok) para escritórios de advocacia. Estrutura em gancho + desenvolvimento + CTA, inclui direção de cena (o que mostrar, tom, cortes), cumpre OAB e prioriza retenção nos primeiros 3 segundos. Use SEMPRE que o advogado mencionar: "roteiro de vídeo", "script de reels", "roteiro do Instagram", "vídeo curto", "roteiro TikTok", "shorts", "vídeo para YouTube", "storyboard", "o que falar no vídeo", "gravar vídeo mas não sei o que dizer", "roteiro de stories". Gera 2-3 versões e inclui variantes de gancho.
---

# Roteiros de Vídeo

Esta skill transforma uma pauta em **roteiro pronto para gravação**, com tempo marcado, gancho, fala por bloco, direção de cena e CTA. Cobre os formatos mais comuns: Reels/Shorts/TikTok (30-90s), Stories em vídeo, YouTube médio (3-8min) e longo (8-15min).

## Por que roteiro antes de câmera

Advogado que grava sem roteiro: se enrola, repete, perde gancho, esquece CTA, fala juridiquês. Roteiro força: primeira linha forte → 1 ideia central → fechamento com ação.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — tom
- `linha-editorial.md` — formato escolhido
- `personas.md` — nível de conhecimento do público
- `banco-ganchos.md` (opcional) — use gancho já validado

## Workflow

### Bloco 1 — Definir o formato exato

| Formato | Duração | Uso |
|---|---|---|
| Story vídeo | 7-15s | informação rápida, bastidor |
| Reels curto | 15-30s | 1 ideia só, alcance |
| Reels médio | 45-90s | 1 ideia explicada, autoridade |
| YouTube médio | 3-8 min | explicação profunda |
| YouTube longo | 8-15 min | guia completo, autoridade máxima |
| Live | 30-60 min | relacionamento, conversão |

### Bloco 2 — Estruturar o roteiro (formato curto ≤90s)

**Bloco A — Gancho (0s-3s)**
- Primeira frase = 80% do resultado
- Direto ao ponto
- Sem "oi pessoal tudo bem comigo"
- Pode começar com pergunta, dado, afirmação contraintuitiva

**Bloco B — Desenvolvimento (3s-75s)**
- 1 ideia central (não 3)
- Pode ter 2-3 pontos de apoio
- Cada ponto = 10-20s
- Usar exemplos concretos (cenário genérico, nunca caso real)

**Bloco C — CTA (últimos 5-15s)**
- Ação simples: salvar, comentar, seguir, DM
- Nunca "entra em contato pra ganhar seu processo"
- Assinatura opcional ("Dra. Fulana, previdenciarista")

### Bloco 3 — Estruturar roteiro (YouTube médio/longo)

**Intro (0s-30s):**
- Gancho + preview do que o vídeo entrega

**Desenvolvimento (bloco principal):**
- Divide em 3-5 capítulos
- Cada capítulo com micro-gancho no começo

**Exemplo/case (opcional):**
- Cenário genérico, sem identificação

**Fechamento:**
- Recap em bullets
- CTA claro
- Próximo vídeo sugerido

### Bloco 4 — Adicionar direção de cena

Para cada bloco, escreva:
- **Fala (o que dizer):** texto exato
- **Cena (o que mostrar):** advogado frontal, tela cheia de texto, recorte, b-roll
- **Corte:** jumpcut / transição / sem corte
- **Ritmo:** velocidade da fala, ênfase, pausa

### Bloco 5 — Gerar variantes de gancho

Entregue o roteiro principal + **2 variantes alternativas de gancho** (primeiros 3s). Isso permite ao advogado testar abertura sem regravar o corpo.

### Bloco 6 — Filtro OAB e ajuste de linguagem

Checklist:
- [ ] Zero promessa de resultado
- [ ] Zero caso identificável
- [ ] Zero comparação com concorrente
- [ ] Juridiquês traduzido
- [ ] CTA orientativo (não mercantil)
- [ ] Duração cabe no formato escolhido

## Gerando o entregável

Use `references/template-roteiro.md`. Estruture:
- Metadados (formato, duração, pilar, CTA)
- Roteiro com tempos marcados
- Fala + direção de cena por bloco
- 2 variantes de gancho
- Sugestões de corte e b-roll
- Estimativa de tempo de gravação

## Integração com skills downstream

Roteiros alimentam:
- `criar-criativos` (capa do vídeo, thumbnail)
- `qa-etico-oab` (checa conteúdo antes de gravar)
- `criar-copy` (legenda que acompanha o vídeo)

## Armadilha comum

**Roteiro longo demais para o formato.** Advogado lê roteiro de 250 palavras e tenta espremer em 30s. Não cabe. Regra: **1 segundo ≈ 2,5 palavras faladas**. Um Reels de 60s cabe ~150 palavras. Calibre antes de escrever.
