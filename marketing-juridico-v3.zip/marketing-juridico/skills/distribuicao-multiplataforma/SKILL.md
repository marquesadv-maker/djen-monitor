---
name: distribuicao-multiplataforma
description: Define estratégia de distribuição e repurposing de conteúdo jurídico entre plataformas — transforma 1 peça central em 5-10 derivativos (carrossel → reels → stories → artigo → LinkedIn → email → short) mantendo coerência e respeitando código de cada canal. Use SEMPRE que o advogado mencionar: "distribuir conteúdo", "repostar em várias plataformas", "repurposing", "adaptar para LinkedIn", "transformar artigo em posts", "aproveitar o mesmo conteúdo", "economizar produção", "postar em múltiplos canais", "estratégia multicanal", "derivar conteúdo". Maximiza ROI de cada pauta produzida.
---

# Distribuição Multiplataforma

Esta skill transforma **1 peça central** em **múltiplos derivativos** adaptados a cada canal. O escritório produz 1x e publica 5-10x, aumentando alcance sem aumentar carga de produção.

## Por que repurposing importa

- Escritório jurídico tem tempo de produção limitado
- Cada plataforma tem público e comportamento diferentes
- Mesma ideia, canais diferentes = alcance multiplicado
- Repetir conceitos reforça autoridade (não chateia se o formato muda)

## Pré-requisitos

Leia antes:
- `linha-editorial.md` — formatos ativos
- `calendario-editorial.md` — peça central planejada
- `personas.md` — onde persona está (WhatsApp, Insta, LinkedIn, YouTube)

## Workflow

### Bloco 1 — Escolher a peça-âncora

A peça-âncora é a mais densa, a partir da qual tudo deriva.

**Opções de âncora:**
- Artigo de blog (2000+ palavras) → âncora mais rica
- Vídeo YouTube longo (10+ min) → âncora audiovisual
- Live / webinar (30+ min) → âncora com interação
- Carrossel profundo (10 slides)

**Regra:** âncora primeiro, derivativos depois. Inverter a lógica = conteúdo raso virando artigo longo forçado.

### Bloco 2 — Mapear derivativos possíveis

**Da âncora, extraia:**

| Derivativo | Origem | Adaptação |
|---|---|---|
| Reels 60s | 1 ponto principal do artigo | Simplificar e visualizar |
| Short YouTube 30s | Trecho mais denso | Cortar e subtitlar |
| Carrossel 8 slides | Subtítulos do artigo | Texto + visual |
| Stories 3-5 telas | Dica principal | Storytelling visual |
| Post LinkedIn | Tese central | Reformatar pra B2B |
| Tweet/X thread | Bullets principais | Fragmentar |
| Email newsletter | Resumo + link | Contextualizar |
| Post feed simples | Quote forte | Card com frase |
| TikTok | Hook do artigo | Voz mais informal |
| Podcast/áudio | Leitura narrada | Adaptar pra áudio |

### Bloco 3 — Calibrar tom por plataforma

Mesma ideia muda de cara:

| Plataforma | Tom | Formato | CTA |
|---|---|---|---|
| Instagram | Próximo, visual, emocional | Reels, carrossel, story | Salva, DM, comenta |
| LinkedIn | Formal, autoridade, B2B | Texto longo, carrossel PDF | Comenta, conecta, DM |
| TikTok | Informal, rápido, direto | Vídeo curto, voz | Segue, comenta |
| YouTube | Didático, profundo | Vídeo longo | Inscreve, comenta |
| X (Twitter) | Opinativo, denso | Thread, quote | RT, comenta |
| Blog | Técnico, SEO | Artigo | Comenta, compartilha |
| Email | Relacionamento | Newsletter | Responde, clica |
| WhatsApp status | Informal, familiar | Foto/vídeo curto | DM |

### Bloco 4 — Cronograma de distribuição

**Padrão sugerido (âncora = artigo de blog):**

- **D+0:** publicar artigo no blog (SEO pega)
- **D+1:** post no LinkedIn referenciando o artigo
- **D+2:** carrossel Instagram com 3 pontos do artigo
- **D+4:** reels 60s com o insight principal
- **D+7:** email newsletter com link pro artigo
- **D+10:** story com enquete sobre o tema
- **D+14:** short YouTube 30s
- **D+21:** tweet/thread com bullets do artigo

**Padrão sugerido (âncora = vídeo YouTube):**

- **D+0:** publicar YouTube longo
- **D+1:** short YouTube com melhor trecho
- **D+2:** reels Instagram com mesmo trecho
- **D+4:** carrossel resumo
- **D+7:** post LinkedIn com tese central
- **D+10:** email com link do vídeo
- **D+21:** TikTok de versão alternativa

### Bloco 5 — Adaptar a copy para cada canal

Regra: **mesmo núcleo, voz da plataforma**.

**Exemplo** (tese: "Revisão da vida toda ainda vale em 2026"):

- **Blog:** "Revisão da vida toda em 2026: quem ainda tem direito após modulação do STF" (1800 palavras, técnico)
- **LinkedIn:** "Modulação do STF na revisão da vida toda: o que mudou e como profissionais de RH devem orientar segurados" (500 palavras, B2B)
- **Instagram carrossel:** "3 mudanças que TODO aposentado precisa saber sobre a revisão da vida toda" (8 slides, leigo)
- **Reels:** "Você ainda tem direito à revisão da vida toda? Depende de 1 coisa." (60s, gancho + 1 explicação)
- **Story:** "Enquete: você sabia que tinha esse direito?" (interativo)
- **Email:** "Se você se aposentou antes de 1999, leia isso hoje" (400 palavras, relacionamento)

### Bloco 6 — Checklist OAB por canal

Cada canal tem risco OAB específico:
- **TikTok:** cuidado com sensacionalismo pra pegar algoritmo
- **Instagram:** cuidado com CTA de captação em DM
- **LinkedIn:** cuidado com comparação entre escritórios/profissionais
- **Anúncios pagos:** passam por QA OAB separado (skill ads)

## Gerando o entregável

Use `references/template-plano-distribuicao.md`. Estruture:
- Peça-âncora identificada
- Lista de 5-10 derivativos
- Cronograma de publicação (D+0 a D+21)
- Tom e adaptação por canal
- Checklist OAB transversal

## Integração com skills downstream

Plano alimenta:
- `criar-copy` (gera copy de cada derivativo)
- `criar-criativos` (gera briefing visual de cada)
- `calendario-editorial` (distribui derivativos nos dias)

## Armadilha comum

**Publicar o mesmo post idêntico em todos os canais.** Público do LinkedIn não lê como o do TikTok. Copiar e colar quebra a relevância. Sempre adapte voz, formato e CTA por canal, mesmo mantendo o núcleo de conteúdo.
