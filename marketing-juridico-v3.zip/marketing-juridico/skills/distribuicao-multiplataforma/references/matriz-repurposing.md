# Matriz de Repurposing — De 1 peça para 10

Mapa visual de como 1 âncora vira múltiplos derivativos.

---

## Âncora: Artigo de blog (2000 palavras)

```
Artigo blog (D+0)
│
├── LinkedIn post longo (D+1) — tese central + link
├── Carrossel Instagram 8 slides (D+2) — 3 pontos principais
├── Reels 60s (D+4) — 1 insight + gancho forte
├── Story enquete (D+5) — engajamento em torno do tema
├── Email newsletter (D+7) — resumo + link + relacionamento
├── Short YouTube 30s (D+10) — recorte do reels
├── Thread X (D+14) — bullets em sequência
└── Post feed simples (D+21) — quote do artigo
```

**Rendimento:** 8 peças a partir de 1 artigo.

---

## Âncora: Vídeo YouTube (10 min)

```
YouTube longo (D+0)
│
├── Short YouTube (D+1) — melhor corte de 30s
├── Reels Instagram (D+2) — mesmo corte adaptado
├── TikTok (D+3) — versão mais informal
├── Carrossel Instagram (D+5) — transcript em formato didático
├── Artigo blog (D+7) — transcript editado + SEO
├── LinkedIn post (D+10) — tese central
├── Email (D+14) — link do vídeo + contexto
└── Story sequência (D+21) — dicas rápidas do vídeo
```

**Rendimento:** 8 peças a partir de 1 vídeo.

---

## Âncora: Live / Webinar (30-60 min)

```
Live (D+0)
│
├── Gravação no YouTube (D+1) — versão editada
├── Cortes virais (D+3 a D+14) — 3-5 reels diferentes
├── Carrossel (D+5) — principais perguntas do público
├── Artigo blog (D+7) — resumo + aprofundamentos
├── Email (D+10) — relatório pós-live
├── Case study / E-book (D+21) — compilação densa
└── Podcast (D+30) — áudio da live editado
```

**Rendimento:** 10+ peças a partir de 1 live.

---

## Regras de repurposing

### 1. Adaptar, não copiar
Mesmo texto em 3 canais = 3 públicos cansados. Sempre reformatar voz, gancho, CTA.

### 2. Variar o ponto de entrada
Cada derivativo começa de um ângulo diferente (dor / autoridade / curiosidade).

### 3. Respeitar o ritmo da plataforma
- TikTok rápido
- LinkedIn denso
- Instagram visual
- YouTube narrativo
- Blog técnico

### 4. Lembrar a âncora nos derivativos
Todo derivativo deve referenciar a âncora (link do artigo, do vídeo) → direciona tráfego pra canal próprio.

### 5. Espaçar no tempo
Se postar 8 peças do mesmo tema em 1 dia, afasta. Distribuir em 21 dias permite que o tema "grude" sem saturar.

### 6. Medir cada peça separadamente
Derivativo A (reels) pode bombar enquanto derivativo B (LinkedIn) flopa. Isso informa futuros repurposings.

---

## Ordem estratégica de publicação

**Regra empírica:**

1. **Âncora (canal próprio):** blog ou YouTube — SEO captura primeiro
2. **Canal de alcance:** Instagram, TikTok — expõe pra público novo
3. **Canal de autoridade:** LinkedIn — consolida imagem profissional
4. **Canal de relacionamento:** email, WhatsApp — nutre lista própria
5. **Variações tardias:** stories, shorts, threads — mantém o tema vivo

---

## Quando NÃO repurposar

- **Pauta urgente/reativa:** pega onda rápida, não vira âncora
- **Conteúdo muito específico de 1 canal** (ex: enquete de story)
- **Dados sensíveis de 1 plataforma** (ex: linkar LinkedIn em TikTok pode não fazer sentido)
- **Conteúdo de baixa qualidade:** repurposar ruim = ruim em 8 canais
