# Plano de Distribuição — [Tema]

> Gerado pela skill `distribuicao-multiplataforma`.
> Peça-âncora: [artigo blog / vídeo YouTube / live / carrossel profundo]
> Data da âncora: [D+0]
> Duração do plano: 21 dias

---

## Núcleo da mensagem (1 frase)

[Tese central que todos os derivativos carregam]

---

## Peça-âncora

- **Formato:** [...]
- **Extensão:** [palavras/minutos]
- **Link/localização:** [...]
- **CTA principal:** [...]

---

## Derivativos

### D+0 — Âncora
**Canal:** [blog/YouTube]
**Status:** 🟡 em produção / 🟢 pronto

### D+1 — [Canal]
- **Formato:** [...]
- **Adaptação:** [o que mudou em relação à âncora]
- **CTA:** [...]
- **Copy:** [link para skill criar-copy ou texto aqui]

### D+2 — [Canal]
- [repetir]

### D+4 — [Canal]
- [repetir]

### D+7 — [Canal]
- [repetir]

### D+10 — [Canal]
- [repetir]

### D+14 — [Canal]
- [repetir]

### D+21 — [Canal]
- [repetir]

---

## Mapeamento tom × canal

| Canal | Tom aplicado | Formato final |
|---|---|---|
| Blog | [...] | [...] |
| LinkedIn | [...] | [...] |
| Instagram | [...] | [...] |
| YouTube | [...] | [...] |
| TikTok | [...] | [...] |
| Email | [...] | [...] |

---

## Observações de execução

- **Tempo total de produção estimado:** [horas]
- **Responsável principal:** [nome]
- **Designer/editor:** [nome]
- **Revisão OAB antes de publicar:** obrigatória para cada peça

---

## Checklist OAB transversal

- [ ] Nenhum derivativo promete resultado
- [ ] Nenhum derivativo compara com concorrente
- [ ] CTAs são orientativos, não mercantis
- [ ] Sem caso identificável em nenhuma peça
- [ ] Adaptação de tom não caiu em sensacionalismo
