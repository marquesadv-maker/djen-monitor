---
name: qa-etico-oab
description: Audita qualquer peça de marketing jurídico contra Provimento 205/2021 CFOAB, Código de Ética e Disciplina, e legislação correlata antes da publicação. Verifica copy, criativo, landing page, roteiro, email, anúncio e gera relatório com status (APROVADO / REVISAR / REPROVADO) + correções sugeridas. Use SEMPRE que o advogado mencionar: "revisar OAB", "isso pode pela OAB", "passa pela ética", "checar provimento", "revisão ética", "aprovar conteúdo", "validar anúncio", "risco disciplinar", "conformidade OAB", "auditoria ética", "QA jurídico", "pode publicar isso". É a última barreira antes de qualquer peça ir ao ar.
---

# QA Ético OAB — Auditoria de Conformidade

Skill de **bloqueio**: toda peça de marketing do escritório passa por aqui antes de publicar. Zero exceção.

## Por que existe

Fiscalização OAB prioriza denúncias sobre publicidade. Uma peça reprovada = processo disciplinar = sanção. Custo de errar: altíssimo. Custo de revisar: 5 minutos.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — tom e linha editorial
- `personas.md` — público-alvo
- Peça a ser auditada

## Workflow

### Bloco 1 — Classificar o tipo de peça

| Tipo | Risco OAB | Atenção extra |
|---|---|---|
| Post informativo orgânico | Baixo | Tom, promessa |
| Reels/vídeo curto | Médio | Gancho emocional, claims visuais |
| Anúncio pago | **Alto** | Tudo (copy + LP + criativo) |
| Landing page | Alto | Formulário, prova, CTA |
| Email/WhatsApp | Médio | Personalização, promessa |
| Case/depoimento | **Crítico** | Anonimização, consentimento |

### Bloco 2 — Checklist bloqueante (qualquer "sim" = REPROVADO)

- [ ] Promete resultado? ("vai ganhar", "receba", "garantimos")
- [ ] Cita valor de indenização conquistada?
- [ ] Compara com outro escritório? ("melhor", "mais rápido")
- [ ] Usa urgência mercantilizada? ("última chance", "só hoje")
- [ ] Oferece desconto/promoção/brinde?
- [ ] Expõe cliente identificável? (nome, foto, processo)
- [ ] Usa depoimento não autorizado por escrito?
- [ ] Promove área não habilitada pelo advogado?
- [ ] Usa linguagem sensacionalista/apelativa?
- [ ] CTA mercantil? ("contrate agora", "compre")

### Bloco 3 — Checklist de forma (itens obrigatórios)

- [ ] Nome do advogado responsável visível
- [ ] Número OAB + seccional visível
- [ ] Escritório identificável
- [ ] Sem uso indevido de símbolos oficiais (balança, escudo STF)
- [ ] Foto profissional (não casual em excesso)
- [ ] Linguagem orientativa, não imperativa

### Bloco 4 — Checklist de tom (amarelos)

Itens que não reprovam sozinhos mas acumulados geram risco:
- [ ] Emoji em excesso (>3 por post)
- [ ] Caps lock agressivo
- [ ] Uso de "você merece", "você tem direito sagrado"
- [ ] Storytelling com cliente "baseado em caso real" sem disclaimer
- [ ] Numeração exata de sucesso ("atendi 327 casos")

### Bloco 5 — Gerar relatório

Use `references/template-relatorio-qa-oab.md`. Formato:
- **Status:** APROVADO / REVISAR / REPROVADO
- **Itens bloqueantes encontrados:** [lista]
- **Itens de forma faltando:** [lista]
- **Amarelos:** [lista]
- **Sugestões de correção:** [texto revisado]
- **Veredito final + justificativa**

### Bloco 6 — Reescrita sugerida

Se REPROVADO/REVISAR, entregar versão corrigida lado a lado:

| Original (problema) | Corrigido (OK) |
|---|---|
| "Receba sua indenização" | "Entenda seus direitos" |
| "Melhor escritório" | "Escritório com atuação desde 2010" |
| "Garantimos resultado" | "Analisamos seu caso com atenção" |

## Integração com skills

**QA-Ético é chamada obrigatoriamente por:**
- `criar-copy`
- `roteiros-video`
- `criar-criativos`
- `landing-pages`
- `nutricao-whatsapp-email`
- `ads-multichannel`
- `distribuicao-multiplataforma`

**Output alimenta:**
- `qa-marca` (se passou OAB, conferir marca)
- Fluxo de publicação

## Armadilhas comuns

1. **Pular QA "só dessa vez".** Risco altíssimo, ganho zero.
2. **Confundir OAB com LGPD.** São duas revisões separadas.
3. **Revisar só o texto.** Criativo visual também viola (ex: selo "melhor escritório").
4. **Achar que orgânico é menos fiscalizado.** É igual.

## Base normativa

- Provimento 205/2021 CFOAB
- Código de Ética e Disciplina da OAB
- Resolução OAB-DF 005/2023 (complementar)
- Lei 8.906/94 (Estatuto da Advocacia)
