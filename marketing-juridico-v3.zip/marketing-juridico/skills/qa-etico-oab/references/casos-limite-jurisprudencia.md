# Casos-Limite — Zonas Cinzentas do Provimento 205/2021

Situações frequentes em que advogados ficam em dúvida sobre o que pode ou não.

---

## 1. Posso mostrar o valor de causas coletivas genéricas?

**Resposta curta:** NÃO, mesmo anonimizado.

**Por quê:** Qualquer divulgação de valor de condenação/acordo = captação mercantilizada. Inclui prints de extrato, comprovantes, "conquistei R$ X".

**Alternativa:** "Atuamos em causas de [tipo], com experiência em decisões favoráveis a trabalhadores/consumidores/etc."

---

## 2. Posso usar depoimento de cliente?

**Resposta curta:** Sim, com 3 condições cumulativas.

1. Autorização expressa por escrito (registrada)
2. Sem exposição de detalhes do processo
3. Sem valor/resultado específico

**Alternativa segura:** Depoimento sobre "qualidade do atendimento", "clareza na explicação", "tranquilidade durante o processo" — sem resultado.

---

## 3. Posso postar sobre uma vitória recente?

**Resposta curta:** Depende do enquadramento.

**Proibido:**
- "Ganhamos ação de R$ 500 mil"
- "Cliente recebeu sua aposentadoria"
- Foto com cliente + processo

**Permitido:**
- Comentar a tese jurídica em abstrato
- Explicar o precedente do tribunal
- Educar sobre o tema da decisão

---

## 4. Posso oferecer "primeira consulta gratuita"?

**Resposta curta:** Ambíguo — evitar como gatilho comercial.

**Problema:** OAB entende que pode configurar captação se usado como chamariz principal ("GRÁTIS!").

**Alternativa:** "Oferecemos conversa inicial sem compromisso para entender se podemos ajudar."

---

## 5. Posso pagar tráfego para aparecer como primeiro no Google?

**Resposta curta:** Sim, com restrições.

**OK:** Anúncios informativos, neutros, com OAB visível.

**Não OK:** Anúncios com promessa, valor, comparação.

---

## 6. Posso usar "especialista em" sem ser pós-graduado?

**Resposta curta:** NÃO.

Segundo OAB, "especialista" exige pós-graduação registrada. Use "atuante em", "com experiência em", "dedicado a".

---

## 7. Posso fazer sorteio/brinde em post?

**Resposta curta:** NÃO.

Configura captação mercantilizada. Qualquer brinde vinculado a contato, agendamento, indicação = violação.

---

## 8. Posso aparecer em Reels dançando/em tom descontraído?

**Resposta curta:** Sim, com limite.

**OK:** Tom leve, informativo, humanizado.

**Não OK:** Sensacionalismo, exposição vexatória da profissão, dublagem de áudios comerciais agressivos.

---

## 9. Posso responder comentário de cliente em público?

**Resposta curta:** Com muito cuidado.

Não revelar detalhes do caso, não confirmar que a pessoa é cliente, redirecionar para canal privado.

**Modelo seguro:** "Obrigado pelo contato. Para analisarmos com a atenção que o caso merece, me chama no privado."

---

## 10. Posso fazer live falando sobre caso real?

**Resposta curta:** Só em abstrato.

Use "em casos como esse" / "uma situação comum que vemos" — nunca nomes, valores, detalhes identificáveis.

---

## Regra-ouro em dúvida

> Se o post fosse printado por um promotor de ética da OAB, ele encontraria algo pra abrir sindicância?

Se a resposta for "talvez" — reescreva.
