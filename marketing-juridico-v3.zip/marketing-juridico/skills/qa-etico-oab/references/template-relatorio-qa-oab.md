# Relatório de QA Ético OAB

> Gerado pela skill `qa-etico-oab`.
> Data: [...]
> Peça analisada: [tipo + canal]
> Responsável pela auditoria: Dr. Cláudio (IA) — revisão final humana recomendada

---

## Status final

**[ APROVADO / REVISAR / REPROVADO ]**

---

## 1. Peça original

```
[colar texto/descrição da peça]
```

---

## 2. Checklist bloqueante

| Item | Status |
|---|---|
| Promessa de resultado | [ OK / ⚠️ / ❌ ] |
| Valor de indenização | [...] |
| Comparação concorrente | [...] |
| Urgência mercantil | [...] |
| Desconto/promoção | [...] |
| Cliente identificável | [...] |
| Depoimento sem autorização | [...] |
| Área não habilitada | [...] |
| Sensacionalismo | [...] |
| CTA mercantil | [...] |

---

## 3. Checklist de forma

| Item | Status |
|---|---|
| Nome advogado visível | [...] |
| OAB + seccional | [...] |
| Escritório identificável | [...] |
| Sem símbolos oficiais indevidos | [...] |
| Linguagem orientativa | [...] |

---

## 4. Amarelos (risco acumulado)

- [descrever]

---

## 5. Itens encontrados

### ❌ Bloqueantes
- [item 1 + trecho problemático]

### ⚠️ Revisar
- [item 1]

### 🟢 OK
- [itens que passaram]

---

## 6. Versão corrigida sugerida

```
[texto reescrito livre de violações]
```

### Comparação lado a lado

| Original | Corrigido |
|---|---|
| [...] | [...] |

---

## 7. Justificativa + base normativa

- Art. [X] Provimento 205/2021: [...]
- Art. [Y] CED/OAB: [...]

---

## 8. Próxima ação

- [ ] Corrigir e reenviar para novo QA
- [ ] Aprovar publicação após assinatura do responsável
- [ ] Arquivar peça descartada

**Responsável final:** [advogado nome + OAB]
**Assinatura/ciência:** ______________________________
