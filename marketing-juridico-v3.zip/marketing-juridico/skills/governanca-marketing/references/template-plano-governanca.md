# Plano de Governança de Marketing — [Escritório]

> Gerado pela skill `governanca-marketing`.
> Data: [...]
> Revisão: trimestral

---

## 1. Escopo

- **Escritório:** [...]
- **Áreas de atuação:** [...]
- **Tamanho da equipe de marketing:** [...]
- **Orçamento mensal:** R$ [...]
- **Meta anual:** [...]

---

## 2. Papéis

| Papel | Pessoa | Tempo dedicado |
|---|---|---|
| Patrocinador | [...] | [...]h/semana |
| Executor principal | [...] | [...]h/semana |
| Revisor ético | [...] | [...]h/semana |
| Analista | [...] | [...]h/semana |

---

## 3. Rituais fixos

| Ritual | Dia/hora | Duração |
|---|---|---|
| Planejamento editorial | [...] | [...] |
| Alinhamento semanal | [...] | [...] |
| Revisão mensal | [...] | [...] |
| Retro trimestral | [...] | [...] |

---

## 4. Fluxo de aprovação

```
[desenhar fluxo específico do escritório]
```

**SLAs:**
- Briefing: [...]
- Produção: [...]
- QAs: [...]
- Aprovação final: [...]

---

## 5. Ferramentas contratadas

| Camada | Ferramenta | Custo/mês |
|---|---|---|
| Planejamento | [...] | [...] |
| Design | [...] | [...] |
| Social | [...] | [...] |
| Email | [...] | [...] |
| CRM | [...] | [...] |

---

## 6. Métricas-alvo

**Mensais:**
- Leads qualificados: [...]
- CPL: [...]
- Agendamentos: [...]

**Trimestrais:**
- Novos clientes: [...]
- CAC: [...]
- ROI: [...]

---

## 7. Matriz de skills do plugin em uso

- [ ] manual-marca
- [ ] personas
- [ ] produto-nicho
- [ ] editorial-linha
- [ ] calendario-editorial
- [ ] curar-conteudo
- [ ] criar-copy
- [ ] headlines-ganchos
- [ ] roteiros-video
- [ ] criar-criativos
- [ ] seo-juridico
- [ ] distribuicao-multiplataforma
- [ ] landing-pages
- [ ] captura-lead
- [ ] nutricao-whatsapp-email
- [ ] ads-multichannel
- [ ] qa-etico-oab
- [ ] qa-marca
- [ ] qa-performance
- [ ] gestao-crise-reputacao
- [ ] governanca-marketing

---

## 8. Calendário de revisão da governança

- **Mensal:** métricas + ajustes táticos
- **Trimestral:** retro + ajuste de processo
- **Semestral:** manual de marca + ferramentas
- **Anual:** estratégia geral + orçamento
