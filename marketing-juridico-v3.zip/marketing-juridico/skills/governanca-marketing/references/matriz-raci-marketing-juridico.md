# Matriz RACI — Marketing Jurídico

Quem é **R**esponsável, **A**provador, **C**onsultado, **I**nformado em cada atividade.

---

| Atividade | Sócio Principal | Sócio Marketing | Executor | QA Ético | Analista |
|---|---|---|---|---|---|
| Definir estratégia anual | A | R | C | I | C |
| Manual de marca | A | R | C | C | I |
| Personas | C | R | R | I | C |
| Calendário editorial | A | R | R | I | I |
| Produção de copy | I | C | R | I | I |
| Produção de criativo | I | C | R | I | I |
| Aprovação OAB | A | C | I | R | I |
| Aprovação marca | I | A/R | I | C | I |
| Publicação | I | A | R | I | I |
| Anúncios pagos | A | R | R | C | I |
| Gestão de crise | A | R | C | C | I |
| Relatório mensal | I | A | C | I | R |
| Contratação de fornecedor | A | R | I | I | C |
| Orçamento | A | R | I | I | C |

---

## Legenda

- **R** (Responsável): faz o trabalho
- **A** (Aprovador): autoriza, responde pelo resultado
- **C** (Consultado): dá input antes
- **I** (Informado): sabe depois

---

## Regras de ouro

1. **1 A por atividade.** Mais de um aprovador = decisão travada.
2. **Mínimo 1 R.** Sem responsável = ninguém executa.
3. **QA Ético sempre presente antes da publicação.**
4. **Sócio principal é A em tudo que envolve orçamento ou crise.**
5. **Adaptar ao tamanho do escritório** — em escritório pequeno, 1 pessoa pode acumular papéis, mas separar mentalmente.

---

## Escritório solo (1 advogado)

Quando é 1 pessoa só, o RACI vira "chapéus" que você troca:

- **Chapéu de sócio:** define estratégia, aprova orçamento
- **Chapéu de executor:** produz peças (ou contrata)
- **Chapéu de revisor ético:** usa `qa-etico-oab` antes de publicar — ZERO exceção
- **Chapéu de analista:** 1 hora por mês olhando número

Se não trocar os chapéus conscientemente, vira tudo reativo.
