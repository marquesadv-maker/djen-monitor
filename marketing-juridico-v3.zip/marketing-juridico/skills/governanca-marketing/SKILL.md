---
name: governanca-marketing
description: Estrutura a governança geral do marketing do escritório — papéis, rituais, fluxos de aprovação, métricas, ferramentas, calendário de revisão, integração entre skills. É a skill "guarda-chuva" que organiza como todo o plugin marketing-juridico opera dentro do escritório. Use quando o advogado mencionar: "como organizar o marketing", "papéis da equipe", "fluxo de aprovação", "rituais de marketing", "governança", "processo de publicação", "quem aprova o quê", "rotina de marketing", "setup do marketing do escritório", "implantar marketing interno".
---

# Governança de Marketing Jurídico

Skill estratégica que organiza como o escritório **opera** o marketing — não apenas cria peças, mas mantém o sistema funcionando.

## Por que existe

Escritórios sem governança de marketing:
- Dependem de 1 pessoa (sócio ou estagiário) pra tudo
- Postam quando "dá tempo"
- Não medem resultado
- Repetem erros
- Perdem oportunidades sazonais

## Pré-requisitos

Leia (se existirem):
- `manual-marca.md`
- `personas.md`
- `calendario-editorial.md`
- Todas as skills do plugin (para mapear integração)

## Workflow

### Bloco 1 — Definir papéis

**Papéis mínimos (escritório pequeno, 2-5 advogados):**

| Papel | Quem | Responsabilidade |
|---|---|---|
| Patrocinador | Sócio principal | Orçamento + decisão estratégica |
| Executor | Advogado/estagiário/freelancer | Produção de conteúdo |
| Revisor ético | Sócio + QA-Ético IA | Aprovação final OAB |
| Analista | Quem olha resultado | Relatório mensal |

**Papéis ampliados (escritório médio/grande):**
- Head de marketing
- Social media manager
- Copywriter interno
- Designer
- Tráfego pago
- Gestão de CRM/leads

### Bloco 2 — Rituais de marketing

| Ritual | Frequência | Participantes | Duração |
|---|---|---|---|
| Planejamento editorial | Mensal | Todos envolvidos | 60 min |
| Alinhamento de pauta | Semanal | Executor + sócio | 15 min |
| Revisão de performance | Mensal | Analista + sócios | 45 min |
| Retro trimestral | Trimestral | Todos | 90 min |
| Reunião de crise | Sob demanda | Sócios + marketing | 30 min |

### Bloco 3 — Fluxo de aprovação padrão

```
Ideia → Briefing (skill específica) →
Produção (copy/criativo/roteiro) →
QA-Ético OAB (obrigatório) →
QA-Marca (obrigatório) →
QA-Performance preview (opcional) →
Aprovação sócio responsável →
Publicação →
Monitoramento 48h
```

**SLA por etapa:**
- Briefing: 1 dia
- Produção: 2-3 dias
- QAs: 1 dia
- Aprovação final: 4 horas
- Total ideal do ciclo: 5-7 dias

### Bloco 4 — Métricas por camada

**Operacional (semanal):**
- Nº de peças publicadas
- Cumprimento do calendário
- Lead time médio

**Tático (mensal):**
- CPL, CTR, taxa conversão
- Leads qualificados
- Agendamentos gerados

**Estratégico (trimestral):**
- CAC
- Clientes novos
- Receita de marketing
- ROI do marketing

### Bloco 5 — Stack de ferramentas mínimo

| Camada | Ferramenta sugerida |
|---|---|
| Planejamento | Notion / Trello / Asana |
| Design | Canva Pro / Figma |
| Agendamento social | mLabs / Etus / Metricool |
| Email | RD Station / ActiveCampaign / Brevo |
| WhatsApp | Z-API / Twilio |
| CRM | RD Station CRM / Pipedrive |
| Analytics | GA4 + nativo plataformas |
| Ads | Meta / Google Ads + Looker Studio |

### Bloco 6 — Integração entre skills do plugin

**Fluxo típico de uma campanha:**

```
manual-marca → personas → produto-nicho
    ↓
editorial-linha → calendario-editorial → curar-conteudo
    ↓
criar-copy + headlines-ganchos + roteiros-video + criar-criativos
    ↓
seo-juridico → landing-pages → captura-lead
    ↓
distribuicao-multiplataforma → ads-multichannel
    ↓
nutricao-whatsapp-email
    ↓
qa-etico-oab → qa-marca → publicação
    ↓
qa-performance → (loop de otimização)
    ↓
gestao-crise-reputacao (se necessário)
```

### Bloco 7 — Documentação viva

Manter atualizado:
- Manual de marca (revisão semestral)
- Banco de personas (revisão anual)
- Playbook de crise (após cada incidente)
- Resultados históricos (mensal)
- Matriz de aprovação (quando muda equipe)

## Gerando o entregável

Use `references/template-plano-governanca.md` para documentar a estrutura do escritório.

## Armadilhas comuns

1. **Sócio "aprovador único" sobrecarregado.** Gargalo — descentralizar aprovações de baixo risco.
2. **Sem ritual fixo.** Vira "quando dá".
3. **Ferramentas demais.** 12 ferramentas = ninguém usa. 3-4 integradas > 10 soltas.
4. **Não medir ROI.** Marketing sem métrica = custo, não investimento.
5. **Terceirizar 100% sem treinar agência em OAB.** Risco disciplinar altíssimo.
