---
name: seo-juridico
description: Otimiza conteúdo jurídico para busca orgânica no Google — pesquisa de palavras-chave para nichos jurídicos, estrutura de artigo (H1/H2/H3), intenção de busca, meta description, internal linking e compliance OAB em SEO. Use SEMPRE que o advogado mencionar: "SEO", "rankear no Google", "palavras-chave", "aparecer na busca", "keyword", "meta description", "título do artigo", "artigo para site", "blog jurídico", "tráfego orgânico", "otimizar site", "Google", "busca orgânica", "ranking". Aplica-se a artigos, landing pages e páginas institucionais do escritório.
---

# SEO Jurídico

Esta skill otimiza conteúdo escrito do escritório para ser encontrado no Google. Foca em **intenção de busca** da persona + estrutura técnica do artigo + restrições OAB.

## Por que SEO é diferente no jurídico

- Volume de busca alto (brasileiros pesquisam direito no Google todo dia)
- Concorrência ferrenha (JusBrasil, Conjur, portais domina as SERPs)
- Restrição OAB: não pode prometer, não pode comparar, não pode ser mercantil
- Keywords são majoritariamente leigas ("direito da mulher demitida grávida"), não jurídicas ("estabilidade gestante CLT")

## Pré-requisitos

Leia antes:
- `personas.md` — vocabulário leigo da persona
- `produto-nicho.md` — nichos de atuação
- `linha-editorial.md` — tom e regras

## Workflow

### Bloco 1 — Definir a intenção de busca

Toda keyword tem 1 intenção:
- **Informacional:** "o que é BPC-LOAS" (aprender)
- **Navegacional:** "INSS meu benefício" (achar algo específico)
- **Comparativa:** "aposentadoria por idade ou tempo qual melhor"
- **Transacional:** "advogado previdenciário [cidade]" (contratar)

Artigo do blog = informacional ou comparativo.
Landing page = transacional.
Páginas institucionais = navegacional + transacional.

**Nunca misture intenções.** Artigo informacional com CTA de contratação pesado prejudica ranking.

### Bloco 2 — Pesquisar palavras-chave

**Fontes:**
- Google Autocomplete (digita + espera sugestões)
- "People Also Ask" (perguntas relacionadas no Google)
- "Searches related to" (final da SERP)
- AnswerThePublic (gratuito limitado)
- Keyword Planner do Google (exige conta de anúncios)
- Ubersuggest, Ahrefs, SEMrush (pagos)

**Para cada keyword candidata, avaliar:**
- Volume estimado de busca/mês
- Dificuldade (quem rankeia)
- Intenção clara
- Fit com o que o escritório resolve

**Estratégia:** priorize **long tail** (3-5 palavras). Ex: "como calcular aposentadoria por tempo de contribuição 2026" é melhor que "aposentadoria".

### Bloco 3 — Estruturar o artigo SEO

**Anatomia:**

**Título (H1):**
- Keyword principal no início
- Até 60 caracteres
- Promete o que o conteúdo entrega (sem prometer resultado!)

**Meta description:**
- 150-160 caracteres
- Inclui keyword + benefício
- CTA suave ("saiba mais", "entenda como")

**URL:**
- Curta, com keyword
- Separada por hífens
- Ex: /aposentadoria-tempo-contribuicao-2026

**Introdução (primeiros 2-3 parágrafos):**
- Keyword na primeira linha (natural)
- Contextualiza o problema
- Promete o que o artigo vai responder

**Estrutura de H2/H3:**
- Cada H2 responde a uma sub-pergunta
- H3 segmenta dentro de cada H2
- Keywords relacionadas nas subseções

**Extensão:**
- Blog jurídico: 1500-3000 palavras
- Landing page: 600-1200 palavras
- Página institucional: 800-1500 palavras

**Elementos auxiliares:**
- Lista, tabela, bullet (melhora escaneabilidade)
- Imagens com ALT text descritivo
- FAQ estruturado no final (Schema FAQPage)

### Bloco 4 — Internal linking

Para cada artigo novo:
- Aponte para 2-5 artigos existentes relacionados
- Receba links de artigos que façam sentido
- Pilares → clusters (pillar page aponta pra artigos profundos)

### Bloco 5 — Compliance OAB em SEO

Checklist:
- [ ] Título não promete ganho ("Ganhe seu direito..." → não)
- [ ] Não usa palavras mercantis no título ("comprar", "desconto", "oferta")
- [ ] Meta description informativa, não captadora
- [ ] CTA no final é orientativo ("fale com um especialista" vs. "contrate agora")
- [ ] Não compara com outros escritórios
- [ ] Não prometeu ranking ou "ganho garantido" de causa

### Bloco 6 — Checklist técnico

- [ ] Título tem keyword principal
- [ ] Meta description preenchida
- [ ] URL limpa com keyword
- [ ] H1 único
- [ ] Hierarquia H2/H3 consistente
- [ ] Imagens com ALT
- [ ] Internal links (2-5)
- [ ] Mobile-friendly
- [ ] Peso da página < 2MB
- [ ] Schema FAQPage ou Article quando aplicável

## Gerando o entregável

Use `references/template-briefing-seo.md`. Entregue:
- Keyword principal + secundárias
- Intenção de busca
- Título + meta description (2-3 variações)
- Estrutura H1/H2/H3
- Internal links sugeridos
- Checklist técnico

## Integração com skills downstream

SEO alimenta:
- `criar-copy` (escreve o corpo do artigo seguindo a estrutura)
- `criar-criativos` (briefing do banner do artigo)
- `distribuicao-multiplataforma` (republicar trechos em redes)

## Armadilha comum

**Otimizar pra keyword que ninguém pesquisa.** "Ação revisional de benefício previdenciário" tem 100 buscas/mês. "Revisão da aposentadoria" tem 30.000. Fale a língua do cliente — não a sua.
