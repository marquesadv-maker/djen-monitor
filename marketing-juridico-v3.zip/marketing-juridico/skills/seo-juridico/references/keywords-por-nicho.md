# Keywords Long Tail por Nicho Jurídico

Catálogo de palavras-chave reais (linguagem leiga) para começar a mapear oportunidades. Números aproximados, sempre validar com ferramenta.

---

## Previdenciário

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| revisão da aposentadoria | 40k/mês | alta |
| como calcular aposentadoria por tempo de contribuição | 10k/mês | média |
| bpc loas como solicitar | 22k/mês | média |
| quem tem direito ao bpc | 18k/mês | média |
| aposentadoria especial professor | 8k/mês | média |
| revisão vida toda quem tem direito | 12k/mês | alta |
| auxílio-doença quanto tempo demora | 9k/mês | média |
| pente fino do inss 2026 | 5k/mês | baixa |

---

## Trabalhista (empregado)

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| demitido sem justa causa direitos | 30k/mês | alta |
| rescisão indireta como pedir | 6k/mês | média |
| horas extras não pagas o que fazer | 8k/mês | média |
| assédio moral no trabalho provas | 7k/mês | média |
| estabilidade gestante contrato temporário | 3k/mês | baixa |
| danos morais trabalho quanto posso receber | 11k/mês | alta |

---

## Família

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| como pedir pensão alimentícia | 20k/mês | alta |
| divórcio quanto custa | 15k/mês | alta |
| guarda compartilhada como funciona | 18k/mês | alta |
| inventário extrajudicial passo a passo | 9k/mês | média |
| alienação parental o que fazer | 7k/mês | média |
| partilha de bens união estável | 6k/mês | média |

---

## Consumidor

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| plano de saúde negou cirurgia o que fazer | 12k/mês | média |
| negativação indevida como provar | 8k/mês | média |
| voo atrasado tenho direito a indenização | 10k/mês | média |
| compra online não entregue o que fazer | 11k/mês | média |
| banco cobrou juros abusivos | 6k/mês | média |
| dano moral consumidor valor | 9k/mês | alta |

---

## Tributário (PF / PJ)

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| execução fiscal o que fazer | 8k/mês | média |
| como recuperar imposto pago a maior | 5k/mês | média |
| simples nacional limite 2026 | 12k/mês | alta |
| darf em atraso como pagar | 14k/mês | alta |
| parcelar dívida receita federal | 10k/mês | alta |

---

## Imobiliário

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| usucapião como funciona | 15k/mês | alta |
| atraso entrega imóvel direitos | 8k/mês | média |
| distrato imóvel na planta | 6k/mês | média |
| contrato de aluguel clausulas abusivas | 5k/mês | média |
| regularização imóvel rural | 4k/mês | baixa |

---

## Bancário / Superendividamento

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| superendividamento lei nova | 7k/mês | média |
| revisão de contrato bancário | 12k/mês | alta |
| negativação após acordo | 4k/mês | baixa |
| pix golpe como recuperar | 18k/mês | média |

---

## Saúde (paciente)

| Keyword | Volume estim. | Dificuldade |
|---|---|---|
| plano de saúde negou medicamento | 9k/mês | média |
| sus medicamento de alto custo | 7k/mês | média |
| erro médico como provar | 11k/mês | alta |
| cirurgia bariátrica plano de saúde | 14k/mês | alta |

---

## Estratégia de priorização

1. **Volume médio (5k-15k/mês) + dificuldade média** → sweet spot para começar
2. **Baixa dificuldade (mesmo com volume baixo)** → ganhos rápidos
3. **Alta dificuldade + alto volume** → longo prazo, precisa de autoridade
4. **Cauda longa hiper-específica** → 100-500 buscas/mês mas converte muito

---

## Como descobrir suas próprias keywords

1. Vá no Google e digite a keyword inicial — **anote o autocomplete**
2. Veja "People Also Ask" na SERP
3. Role até o final e veja "Searches related"
4. Use AnswerThePublic (gratuito limitado)
5. Pergunte a clientes reais: "o que você pesquisou antes de me procurar?"

A última é a melhor fonte. Cliente real = linguagem real.
