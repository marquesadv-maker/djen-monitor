# Checklist On-Page SEO Jurídico

Auditoria por artigo. Passe por todos os itens antes de publicar.

---

## Técnico

- [ ] **HTTPS ativo** no site
- [ ] **Mobile responsivo** (teste no próprio celular)
- [ ] **Velocidade <3s** (teste em PageSpeed Insights)
- [ ] **Peso da página <2MB**
- [ ] **Sem broken links** (internos e externos)
- [ ] **Sitemap.xml** atualizado
- [ ] **Robots.txt** permite rastreamento
- [ ] **Canonical tag** presente (se aplicável)

---

## Título (H1)

- [ ] H1 único na página
- [ ] Keyword principal no H1
- [ ] Até 60 caracteres
- [ ] Keyword preferencialmente no início
- [ ] Não repete título em nenhum H2

---

## Meta Description

- [ ] Preenchida (não deixar em branco)
- [ ] 150-160 caracteres
- [ ] Keyword principal incluída (natural)
- [ ] CTA suave no final
- [ ] Não prometer resultado ("garanta")

---

## URL

- [ ] Curta (até 75 caracteres)
- [ ] Keyword principal incluída
- [ ] Separada por hífens (-)
- [ ] Sem parâmetros (?id=, &utm)
- [ ] Tudo em minúsculo
- [ ] Sem caracteres especiais

---

## Estrutura de conteúdo

- [ ] Hierarquia H1 → H2 → H3 respeitada
- [ ] Keyword na primeira linha da introdução
- [ ] Keywords secundárias distribuídas naturalmente
- [ ] Parágrafos de 2-4 linhas
- [ ] Uso de listas e tabelas para escaneabilidade
- [ ] Mínimo 1200 palavras (artigo completo)

---

## Imagens

- [ ] Todas as imagens têm ALT text
- [ ] ALT descreve a imagem (não é keyword stuffing)
- [ ] Peso otimizado (WebP ou JPG 80%)
- [ ] Nome do arquivo descritivo (revisao-aposentadoria.jpg, não IMG_1234.jpg)
- [ ] Largura máxima 1200px no blog

---

## Links

- [ ] 2-5 internal links (para outros artigos/páginas)
- [ ] Anchor text descritivo (não "clique aqui")
- [ ] External links confiáveis (tribunais, leis, gov.br)
- [ ] External links com `rel="noopener"`
- [ ] Sem broken links

---

## Schema / Rich Snippets

- [ ] Article schema (para posts)
- [ ] FAQPage schema (se tem FAQ)
- [ ] LocalBusiness schema (página de contato)
- [ ] BreadcrumbList schema
- [ ] Validado em Rich Results Test do Google

---

## Experiência de leitura

- [ ] Índice navegável (para artigos longos)
- [ ] Espaçamento confortável
- [ ] Contraste adequado
- [ ] Sem pop-ups agressivos
- [ ] CTA visível mas não invasivo

---

## Compliance OAB

- [ ] Título não promete ganho
- [ ] Não compara com concorrente
- [ ] CTA é orientativo ("fale com um especialista")
- [ ] Sem linguagem mercantil
- [ ] Identificação da autoria + OAB (no rodapé ou card do autor)

---

## Pós-publicação

- [ ] Submeter URL no Google Search Console
- [ ] Divulgar em redes sociais
- [ ] Enviar na newsletter
- [ ] Monitorar ranking em 4-8 semanas
- [ ] Atualizar anualmente (ou quando lei mudar)
