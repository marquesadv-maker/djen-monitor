# Briefing SEO — [Tema do Artigo]

> Gerado pela skill `seo-juridico`.
> Tipo de página: [artigo blog / landing page / página institucional]
> Data: [data]

---

## Keyword principal

**Termo:** [ex: "revisão da aposentadoria"]
**Volume estimado:** [buscas/mês]
**Dificuldade:** [baixa / média / alta]
**Intenção:** [informacional / comparativa / transacional]

---

## Keywords secundárias (LSI)

1. [keyword relacionada]
2. [keyword relacionada]
3. [keyword relacionada]
4. [keyword relacionada]
5. [keyword relacionada]

---

## Perguntas "People Also Ask" a cobrir

1. [pergunta 1]
2. [pergunta 2]
3. [pergunta 3]
4. [pergunta 4]

---

## Título (H1) — 3 variações

**Opção A (keyword first):** [...]
**Opção B (benefício + keyword):** [...]
**Opção C (pergunta):** [...]

(Até 60 caracteres cada)

---

## Meta description — 2 variações

**Opção A:** [150-160 caracteres]
**Opção B:** [150-160 caracteres]

---

## URL sugerida

/[slug-com-keyword]

---

## Estrutura H2/H3

**H1:** [título final]

- **H2:** [subseção 1 — responde pergunta X]
  - H3: [sub-ponto]
  - H3: [sub-ponto]
- **H2:** [subseção 2 — responde pergunta Y]
  - H3: [sub-ponto]
- **H2:** [subseção 3 — responde pergunta Z]
- **H2:** Perguntas frequentes (FAQ)
  - H3: [pergunta 1]
  - H3: [pergunta 2]
- **H2:** Conclusão

---

## Internal links sugeridos

Aponta de dentro deste artigo para:
1. /[artigo existente 1]
2. /[artigo existente 2]
3. /[página institucional]

Deveria receber link de:
1. /[artigo pilar sobre o tema]

---

## Extensão alvo

[1500-3000] palavras

---

## Elementos adicionais

- [ ] 1 tabela (comparação ou passo a passo)
- [ ] 1 lista bullet
- [ ] 1 FAQ estruturado (Schema)
- [ ] 2-3 imagens com ALT
- [ ] 1 CTA orientativo no final

---

## Checklist OAB

- [ ] Título não promete ganho
- [ ] Meta description informativa (não captadora)
- [ ] Sem comparação com escritórios
- [ ] CTA final orientativo
- [ ] Sem palavras mercantis ("desconto", "oferta")

---

## Checklist técnico

- [ ] H1 único
- [ ] Keyword na intro (1os 100 caracteres)
- [ ] Keyword em 1 H2
- [ ] Imagens com ALT
- [ ] Internal links
- [ ] URL limpa
- [ ] Schema marcado (FAQPage ou Article)
