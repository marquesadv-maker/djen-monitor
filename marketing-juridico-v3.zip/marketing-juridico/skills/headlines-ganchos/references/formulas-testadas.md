# Fórmulas de Gancho Testadas para Jurídico

Biblioteca de fórmulas com exemplos adaptados a cada nicho. Use como baralho.

---

## Fórmula 1 — Pergunta direta

**Estrutura:** "[pergunta que ativa a dor da persona]?"

- "Você sabe quanto o INSS pagou a menos na sua aposentadoria?"
- "Sua empresa te demitiu por justa causa sem provar?"
- "Quem mora no imóvel que não é seu há mais de 5 anos?"
- "Seu banco te cobrou juros que você não entende?"

---

## Fórmula 2 — Número + benefício

**Estrutura:** "[N] [coisas] que [persona] precisa saber sobre [tema]"

- "3 direitos do aposentado que o INSS não conta"
- "5 verbas rescisórias que a empresa pode ter esquecido"
- "7 situações em que o plano de saúde NÃO pode negar cobertura"
- "4 erros no divórcio que custam caro depois"

---

## Fórmula 3 — Mito × verdade

**Estrutura:** "Mito: [crença errada]. Verdade: [o que é de fato]"

- "Mito: processo contra o INSS demora 10 anos. Verdade: [...]"
- "Mito: quem pede justa causa não recebe nada. Verdade: [...]"
- "Mito: alimentando divide 50/50. Verdade: [...]"

---

## Fórmula 4 — Erro que [persona] comete

**Estrutura:** "O erro [mais comum / mais caro / mais silencioso] de quem [ação da persona]"

- "O erro mais comum de quem vai se aposentar (e custa caro)"
- "O erro silencioso que trabalhador PJ comete na demissão"
- "O erro que mães solo cometem no acordo de pensão"

---

## Fórmula 5 — Dado chocante

**Estrutura:** "[estatística específica] — e ninguém te conta"

- "8 em cada 10 aposentadorias são calculadas abaixo do devido"
- "Mais de 60% dos contratos bancários têm cláusulas abusivas"
- "1 a cada 4 divórcios tem partilha errada"

(Use dados reais. Nunca invente estatística.)

---

## Fórmula 6 — Revelação / o que ninguém conta

**Estrutura:** "O que [instituição/profissão] não te avisa quando [situação]"

- "O que o INSS não avisa quando você se aposenta"
- "O que o RH não conta quando você é demitido"
- "O que o banco esconde na hora de fechar o financiamento"

---

## Fórmula 7 — Contraste antes × depois

**Estrutura:** "Antes: [situação ruim]. Depois: [situação melhor]."

- "Antes da revisão: R$ 1.800. Depois: R$ 2.900. Todo mês."
- "Sem planejamento sucessório: 2 anos de briga. Com: 3 meses."

(Cuidado OAB: não exponha caso real identificável. Use cenário genérico.)

---

## Fórmula 8 — Urgência / prazo

**Estrutura:** "Você tem até [prazo] para [ação]. Depois, prescreve / perde."

- "Você tem 5 anos pra pedir essa revisão. Depois, prescreve."
- "Até [data], trabalhador demitido pode pedir diferenças em 2 anos"
- "A mudança entra em vigor em [data]. Depois disso, o direito muda."

---

## Fórmulas extras (avançadas)

### Fórmula 9 — Comparação de cenários
"Se você [situação A], faça X. Se [situação B], faça Y. A diferença custa [N]."

### Fórmula 10 — Pergunta retórica + provocação
"Se seu plano de saúde negasse cirurgia da sua mãe, você aceitaria calado?"

### Fórmula 11 — Lista negativa
"3 coisas que NÃO contam como tempo de contribuição"

### Fórmula 12 — Curiosidade na incompletude
"A decisão do STF que mudou tudo pra quem é aposentado (e quase ninguém viu)"

---

## Ganchos que NÃO usar (violação OAB)

❌ "Você tem direito a R$ 50 mil e não sabe"
❌ "Vou te fazer ganhar seu processo"
❌ "O melhor advogado de [cidade] em [área]"
❌ "Garanto sua indenização em 60 dias"
❌ "NÃO contrate esse tipo de advogado"
❌ "Seus direitos estão sendo roubados" (sensacionalismo)

---

## Teste rápido de gancho

Antes de finalizar, pergunte:

1. Em 3 segundos, a persona entende do que se trata? ✅/❌
2. Tem elemento concreto (número, nome, cenário)? ✅/❌
3. Ativa alguma emoção? ✅/❌
4. Passa no filtro OAB? ✅/❌
5. É diferente do que o concorrente já postou? ✅/❌

3 ou mais ❌ → refaz.
