# Banco de Ganchos — [Título da Pauta]

> Gerado pela skill `headlines-ganchos`.
> Plataforma-alvo: [Instagram / LinkedIn / YouTube / blog / email]
> Formato: [capa carrossel / legenda / título artigo / assunto email]
> Persona: [persona primária]

---

## Núcleo emocional da pauta

- **Emoção ativada:** [medo / raiva / alívio / surpresa / esperança]
- **Crença quebrada:** [o que a pessoa achava e não é]
- **Perda invisível:** [o que ela perde sem saber]
- **Dado/número chave:** [...]

---

## Top 10 ganchos ranqueados

### 🥇 #1 — [Gancho]
- **Fórmula:** [pergunta / número / mito / erro / dado / revelação / contraste / urgência]
- **Plataforma ideal:** [...]
- **Por que funciona:** [...]

### 🥈 #2 — [Gancho]
- **Fórmula:** [...]
- **Plataforma ideal:** [...]

### 🥉 #3 — [Gancho]
[repetir]

### #4 a #10
[repetir]

---

## Sugestão de A/B test

- **Versão A:** [gancho #1]
- **Versão B:** [gancho #4 — fórmula diferente]
- **Hipótese:** [qual tende a ganhar e por quê]
- **Métrica de decisão:** [retenção nos primeiros 3s do reels / taxa de clique do email / salvamentos do carrossel]

---

## Checklist OAB

- [ ] Nenhum gancho promete resultado
- [ ] Nenhum garante indenização/ganho
- [ ] Sem sensacionalismo excessivo
- [ ] Sem captação mercantilizada
- [ ] Sem comparação com concorrente
