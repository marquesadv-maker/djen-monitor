---
name: headlines-ganchos
description: Cria headlines, ganchos de abertura, títulos e primeiras linhas que fazem o leitor parar de rolar. Entrega 5-10 variações por pauta, com fórmulas testadas (pergunta, dado, mito, lista, erro, revelação) adaptadas para jurídico e filtradas por OAB. Use SEMPRE que o advogado disser: "criar gancho", "headline do post", "título do artigo", "primeira linha", "como abrir o post", "gancho do reels", "hook", "chamada", "o que colocar no slide de capa", "manchete", "título que converte", "título de email". Fornece matéria-prima pra skill criar-copy e roteiros-video.
---

# Headlines e Ganchos

Esta skill produz **5-10 variações** de gancho/headline para uma mesma pauta, permitindo ao advogado escolher o que melhor conecta com persona e plataforma. 80% do engajamento de um post é definido pela primeira linha.

## Por que tratar separado de copy

Gancho é um músculo próprio. Mesmo redator bom de copy escreve gancho fraco se não aplicar fórmulas específicas. Isolar a criação de headlines força a variedade e melhora a taxa de acerto.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — tom de voz
- `personas.md` — vocabulário e dores da persona
- `linha-editorial.md` — restrições e formatos

## Workflow

### Bloco 1 — Entender o objetivo do gancho

Confirme:
- **Plataforma:** Instagram / LinkedIn / YouTube / blog / email?
- **Formato:** capa de carrossel / primeira linha de legenda / título de artigo / assunto de email / slide 1 de reels?
- **Persona:** quem deve parar de rolar ao ler?
- **Ângulo desejado:** dor / autoridade / curiosidade?

### Bloco 2 — Extrair o "núcleo emocional" da pauta

Responda internamente:
- **Qual emoção essa pauta ativa?** (medo, raiva, alívio, surpresa, esperança)
- **Qual crença a pauta quebra?** (o que a pessoa achava e não é)
- **Qual perda a pessoa está tendo sem saber?** (o prejuízo invisível)
- **Qual número/dado específico pode entrar?**

Sem ter clareza disso, os ganchos saem genéricos.

### Bloco 3 — Aplicar as 8 fórmulas

Gere **ao menos 1 gancho por fórmula** (selecione as 5-10 melhores no fim):

**Fórmula 1 — Pergunta direta**
"Você sabe quanto perdeu por não revisar sua aposentadoria?"

**Fórmula 2 — Número + benefício**
"3 direitos do aposentado que o INSS não conta pra você"

**Fórmula 3 — Mito × verdade**
"Mito: quem entra na Justiça contra o INSS demora 10 anos. Verdade: [...]"

**Fórmula 4 — Erro que [persona] comete**
"O erro mais comum de quem pede aposentadoria (e custa caro)"

**Fórmula 5 — Dado chocante**
"8 em cada 10 aposentadorias têm valor calculado errado"

**Fórmula 6 — Revelação / o que ninguém conta**
"O que o INSS não vai te avisar quando você se aposentar"

**Fórmula 7 — Contraste antes × depois**
"Antes: benefício de R$ 1.800. Depois da revisão: R$ 2.900."

**Fórmula 8 — Urgência/prazo**
"Você tem até [data] pra pedir esse direito. Depois, prescreve."

### Bloco 4 — Filtrar por OAB

Descarte qualquer gancho que:
- Prometa resultado ("vou te fazer ganhar")
- Garanta indenização
- Use linguagem sensacionalista de mais ("VOCÊ VAI FICAR CHOCADO")
- Capture cliente mercantilmente ("quero ser seu cliente hoje")
- Compare com escritório concorrente

Promessa camuflada também cai fora. "Veja como garantir seu direito" ≈ promessa.

### Bloco 5 — Ranquear

Ordene os 10 ganchos por:
1. **Força emocional** (puxa a atenção?)
2. **Clareza** (entende em 2 segundos?)
3. **Especificidade** (tem número, nome, cenário concreto?)
4. **Fit com persona**
5. **Fit com plataforma**

Entregue top 5-10 ranqueados, indicando qual fórmula foi usada em cada.

## Gerando o entregável

Use `references/template-banco-ganchos.md`. Apresente:
- 5-10 ganchos ranqueados
- Fórmula usada em cada
- Plataforma mais indicada
- Sugestão de teste A/B (2 ganchos pra alternar)

## Integração com skills downstream

Os ganchos viram input para:
- `criar-copy` (usa o gancho vencedor como abertura)
- `roteiros-video` (usa como primeira frase do reels/vídeo)
- `criar-criativos` (usa como texto da capa do carrossel)

## Armadilhas comuns

1. **Clickbait vazio.** Gancho forte que não entrega no corpo destrói confiança.
2. **Genérico demais.** "Você sabia que tem direitos?" — todo mundo tem, isso não diz nada.
3. **Jargão jurídico no gancho.** "Ação revisional de benefício previdenciário" afasta leitor leigo.
4. **Gancho que presume conhecimento.** "Aplicação do art. 96 da Lei 8213/91" — só quem já sabe entende.
