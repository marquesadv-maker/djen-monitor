---
name: gestao-crise-reputacao
description: Gerencia crises de reputação online envolvendo escritório de advocacia — avaliação negativa, print viralizado, comentário hostil, reclamação no Google/Reclame Aqui, ex-cliente insatisfeito, exposição indevida em mídia. Define protocolo de resposta, tom, canal e prazo. Use quando o advogado mencionar: "crise de imagem", "avaliação negativa", "reclamação no Google", "print viralizou", "cliente falando mal", "reputação", "responder crítica", "dano à imagem", "cliente insatisfeito postou", "Reclame Aqui", "tá dando ruim".
---

# Gestão de Crise de Reputação

Protocolo para responder incidentes reputacionais de escritório jurídico — calibrado para OAB (não pode revelar detalhes do caso) + plataformas digitais.

## Princípio central

Em crise, **velocidade > perfeição**, mas **sigilo profissional é inegociável**. Nunca revelar detalhes de caso público, nunca expor cliente, nunca confirmar relação profissional sem autorização.

## Pré-requisitos

Leia:
- `manual-marca.md` — tom do escritório
- Contexto do incidente (print, link, contexto)

## Workflow

### Bloco 1 — Classificar severidade

| Nível | Exemplo | Prazo resposta |
|---|---|---|
| **Baixo** | 1 avaliação 1-estrela sem texto | 48h |
| **Médio** | Reclamação detalhada no Google/site | 24h |
| **Alto** | Post viral, print em grupos, repercussão em rede | 6-12h |
| **Crítico** | Matéria jornalística, processo público, exposição de terceiros | Imediato (2h) |

### Bloco 2 — Triagem pré-resposta

Antes de responder, confirmar:
- [ ] Pessoa é cliente/ex-cliente do escritório? (verificar CRM)
- [ ] Reclamação tem fundamento factual? (investigar internamente)
- [ ] Há risco de processo? (difamação, calúnia, contrato)
- [ ] Revelar que é cliente viola sigilo?
- [ ] Advogado responsável pelo caso foi notificado?

**Nunca responder sem passar pelos 5 itens.**

### Bloco 3 — Definir canal e tom

**Canal de resposta:**
- Público (mesmo canal) → defesa da reputação + educação
- Privado (DM/email) → resolver conflito real
- Ambos → resposta pública genérica + convite privado

**Tom:**
- Sóbrio, nunca defensivo
- Não usar ironia, não usar sarcasmo
- Não contra-atacar cliente
- Posicionar escritório como profissional que acolhe

### Bloco 4 — Arquitetura da resposta pública

**Modelo OAB-safe (4 partes):**

1. **Reconhecimento:** "Agradecemos o contato e lamentamos que sua experiência não tenha sido a esperada."
2. **Neutralidade:** "Por força do sigilo profissional, não comentamos casos específicos publicamente."
3. **Convite privado:** "Pedimos que entre em contato pelo canal [X] para que possamos ouvir com atenção."
4. **Assinatura:** Advogado responsável + OAB

### Bloco 5 — O que NÃO fazer

- ❌ Confirmar que a pessoa é cliente
- ❌ Revelar detalhes do caso (mesmo pra se defender)
- ❌ Responder com raiva / ironia
- ❌ Apagar comentário (aumenta a crise)
- ❌ Bloquear autor antes de responder publicamente
- ❌ Acionar advogado contra ex-cliente em cima da hora
- ❌ Pagar para remover review (ilegal + anti-ético)

### Bloco 6 — Escalonamento interno

| Severidade | Quem decide resposta |
|---|---|
| Baixo | Equipe marketing + 1 sócio |
| Médio | Sócio responsável + marketing |
| Alto | Todos os sócios |
| Crítico | Sócios + assessoria de imprensa/advogado externo |

### Bloco 7 — Pós-crise (48h depois)

- [ ] Documentar incidente (o que, onde, como respondido)
- [ ] Avaliar impacto (prints, repercussão, leads afetados)
- [ ] Atualizar playbook interno
- [ ] Treinar equipe se houve erro de processo

## Templates prontos

Ver `references/templates-resposta.md` para modelos por situação.

## Integração com skills

- Roda em paralelo com `qa-etico-oab` (resposta precisa passar)
- Alimenta `governanca-marketing` (aprendizado incorporado ao playbook)

## Armadilhas comuns

1. **Silêncio prolongado.** 72h sem resposta = multiplica a crise.
2. **Resposta emocional.** Raiva sincera vira print.
3. **Revelar detalhes para "se defender".** Sigilo profissional é absoluto.
4. **Ignorar review pequeno.** Acumula — vira padrão.
5. **Comprar reviews fake pra diluir.** OAB pune + plataforma pune.
