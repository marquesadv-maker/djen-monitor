# Protocolo de Escalonamento — Crise de Reputação

Fluxo interno de decisão desde a detecção até a resposta pública.

---

## Fase 1 — Detecção (0-30 min)

**Quem detecta:**
- Equipe de marketing (monitoramento de menções)
- Recepção/atendimento (cliente comenta)
- Sócios (alerta de terceiros)

**Ação imediata:**
- [ ] Capturar prints com data/hora
- [ ] Registrar URL
- [ ] Classificar severidade preliminar
- [ ] Acionar canal interno de crise

---

## Fase 2 — Triagem (30 min - 2h)

**Responsável:** Líder de marketing + 1 sócio

**Perguntas a responder:**
1. Autor é cliente? Ex-cliente? Desconhecido?
2. Conteúdo tem base factual?
3. Envolve processo/sigilo?
4. Qual o alcance atual?
5. Há terceiros citados?

**Output:** decisão de severidade final + canal de resposta

---

## Fase 3 — Redação de resposta

**Severidade Baixa (1 pessoa decide):**
- Marketing escreve → revisa com 1 sócio → publica

**Severidade Média:**
- Marketing escreve → sócio responsável aprova → QA ético → publica

**Severidade Alta:**
- Minuta elaborada em conjunto
- Todos sócios aprovam
- QA ético obrigatório
- Publicar em 6-12h

**Severidade Crítica:**
- Envolver assessoria de imprensa
- Envolver advogado externo (se cabível processo)
- Nota oficial formal
- Publicar em até 2h
- Monitorar continuamente por 48h

---

## Fase 4 — Pós-publicação

- [ ] Monitorar repercussão por 48-72h
- [ ] Responder comentários secundários (se houver)
- [ ] Não apagar comentários originais
- [ ] Registrar incidente em log interno
- [ ] Retrospectiva em até 7 dias

---

## Log de incidente (documentar sempre)

**Data:** [...]
**Detecção:** [quem / como]
**Autor:** [identificado / anônimo]
**Canal:** [...]
**Conteúdo:** [resumo]
**Severidade:** [...]
**Resposta publicada:** [link]
**Aprovação:** [quem aprovou]
**Tempo até resposta:** [horas]
**Resultado:** [...]
**Aprendizado:** [...]

---

## Canais de monitoramento contínuo

- Google Meu Negócio (reviews)
- Reclame Aqui
- Instagram (menções + comentários)
- Facebook (comentários + mensagens)
- LinkedIn
- TripAdvisor / Jurídico Certo
- Busca orgânica Google (nome do escritório + "reclamação")

**Frequência recomendada:** diária (automatizada) + revisão semanal manual.

---

## Sinais de crise iminente

- Pico de menções em 24h (>3x média)
- Comentário com alto engajamento em post antigo
- Print circulando em grupos de WhatsApp
- Perguntas de clientes sobre "aquela história"
- Queda súbita em leads/conversão
