# Templates de Resposta — Crise de Reputação

Modelos calibrados por tipo de incidente. Sempre adaptar ao tom do escritório.

---

## 1. Avaliação negativa sem contexto (1 estrela, sem texto)

**Público (Google/Facebook):**

> Agradecemos a avaliação. Lamentamos não ter registrado o contexto da sua experiência — gostaríamos de entender melhor. Pedimos que entre em contato pelo [email/WhatsApp] para que possamos conversar.
>
> Dra. [Nome] — OAB/[UF] [nº]

---

## 2. Reclamação detalhada de ex-cliente

**Público:**

> Agradecemos seu contato. Por respeito ao sigilo profissional, não comentamos casos específicos em ambiente público. Pedimos que nos procure pelo [canal] para que possamos ouvir com a atenção devida e buscar uma solução.
>
> Dra. [Nome] — OAB/[UF] [nº]

**Privado (paralelo):**

> Oi, [nome]. Acabei de ver seu comentário e quero conversar com você sobre isso. Pode me ligar no [número] ou me responder por aqui pra marcarmos um horário?

---

## 3. Comentário hostil de quem não é cliente

**Público:**

> Agradecemos o comentário. Nosso escritório mantém respeito à opinião pública e continua à disposição de quem precisar de orientação jurídica. Se quiser debater o tema em profundidade, estamos abertos ao diálogo por [canal].

---

## 4. Print viralizado (contexto incompleto)

**Público (em post próprio, não só comentário):**

> Tomamos conhecimento de uma publicação recente que envolveu menção ao nosso escritório. Por força do sigilo profissional e respeito aos envolvidos, não traremos detalhes do caso. Esclarecemos que atuamos dentro dos parâmetros éticos do Estatuto da Advocacia e do Código de Ética da OAB. Seguimos à disposição de quem queira nos conhecer melhor.
>
> Equipe [Escritório]

---

## 5. Reclame Aqui

**Resposta padrão (dentro do prazo):**

> Olá, [nome]. Recebemos sua manifestação e queremos entender o que aconteceu. Por respeito ao sigilo, não traremos detalhes do caso aqui, mas entramos em contato diretamente pelo seu e-mail cadastrado para alinharmos uma conversa.
>
> Escritório [Nome]

---

## 6. Matéria jornalística negativa

**Nota oficial (revista por advogado):**

> O escritório [Nome] tomou conhecimento da reportagem publicada em [data/veículo]. Por força do sigilo profissional e do dever de lealdade aos clientes, não comentaremos detalhes de casos específicos. Reafirmamos nosso compromisso com a ética profissional e os princípios que regem o exercício da advocacia. Estamos à disposição para esclarecimentos pelos canais oficiais do escritório.

---

## 7. Ex-advogado do escritório falando mal

**Interno:** consultar assessoria jurídica antes de responder publicamente.

**Público (se for responder):**

> Respeitamos o direito de manifestação. Divergências profissionais fazem parte de qualquer trajetória. Seguimos focados no trabalho técnico e no compromisso com nossos clientes.

---

## 8. Informação falsa circulando

**Público:**

> Esclarecemos que a informação [X] que tem circulado não corresponde à realidade. [Correção factual breve]. Mantemos compromisso com a transparência e estamos à disposição para esclarecimentos oficiais.

---

## Regras transversais

1. **Assinar sempre** — nome do advogado + OAB
2. **Máximo 4-5 linhas** — resposta concisa
3. **Zero ironia**
4. **Zero confirmação de relação profissional**
5. **Sempre oferecer canal privado**
6. **Revisar com sócio responsável antes de publicar**
