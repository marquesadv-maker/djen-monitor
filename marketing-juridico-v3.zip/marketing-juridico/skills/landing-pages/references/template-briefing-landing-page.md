# Briefing Landing Page — [Nome da LP]

> Gerado pela skill `landing-pages`.
> Tipo: [agendamento / captura de lead / download / webinar / contato]
> Persona-alvo: [...]
> Serviço ofertado: [...]

---

## Objetivo único

**Ação desejada:** [o que o visitante deve fazer]
**Métrica principal:** [taxa de conversão / leads/dia / agendamentos/mês]
**Meta inicial:** [X% de conversão ou N conversões/mês]

---

## Estrutura hierárquica

### 1. Hero (acima da dobra)
- **Headline (H1):** [texto]
- **Subheadline:** [texto]
- **CTA primário (texto do botão):** [texto]
- **Imagem/visual:** [descrição]

### 2. Seção "Você passa por isso?" (validação de dor)
- **Subtítulo:** [texto]
- **Bullets de dor:**
  1. [dor 1]
  2. [dor 2]
  3. [dor 3]
  4. [dor 4]

### 3. Como resolvemos (processo de atendimento)
- **Passo 1:** [nome + descrição curta]
- **Passo 2:** [...]
- **Passo 3:** [...]
- **Passo 4 (se houver):** [...]

### 4. Prova social (OAB-safe)
- **Depoimentos anonimizados:** [3 textos sem nome/foto]
- **Dados institucionais:** ["mais de X clientes atendidos"]
- **Publicações/imprensa:** [logos de onde apareceu]

### 5. Autoridade
- **Foto do advogado:** [link/descrição]
- **Nome + OAB:** [...]
- **Formação:** [...]
- **Especializações:** [...]
- **Tempo de atuação:** [...]
- **Publicações/Palestras:** [...]

### 6. FAQ
1. **Pergunta:** [...]
   **Resposta:** [...]
2. **Pergunta:** [...]
   **Resposta:** [...]
3. [repetir 5-8 vezes]

### 7. CTA final
- **Headline reforço:** [texto]
- **CTA (botão):** [texto]
- **Formulário:** [campos listados abaixo]

### 8. Rodapé
- **Endereço do escritório:** [...]
- **Telefone/WhatsApp:** [...]
- **Email:** [...]
- **OAB (nº da inscrição):** [...]
- **Política de privacidade:** [link]
- **Termos LGPD:** [link]

---

## Formulário

**Campos:**
- [ ] Nome completo
- [ ] WhatsApp
- [ ] Email (se captura de lead)
- [ ] Assunto/Mensagem (textarea, opcional)
- [ ] Aceite LGPD ✓ (obrigatório)

**Destino pós-envio:**
- [ ] Página de obrigado (thank you page)
- [ ] WhatsApp automático
- [ ] Email de confirmação
- [ ] Agendamento direto (Calendly/Cal.com)

---

## Elementos de confiança (OAB-safe)

- [ ] Foto do advogado
- [ ] Número OAB visível
- [ ] Logos de publicações (se houver)
- [ ] Depoimentos ANONIMIZADOS
- [ ] Certificado de segurança SSL
- [ ] Política de privacidade
- [ ] Selo LGPD

**Não incluir:**
- [ ] Fotos/nomes de clientes reais
- [ ] "X% de vitórias"
- [ ] Valores de indenização conquistada
- [ ] Comparação com outros escritórios

---

## Checklist técnico

- [ ] Mobile-first
- [ ] Carregamento <3s
- [ ] Botões ≥44px altura
- [ ] Pixel de tracking instalado
- [ ] GA4 configurado
- [ ] Aviso de cookies LGPD
- [ ] Schema Attorney + LocalBusiness

---

## Checklist OAB

- [ ] Headline não promete resultado
- [ ] Subheadline informativa (não mercantil)
- [ ] CTA orientativo ("agendar consulta")
- [ ] Zero promessa de ganho
- [ ] Zero comparação com concorrente
- [ ] Depoimentos anonimizados
- [ ] Inscrição OAB visível

---

## Métricas para monitorar

- Taxa de conversão da LP
- Tempo médio na página
- Scroll depth
- Cliques em CTA (primário e final)
- Origem do tráfego (orgânico, pago, social)
- Taxa de abandono de formulário
