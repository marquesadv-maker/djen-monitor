# Padrões de Copy para LPs Jurídicas

Biblioteca de headlines, subheadlines e CTAs que convertem dentro da OAB. Use como banco.

---

## Headlines (H1) por tipo de serviço

### Previdenciário — Revisão
✅ "Revisão de aposentadoria: descubra se você tem direito a receber mais"
✅ "Aposentado? Entenda se sua aposentadoria foi calculada corretamente"
❌ "Receba o dinheiro que o INSS te deve" (promessa)

### Trabalhista — Demissão
✅ "Foi demitido? Entenda seus direitos antes de assinar qualquer coisa"
✅ "Demissão por justa causa: saiba como contestar"
❌ "Ganhe sua rescisão hoje" (mercantil)

### Família — Divórcio
✅ "Divórcio com menos conflito: orientação jurídica estratégica"
✅ "Guarda compartilhada: entenda como funciona na prática"
❌ "Resolva seu divórcio rápido" (promessa implícita)

### Consumidor — Plano de saúde
✅ "Plano de saúde negou cobertura? Saiba o que a lei determina"
❌ "Obrigamos o plano a cobrir" (comparativo e promessa)

---

## Subheadlines (apoio)

Estruturas testadas:
- "Mais de [X] anos de atuação em [área]"
- "Equipe especializada em [subárea específica]"
- "Atendimento presencial em [cidade] e online em todo o Brasil"
- "Escritório com foco exclusivo em [nicho]"
- "Processos acompanhados do início ao fim, com transparência e clareza"

---

## CTAs primários (botões)

**Para agendamento:**
- "Agendar consulta"
- "Falar com um advogado"
- "Agendar conversa inicial"
- "Marcar atendimento"

**Para captura de lead (material):**
- "Baixar guia gratuito"
- "Receber o checklist"
- "Quero o e-book"
- "Acessar agora"

**Para webinar:**
- "Quero participar"
- "Garantir minha vaga"
- "Reservar lugar"
- "Inscrever-se"

**Para contato:**
- "Entrar em contato"
- "Enviar mensagem"
- "Falar pelo WhatsApp"

❌ NUNCA: "Contrate agora", "Ganhe seu processo", "Resolva já"

---

## Bullets de dor (seção validação)

Formato: "Você [ação/sentimento da persona]?"

**Exemplos:**
- "Você se sente perdido diante das regras do INSS?"
- "Você assinou algo no momento da demissão sem ler com calma?"
- "Você tentou entrar em contato com o plano de saúde e foi ignorado?"
- "Você quer se divorciar mas tem medo de brigas sobre os filhos?"

Regra: cada bullet = 1 emoção/situação reconhecível.

---

## Textos de processo (3-4 etapas)

Estrutura didática:

**Etapa 1 — [Nome]**
Breve descrição (1-2 linhas) do que acontece nessa etapa.

**Etapa 2 — [Nome]**
[...]

**Etapa 3 — [Nome]**
[...]

**Exemplo (consulta previdenciária):**

1. **Análise inicial** — Conversamos sobre sua situação e reunimos seus documentos.
2. **Cálculo detalhado** — Verificamos tempo de contribuição e valores.
3. **Estratégia** — Apresentamos as opções possíveis com base no seu caso.
4. **Acompanhamento** — Você decide os próximos passos com clareza.

---

## Depoimentos anonimizados (OAB-safe)

Formato seguro:
- Sem nome real
- Sem foto
- Sem identificação de caso
- Foco na experiência de atendimento, não no resultado

**Exemplos:**

✅ "Fui atendida com respeito, me explicaram cada etapa sem juridiquês. Recomendo." — M.S., aposentada

✅ "O escritório me orientou com paciência, mesmo eu fazendo muitas perguntas. Senti segurança." — J.R., trabalhador

❌ "Ganhei R$ 80 mil de indenização graças ao escritório" (valor + resultado)
❌ "O escritório X é o melhor de [cidade]" (comparativo)
❌ "Foto + nome real + valor do processo" (múltiplas violações)

---

## FAQ recorrente (5-8 perguntas)

Perguntas que toda persona faz:

1. "Quanto custa a consulta?"
2. "Quanto tempo demora um processo como o meu?"
3. "O atendimento é presencial ou online?"
4. "Vocês atendem em todo o Brasil?"
5. "Como são os honorários?"
6. "Preciso levar documentos na primeira consulta?"
7. "Vocês emitem nota fiscal?"
8. "Qual o prazo para me responder depois do contato?"

Respostas: 2-4 linhas, tom direto.

---

## Rodapé obrigatório

**Elementos:**
- Razão social do escritório
- Nº inscrição OAB (do responsável ou sociedade)
- Endereço físico
- Telefone/WhatsApp
- Email institucional
- Link política de privacidade
- Link termos LGPD
- Copyright + ano

**Exemplo:**
> [Nome do Escritório] — OAB/[UF] [número]
> [Endereço completo]
> WhatsApp: [número] | Email: [contato@]
> [Política de Privacidade] | [LGPD]
> © 2026 — Todos os direitos reservados
