---
name: landing-pages
description: Estrutura landing pages jurídicas de alta conversão — briefing, hierarquia de seções, copy orientada a ação, prova social compliant (sem violação OAB), formulário calibrado e elementos de confiança. Use SEMPRE que o advogado mencionar: "landing page", "página de captura", "página de conversão", "página do site", "página de serviço", "página institucional", "página da área de atuação", "LP", "site do escritório", "página de agendamento", "página de contato". Cobre LPs de serviço específico, institucional, isca de conversão (e-book, webinar).
---

# Landing Pages Jurídicas

Esta skill estrutura landing pages do escritório com foco em **conversão** (lead, agendamento, contato) respeitando OAB. Entrega briefing completo: hierarquia de seções, copy, CTA, prova social compliant, formulário.

## Por que LP é diferente de site institucional

- **Objetivo único:** cada LP tem 1 ação desejada
- **Sem menu de distração:** minimiza fuga
- **Copy orientada a dor/benefício:** não é "quem somos"
- **Elementos de confiança calibrados:** autoridade sem exagero
- **Mensurabilidade:** taxa de conversão é o KPI

## Pré-requisitos

Leia antes:
- `personas.md` — dor e linguagem
- `produto-nicho.md` — serviço que a LP está oferecendo
- `manual-marca.md` — visual e tom

## Workflow

### Bloco 1 — Definir objetivo único da LP

Toda LP tem **1 objetivo**. Escolha:
- **Agendamento de consulta** (direto)
- **Captura de lead** (email/WhatsApp em troca de material)
- **Contato geral** (formulário amplo)
- **Inscrição em webinar/live**
- **Download de e-book/checklist**

Se tentar fazer 2 ao mesmo tempo, a conversão cai pela metade.

### Bloco 2 — Mapear estrutura hierárquica

**Estrutura padrão (8 seções):**

1. **Hero (acima da dobra)**
   - Headline (tese central)
   - Subheadline (expansão)
   - CTA primário
   - Imagem/vídeo/banner

2. **Dor/problema (validação)**
   - "Você passa por isso?"
   - 3-5 bullets da dor da persona

3. **Solução (como o escritório resolve)**
   - Processo de atendimento em 3-4 etapas
   - Diferencial (sem prometer resultado)

4. **Prova social** (CUIDADO OAB)
   - Depoimentos ANONIMIZADOS (sem foto, sem nome de cliente)
   - Ou: cases genéricos ("atendemos +500 famílias")
   - Ou: reconhecimento de imprensa, publicações, palestras

5. **Autoridade do advogado**
   - Foto do advogado
   - Credenciais (OAB, formação, especialização)
   - Tempo de atuação
   - Publicações, livros

6. **FAQ**
   - 5-8 perguntas que atrasam a decisão
   - Respostas claras e curtas

7. **CTA final**
   - Reforço da ação
   - Formulário completo ou botão de agendamento

8. **Rodapé**
   - Contato, endereço, inscrição OAB, política de privacidade/LGPD

### Bloco 3 — Escrever a copy da hero

**Headline (H1):**
- Foca no benefício ou resultado que a persona quer
- Não promete resultado de processo
- Específica (evita genérico)

Exemplo OK: "Orientação especializada em revisão de aposentadoria do INSS"
Exemplo ruim: "Receba o que o INSS te deve" (promessa)

**Subheadline:**
- Expande o headline com credibilidade
- "Mais de 10 anos de atuação / X advogados especializados / Atendimento em todo Brasil"

**CTA primário:**
- Ação clara e suave
- "Agendar consulta", "Falar com especialista", "Baixar guia grátis"
- NUNCA "contrate agora", "ganhe seu direito"

### Bloco 4 — Calibrar formulário

**Regra de ouro:** cada campo a mais reduz conversão ~10%.

**Agendamento:**
- Nome
- WhatsApp
- Assunto/dúvida (opcional, textarea curto)
- Aceite LGPD ✓

**Captura de lead (em troca de material):**
- Nome
- Email
- Aceite LGPD ✓

**Qualificação mais profunda (só quando preciso):**
- + Cidade/Estado
- + Tipo de caso

Nunca pedir CPF, RG, número de processo em formulário inicial.

### Bloco 5 — Elementos de confiança (OAB-safe)

**O que PODE:**
- Foto e credenciais do advogado
- Logo de publicações onde saiu (Conjur, revistas jurídicas)
- Número da OAB
- Certificações, especializações
- Tempo de atuação
- Áreas de atuação
- Depoimentos anonimizados (sem foto/nome/caso identificável)

**O que NÃO pode:**
- "Ganhamos 95% dos processos"
- "Cliente X recebeu R$ 50 mil"
- Foto/nome/depoimento de cliente identificado
- "Melhor escritório de [cidade]"
- Comparativo com concorrente

### Bloco 6 — Otimização técnica

Checklist:
- [ ] Carrega em <3s
- [ ] Mobile-first (70%+ do tráfego jurídico é mobile)
- [ ] Botões grandes e clicáveis (mínimo 44px altura)
- [ ] Pixel de tracking instalado (Meta, Google Ads se usar)
- [ ] Google Analytics / GA4 configurado
- [ ] Aviso de cookies LGPD
- [ ] Política de privacidade linkada
- [ ] SSL ativo
- [ ] Schema LocalBusiness + Attorney

## Gerando o entregável

Use `references/template-briefing-landing-page.md`. Entregue briefing completo que web designer/dev executa.

## Integração com skills downstream

Briefing alimenta:
- `criar-copy` (textos detalhados de cada seção)
- `criar-criativos` (banners e imagens)
- `captura-lead` (configuração do fluxo pós-formulário)
- `qa-etico-oab` (aprovação final)

## Armadilha comum

**Landing page lotada de informação.** LP não é site institucional. Regra: 1 objetivo, 1 CTA principal, 1 mensagem central. Tudo que não serve a converter → fora.
