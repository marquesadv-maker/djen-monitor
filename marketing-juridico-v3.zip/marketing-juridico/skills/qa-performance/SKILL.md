---
name: qa-performance
description: Avalia performance de peças e campanhas de marketing jurídico depois de publicadas — alcance, engajamento, cliques, conversão, CPL, qualidade de lead, ROI. Identifica o que funcionou, o que não funcionou, e recomenda ajustes. Use quando o advogado mencionar: "como foi o resultado", "análise de desempenho", "o que performou", "relatório de marketing", "ROI da campanha", "está dando retorno", "vale a pena continuar", "performance do conteúdo", "métricas do mês", "prestação de contas marketing".
---

# QA de Performance — Análise de Resultado

Foca em **resultado real** (lead, cliente, receita), não métricas de vaidade.

## Métrica que importa vs métrica de vaidade

| Vaidade (ignorar) | Resultado (olhar) |
|---|---|
| Curtidas | Leads qualificados |
| Alcance | Custo por lead (CPL) |
| Seguidores | Taxa conversão LP |
| Comentários | Agendamentos gerados |
| Impressões | Custo por cliente adquirido (CAC) |

## Pré-requisitos

Leia:
- `manual-marca.md` — metas do escritório
- Dados da plataforma (Meta, Google Ads, LinkedIn, analytics LP)
- Planilha de CRM/agendamentos

## Workflow

### Bloco 1 — Definir janela e escopo

- Período: [7 / 14 / 30 / 90] dias
- Canal: [orgânico / pago / ambos]
- Meta do período: [X leads ao CPL Y]

### Bloco 2 — Coletar métricas por funil

**Topo (atração):**
- Impressões / alcance
- CTR (anúncios)
- Taxa de engajamento (orgânico)

**Meio (interesse):**
- Cliques na LP
- Tempo na página
- Taxa de rejeição

**Fundo (conversão):**
- Leads capturados
- CPL
- Taxa conversão LP
- Agendamentos
- Consultas realizadas

**Pós (receita):**
- Clientes fechados
- Receita gerada
- CAC
- ROI (receita ÷ investimento)

### Bloco 3 — Diagnóstico por estágio

**Se topo está OK e meio cai:**
- Problema na LP (copy, promessa desalinhada, formulário)

**Se meio está OK e fundo cai:**
- Lead não qualificado
- Follow-up fraco
- Nutrição não funciona

**Se fundo está OK mas sem cliente:**
- Qualificação ruim
- Atendimento comercial do escritório

### Bloco 4 — Identificar top 3 e bottom 3

Liste as 3 peças de **melhor** e **pior** desempenho + hipótese do porquê:
- Melhor tema?
- Melhor formato?
- Melhor horário?
- Melhor gancho?

### Bloco 5 — Recomendações acionáveis

Para cada achado, 1 ação concreta:
- "Pausar anúncio X (CTR <1%)"
- "Escalar anúncio Y (CPL R$ 40)"
- "Refazer hero da LP Z (bounce 72%)"
- "Testar gancho diferente no Reels W"

### Bloco 6 — Gerar relatório

Use `references/template-relatorio-performance.md`.

## Integração com skills

- Alimenta `ads-multichannel` (otimização)
- Alimenta `calendario-editorial` (ajuste de pauta)
- Alimenta `criar-copy` (aprende o que converte)

## Armadilhas comuns

1. **Olhar métrica de vaidade.** Relatório cheio de "alcance subiu" sem leads = nada.
2. **Janela curta demais.** 3 dias ≠ diagnóstico. Mínimo 7, ideal 14.
3. **Comparar canais com métricas iguais.** Reels orgânico e Google Search têm lógicas diferentes.
4. **Ignorar qualidade do lead.** 50 leads ruins ≠ 10 leads bons.
