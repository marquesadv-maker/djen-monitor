# Relatório de Performance — [Período]

> Gerado pela skill `qa-performance`.
> Período: [data início – data fim]
> Canais analisados: [...]
> Investimento total: R$ [...]

---

## 1. Resumo executivo

- **Leads capturados:** [X] (meta: [Y])
- **CPL médio:** R$ [...]
- **Agendamentos:** [X]
- **Clientes fechados:** [X]
- **Receita gerada:** R$ [...]
- **ROI:** [X]x

**Veredito:** [meta batida / parcial / abaixo]

---

## 2. Funil completo

| Estágio | Volume | Taxa |
|---|---|---|
| Impressões | [...] | — |
| Cliques | [...] | CTR [...]% |
| Leads | [...] | Conv LP [...]% |
| Agendamentos | [...] | [...]% |
| Clientes | [...] | [...]% |

---

## 3. Top 3 peças

| # | Peça | Resultado | Hipótese |
|---|---|---|---|
| 1 | [...] | [...] | [...] |
| 2 | [...] | [...] | [...] |
| 3 | [...] | [...] | [...] |

---

## 4. Bottom 3 peças

| # | Peça | Problema | Ação |
|---|---|---|---|
| 1 | [...] | [...] | [...] |
| 2 | [...] | [...] | [...] |
| 3 | [...] | [...] | [...] |

---

## 5. Diagnóstico por estágio

- **Topo:** [...]
- **Meio:** [...]
- **Fundo:** [...]
- **Pós:** [...]

---

## 6. Recomendações priorizadas

### Imediato (fazer essa semana)
- [ação 1]
- [ação 2]

### Curto prazo (próximas 2 semanas)
- [...]

### Estratégico (próximo ciclo)
- [...]

---

## 7. Próximo período — metas

- Leads: [...]
- CPL: R$ [...]
- Receita: R$ [...]
