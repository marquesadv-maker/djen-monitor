# Benchmarks de Performance — Marketing Jurídico BR

Faixas de referência para comparação. Varia por nicho, região e maturidade de conta.

---

## Google Search Ads (advogados)

| Métrica | Ruim | OK | Bom | Excelente |
|---|---|---|---|---|
| CTR | <2% | 2-4% | 4-6% | >6% |
| CPC | >R$ 15 | R$ 8-15 | R$ 4-8 | <R$ 4 |
| Taxa conv LP | <2% | 2-5% | 5-8% | >8% |
| CPL | >R$ 200 | R$ 100-200 | R$ 50-100 | <R$ 50 |

---

## LinkedIn Ads (jurídico B2B)

| Métrica | Ruim | OK | Bom |
|---|---|---|---|
| CTR | <0,3% | 0,3-0,6% | >0,6% |
| CPC | >R$ 25 | R$ 15-25 | <R$ 15 |
| CPL | >R$ 500 | R$ 200-500 | <R$ 200 |

---

## Orgânico (Instagram / Reels)

| Métrica | Ruim | OK | Bom | Viral |
|---|---|---|---|---|
| Alcance/seguidores | <15% | 15-35% | 35-80% | >80% |
| Taxa engajamento | <2% | 2-5% | 5-10% | >10% |
| Salvamentos por post | <10 | 10-50 | 50-200 | >200 |

---

## Landing Pages jurídicas

| Métrica | Ruim | OK | Bom |
|---|---|---|---|
| Taxa conversão | <3% | 3-8% | >8% |
| Bounce rate | >70% | 50-70% | <50% |
| Tempo na página | <30s | 30s-90s | >90s |

---

## Email marketing

| Métrica | Ruim | OK | Bom |
|---|---|---|---|
| Open rate | <18% | 18-28% | >28% |
| CTR | <2% | 2-4% | >4% |
| Unsubscribe | >2% | 1-2% | <1% |

---

## Funil completo (lead → cliente)

| Etapa | Taxa típica |
|---|---|
| Lead → agendamento | 15-35% |
| Agendamento → consulta realizada | 50-75% |
| Consulta → contrato fechado | 15-40% |
| **Lead → cliente (total)** | **2-8%** |

---

## CAC (Custo Aquisição Cliente)

| Nicho | CAC aceitável |
|---|---|
| Previdenciário | R$ 500-1.500 |
| Trabalhista | R$ 400-1.200 |
| Família | R$ 600-2.000 |
| Tributário PJ | R$ 2.000-8.000 |
| Empresarial | R$ 3.000-15.000 |

Regra: CAC deve ser < 20-30% do LTV (valor médio do cliente).
