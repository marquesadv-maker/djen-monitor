# Sequência de Nutrição — [Nome da Isca/Campanha]

> Gerado pela skill `nutricao-whatsapp-email`.
> Canal principal: [email / WhatsApp / ambos]
> Duração: [7 / 14 / 30 dias]
> Persona-alvo: [...]
> Isca de entrada: [...]

---

## Cadência

| Dia | Canal | Assunto/Gancho | Objetivo |
|---|---|---|---|
| D+0 | [...] | [...] | Entregar isca |
| D+1 | [...] | [...] | Abrir diálogo |
| D+3 | [...] | [...] | Complementar |
| D+7 | [...] | [...] | Case de autoridade |
| D+14 | [...] | [...] | Convite consulta |
| D+21 | [...] | [...] | Dúvidas comuns |
| D+30 | [...] | [...] | Checkin final |

---

## Mensagem D+0

**Canal:** [email / WhatsApp]
**Assunto:** [apenas email]

**Texto:**
> [mensagem completa]

**CTA:** [...]

---

## Mensagem D+1

**Canal:** [...]
**Assunto/Primeira frase:** [...]

**Texto:**
> [...]

**CTA:** [...]

---

## Mensagem D+3

[repetir formato]

---

## Mensagem D+7

[repetir]

---

## Mensagem D+14 (CTA principal)

**Canal:** [...]
**Assunto:** [...]

**Texto:**
> [...]

**CTA:** Agendar consulta de 15 minutos
**Link:** [link de agendamento]

---

## Mensagem D+21

[repetir]

---

## Mensagem D+30 (checkin final)

**Canal:** [...]
**Assunto:** [...]

**Texto:**
> [...]

**Opção explícita:** sair da lista ou continuar recebendo

---

## Segmentação

Depois da sequência, leads vão para:
- **Convertidos (agendaram):** CRM / WhatsApp pessoal do advogado
- **Engajados sem converter:** newsletter mensal
- **Inativos (sem interação):** lista dormente, re-engagement em 90 dias
- **Opt-out:** removidos permanentemente

---

## Checklist OAB

- [ ] Nenhuma mensagem promete resultado
- [ ] Todos os cases são anonimizados
- [ ] CTAs são orientativos
- [ ] Sem comparação com concorrentes
- [ ] Identificação do advogado (nome + OAB) visível

---

## Checklist LGPD

- [ ] Unsubscribe em 100% dos emails
- [ ] Opção de saída clara no WhatsApp
- [ ] Política de privacidade linkada
- [ ] Finalidade do contato declarada
- [ ] Dados protegidos

---

## KPIs

- Taxa de abertura email (alvo: >30% D+0, >15% D+30)
- Taxa de resposta WhatsApp (alvo: >20% D+1)
- Taxa de clique no CTA principal (D+14) — alvo: >5%
- Taxa de conversão total (lead → consulta agendada) — alvo: 3-8%
- Unsubscribe rate — alvo: <2%
