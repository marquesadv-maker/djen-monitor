# Biblioteca de Mensagens — Modelos Prontos

Mensagens testadas por momento da sequência. Adapte ao tom do escritório.

---

## D+0 — Entrega da isca

### Email

**Assunto:** Aqui está seu [nome do material]

> Oi, [nome]!
>
> Conforme combinado, aqui está o [checklist/guia/e-book] que você baixou: [link].
>
> Esse material foi pensado pra quem está vivendo [situação da persona]. Nele, você encontra [3 tópicos principais].
>
> Se depois de ler você tiver uma pergunta específica sobre sua situação, pode me responder esse email. Eu leio e respondo pessoalmente.
>
> Até breve,
>
> Dra. [Nome]
> OAB/[UF] [número]

### WhatsApp

> Oi, [nome]! Tudo bem?
>
> Aqui está o [material] que você pediu: [link]
>
> Qualquer dúvida, é só me chamar por aqui mesmo.
>
> [Nome] — Advogad(a) / OAB [UF] [número]

---

## D+1 — Abertura de diálogo

### Email

**Assunto:** Conseguiu abrir o material?

> Oi, [nome],
>
> Passando rápido pra saber se você conseguiu abrir o [material] que mandei ontem.
>
> Se teve algum problema no link, me avisa que eu reenvio.
>
> E aproveitando: se enquanto lia surgiu alguma pergunta que o material não respondeu, me conta. Essas perguntas são as que eu mais gosto de responder.
>
> Abraço,
> [Nome]

### WhatsApp

> [nome], deu tudo certo com o material de ontem?
>
> Se bateu alguma dúvida enquanto lia, me chama que te ajudo.

---

## D+3 — Conteúdo complementar

### Email

**Assunto:** Uma coisa que o checklist não explica

> Oi, [nome],
>
> Quando eu montei aquele [checklist], tive que deixar de fora um detalhe importante: [mini-insight].
>
> [2-3 parágrafos explicando]
>
> Esse tipo de coisa é o que normalmente aparece na conversa com o cliente, mas dificilmente cabe num material de 2 páginas.
>
> Se quiser entender como isso se aplica ao seu caso, é só responder.
>
> [Nome]

### WhatsApp

> [nome], dica rápida que não coloquei no material:
>
> [1 insight curto, 2-3 linhas]
>
> Faz sentido pra sua situação?

---

## D+7 — Case de autoridade (anonimizado)

### Email

**Assunto:** Uma situação que resolvemos recentemente

> Oi, [nome],
>
> Semana passada atendemos um caso parecido com [descrição genérica da dor].
>
> A pessoa tinha [situação similar à persona]. Depois de analisar documentos e entender o histórico, identificamos [ponto técnico].
>
> O resultado: conseguimos [resultado genérico SEM valor/garantia].
>
> Cada caso é único, mas muitas vezes a pessoa nem sabe que tem direito porque ninguém explicou.
>
> Se você tá se reconhecendo nessa história, posso te ajudar a entender se faz sentido olhar com calma.
>
> Me responde aqui que a gente conversa.
>
> [Nome]

---

## D+14 — Convite para consulta (CTA principal)

### Email

**Assunto:** Conversa de 15 minutos pra tirar suas dúvidas

> Oi, [nome],
>
> Nas últimas semanas te mandei conteúdo sobre [tema]. Espero que tenha sido útil.
>
> Se tiver uma dúvida específica sobre sua situação, quero te oferecer uma **conversa inicial de 15 minutos** — sem custo.
>
> Não é consulta formal. É só pra entender se faz sentido continuar o assunto ou se resolve com uma orientação rápida.
>
> Se quiser, pode agendar um horário aqui: [link de agendamento]
>
> Se preferir, me manda direto sua dúvida por email ou WhatsApp.
>
> Abraço,
> [Nome]
> OAB/[UF] [nº]

### WhatsApp

> [nome], to aqui pensando se você conseguiu avançar com aquela situação que a gente tava conversando.
>
> Se ainda tá em dúvida, que tal uma conversa de 15 min pra eu entender seu caso e te orientar?
>
> Pode ser pelo WhatsApp mesmo ou aqui: [link]

---

## D+21 — Dúvidas comuns

### Email

**Assunto:** 3 perguntas que todo mundo faz sobre [tema]

> Oi, [nome],
>
> Essas são as 3 perguntas que mais aparecem quando o tema é [tema]:
>
> **1. [pergunta 1]**
> [resposta curta]
>
> **2. [pergunta 2]**
> [resposta]
>
> **3. [pergunta 3]**
> [resposta]
>
> Se tiver outra pergunta, me manda que eu respondo.
>
> [Nome]

---

## D+30 — Checkin final

### Email

**Assunto:** Última mensagem — você decide

> Oi, [nome],
>
> Essa é a última mensagem da sequência que eu configurei quando você baixou o [material].
>
> Se preferir continuar recebendo conteúdos ocasionais sobre [tema], não precisa fazer nada. Eu mando umas 1-2x por mês.
>
> Se preferir sair, clica aqui: [unsubscribe].
>
> Se quiser conversar sobre seu caso, a porta tá aberta: [link de agendamento].
>
> Obrigad(a) pela atenção até aqui.
>
> [Nome]

---

## Princípios transversais

1. **Escrever como gente** — nada de "prezado cliente, temos o prazer de comunicar"
2. **Assinar sempre** — reforça que é pessoa, não marketing automation
3. **1 CTA por mensagem** — não misturar
4. **Mensagem curta em WhatsApp** — respeita o canal
5. **Nenhuma promessa** — OAB first
6. **Valor antes de pedido** — 4 mensagens de valor antes da venda
