---
name: nutricao-whatsapp-email
description: Escreve sequências de nutrição (email e WhatsApp) para transformar leads capturados em clientes do escritório. Gera 5-10 mensagens com cadência, tom humanizado, CTAs escalonados e compliance OAB+LGPD. Use SEMPRE que o advogado mencionar: "nutrir leads", "sequência de emails", "automação de WhatsApp", "fluxo de mensagens", "relacionamento com lead", "email marketing jurídico", "fluxo de nutrição", "converter lead frio em cliente", "escrever emails da sequência", "mensagens automáticas", "jornada de lead". Complementa a skill captura-lead.
---

# Nutrição via WhatsApp e Email

Esta skill escreve a **sequência completa de mensagens** que o escritório envia para leads capturados, guiando-os da curiosidade inicial até o agendamento da consulta.

## Por que nutrir (e não só vender)

- Cliente jurídico decide em 3-8 semanas
- Contato imediato de venda = afasta
- Nutrição = entregar valor antes de pedir algo
- Relação de confiança é a moeda do jurídico

## Pré-requisitos

Leia antes:
- `personas.md` — linguagem e dor
- `produto-nicho.md` — serviço ofertado
- `captura-lead.md` — isca e fluxo definidos
- `manual-marca.md` — tom de voz

## Workflow

### Bloco 1 — Definir cadência da sequência

**Padrão 14 dias (leads em busca rápida):**
D+0 → D+1 → D+3 → D+7 → D+14

**Padrão 30 dias (leads em pesquisa longa):**
D+0 → D+2 → D+5 → D+10 → D+17 → D+25 → D+35

**Padrão 7 dias (leads quentes urgentes):**
D+0 → D+1 → D+2 → D+4 → D+7

Escolha com base no **momento de decisão** da persona. Trabalhista demitido = urgente (7-14 dias). Planejamento sucessório = longo (30-60 dias).

### Bloco 2 — Estruturar cada mensagem

**Arquitetura de cada email/mensagem:**

- **Gancho:** pergunta ou afirmação que prende
- **Conteúdo útil:** 1 insight/dica/case (não é venda)
- **Próximo passo:** CTA escalonado (ver Bloco 4)
- **Assinatura humana:** nome + OAB

### Bloco 3 — Progressão emocional da sequência

| Mensagem | Objetivo | Tom |
|---|---|---|
| D+0 | Entregar o prometido (isca) | Acolhedor |
| D+1 | Abrir diálogo, checar recebimento | Pessoal |
| D+3 | Complementar com 1 insight | Útil |
| D+7 | Case anonimizado (autoridade) | Profissional-humano |
| D+14 | Convite para consulta (CTA principal) | Direto mas suave |
| D+21 | Responder 3 dúvidas comuns | Didático |
| D+30 | Checkin final / saída da lista | Honesto |

### Bloco 4 — CTAs escalonados

Nunca começar com "agende consulta". Progressão:

| Momento | CTA sugerido |
|---|---|
| D+0 | "Responde essa mensagem se tiver alguma dúvida" |
| D+1 | "Conseguiu acessar o material? Me conta" |
| D+3 | "Quer receber mais conteúdos como esse?" |
| D+7 | "Quer entender como o caso da minha cliente foi resolvido? Me chama" |
| D+14 | "Podemos marcar uma conversa inicial de 15 min pra entender seu caso?" |
| D+21 | "Se fizer sentido pra você, tá aberto: [link agendamento]" |
| D+30 | "Se preferir sair da lista, tudo bem. Se preferir continuar recebendo, não precisa fazer nada." |

### Bloco 5 — Diferenças email vs WhatsApp

**Email:**
- 200-500 palavras
- Assunto trabalhado (40-60 caracteres)
- Estrutura: intro + desenvolvimento + CTA
- Assinatura completa
- Permite links clicáveis longos

**WhatsApp:**
- 40-120 palavras (máximo)
- Sem assunto — primeira frase É o assunto
- Estrutura: frase de entrada + 1 ideia + CTA curto
- Linguagem mais próxima
- Evitar links excessivos (filtros de spam)
- Usar emoji pontual (máx 1-2 por mensagem)

### Bloco 6 — Compliance OAB + LGPD

**OAB:**
- [ ] Sem promessa de resultado em nenhuma mensagem
- [ ] Cases anonimizados (sem nome/foto de cliente)
- [ ] CTA orientativo, não mercantil
- [ ] Sem comparação com outro escritório

**LGPD:**
- [ ] Link de unsubscribe em todo email
- [ ] Opção de "sair" no WhatsApp (instrução clara)
- [ ] Respeitar revogação imediatamente
- [ ] Não compartilhar lista com terceiros

## Gerando o entregável

Use `references/template-sequencia-nutricao.md`. Entregue:
- Sequência completa (5-10 mensagens)
- Assuntos de email + primeira frase de WhatsApp
- Textos completos
- Cadência/timing
- CTA por mensagem
- Checklist compliance

## Integração com skills downstream

Sequência alimenta:
- `criar-copy` (refinamento de textos específicos)
- `qa-etico-oab` (aprovação antes de automatizar)
- Ferramenta de automação (RD Station, ActiveCampaign, Z-API, etc.)

## Armadilhas comuns

1. **Sequência genérica.** Email igual pra todos os leads = baixa conversão. Segmentar por isca usada ou origem do lead.

2. **Excesso de CTAs.** 3 CTAs diferentes no mesmo email = 0 cliques. 1 CTA por mensagem.

3. **Silêncio prolongado depois da sequência.** Se o lead não converter em 30 dias, mover pra newsletter mensal (não abandonar).

4. **Automação sem toque humano.** Toda sequência deve ter 1-2 mensagens que parecem escritas na hora (ex: D+14 com "ei, to pensando em você"). Alivia o cheiro de robô.
