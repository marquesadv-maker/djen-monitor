---
name: curar-conteudo
description: Cura e organiza fontes de conteúdo jurídico relevantes para o escritório — decisões novas, mudanças legislativas, tendências do nicho, pautas de imprensa, casos em destaque — transformando matéria-prima bruta em lista de pautas editoriais acionáveis. Use SEMPRE que o advogado mencionar: "pautas de conteúdo", "sobre o que postar", "ideias para post", "curadoria de conteúdo", "não sei do que falar", "me falta assunto", "banco de pautas", "fontes de conteúdo jurídico", "acompanhar novidades do direito", "monitorar decisões", "tendências jurídicas", "jurisprudência nova", "mudança na lei", "virou notícia e eu quero falar", "o que está bombando no nicho", "preciso de ideias para post". Essencial para alimentar skills downstream de criação (roteiros, copies, criativos) com pautas atualizadas.
---

# Curar Conteúdo Jurídico

Esta skill gera **banco de pautas** para o escritório: transforma o caos de decisões, notícias, mudanças legislativas e pautas do nicho numa **lista curada e priorizada** de temas para produzir conteúdo.

## Por que isso importa

Advogado trava em "sobre o que postar" porque não tem pipeline de pautas. Sem curadoria, ele posta o que lembra na hora — e geralmente isso dá conteúdo genérico, repetido, sem novidade.

Curadoria estruturada transforma o escritório em **fonte primária**: quando algo importante acontece no nicho (nova súmula, decisão do STF, mudança legislativa), o escritório é o primeiro a publicar. Isso cria autoridade real.

## Pré-requisito

Leia antes:
- `produto-nicho.md` — define o **escopo** da curadoria (só pauta do nicho)
- `personas.md` — define o **ângulo** da pauta (pro cliente, não pro advogado)

Sem esses dois, a curadoria fica genérica.

## Workflow

A curadoria acontece em **4 etapas**, idealmente com WebSearch disponível pra buscar fontes ao vivo.

### Etapa 1 — Definir as fontes ativas

Com o advogado, mapear 5-8 **fontes primárias** que ele quer acompanhar no nicho dele. Exemplos:

**Institucionais:**
- STF, STJ, TST, TRFs (decisões novas)
- CNJ, OAB, Senado/Câmara (mudanças)
- Tribunais estaduais (jurisprudência regional)
- INSS, Receita Federal, órgãos reguladores (mudanças administrativas)

**Imprensa jurídica:**
- JOTA, Conjur, Migalhas, Valor Econômico (caderno jurídico)

**Comunidade:**
- Perfis de grandes juristas do nicho no LinkedIn/Instagram
- Podcasts jurídicos de autoridade
- Canais YouTube de alta qualidade

**Consulte `references/fontes-conteudo-juridico.md`** para catálogo completo por nicho.

### Etapa 2 — Varredura ativa

Para cada fonte, buscar nos últimos 7-30 dias:
- Decisões relevantes
- Mudanças legislativas
- Matérias de imprensa
- Discussões em alta

Registre em formato cru (link + 1 linha descritiva), sem filtrar ainda.

**Objetivo:** sair da varredura com 20-40 itens brutos.

### Etapa 3 — Filtro de relevância

Aplicar filtro nos itens brutos para virar pauta. Perguntas:

1. **Afeta a persona primária?** (se sim → mantém, se não → descarta)
2. **É acionável?** (cliente pode fazer algo com essa info?)
3. **É didatizável?** (consegue virar post de 3-5min ou carrossel de 8 slides?)
4. **Ainda é atual?** (decisão de 3 meses atrás pode ser velha na timeline)
5. **É seguro pela OAB?** (não cai em promessa, comparação, exposição?)

**Consulte `references/filtros-relevancia-pauta.md`** para framework completo.

Saída: 8-15 pautas filtradas.

### Etapa 4 — Priorização e angulação

Priorizar as pautas em **3 categorias**:

**Urgentes (quente, 7 dias):**
- Notícia/decisão novíssima
- Alta relevância pro cliente
- Risco de ser "velha" em 1 semana

**Evergreen (sempre-verde):**
- Conteúdo que vale hoje e daqui 1 ano
- Base da biblioteca de autoridade

**Sazonais:**
- Pautas ligadas a eventos do ano (IR no março, aposentadoria no aniversário, etc.)

Para cada pauta, sugerir **ângulo** que conversa com a persona (não com o advogado). Exemplo:

> **Pauta bruta:** "STF decidiu que revisão da vida toda pode ser pedida até 10 anos depois"
> **Ângulo para persona:** "Se você se aposentou depois de 2000, tem até 10 anos pra pedir pra revisar seu benefício — muita gente perde prazo por não saber"

## Gerando o entregável

Use `references/template-banco-pautas.md`. Gere `banco-pautas.md` com pauta organizada em urgente / evergreen / sazonal, cada uma com ângulo e primeira hipótese de formato (reels? carrossel? artigo?).

## Cadência de atualização

Curadoria não é evento — é **ritmo**. Recomende ao advogado:
- **Semanal** (30 min): varredura rápida das fontes primárias, adição de 3-5 pautas novas
- **Mensal** (2h): varredura profunda, revisão do banco, descarte do que ficou velho
- **Trimestral:** revisão das fontes (adicionar novas, remover inativas)

Se o advogado quiser automatizar a varredura, sugira integrar com o plugin **captar-djen** (que já faz monitoramento de publicações) e criar alerts em ferramentas tipo Google Alerts.

## Integração com skills downstream

O `banco-pautas.md` alimenta diretamente:
- `editorial-linha` (define quais temas recorrentes viram pilar editorial)
- `calendario-editorial` (distribui as pautas no calendário)
- `criar-copy`, `roteiros-video`, `criar-criativos` (pegam pauta pronta como briefing)

Mantenha o banco de pautas **vivo** — é o motor de produção do escritório.

## Armadilha comum

Advogado cura e não produz. Curadoria só tem valor se virar conteúdo publicado. Estabeleça um **SLA interno**: pauta nova curada hoje vira conteúdo publicado em até 14 dias, senão sai do banco e entra no arquivo.
