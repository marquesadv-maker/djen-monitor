# Filtros de Relevância de Pauta

Framework para transformar item bruto (notícia, decisão, mudança) em pauta editorial acionável. Aplique na ordem.

---

## Filtro 1 — Afeta a persona primária?

Pergunta: **o cliente-tipo do escritório sente esse tema na pele?**

- ✅ Mantém se a pauta toca direto na vida/bolso/rotina da persona
- ❌ Descarta se só interessa pra advogado, pra acadêmico ou pra outro nicho

Exemplo:
- Persona = aposentado que teve benefício negado
- Pauta "STF decidiu sobre teto do RGPS" → ✅ mantém (afeta valor do benefício)
- Pauta "CNJ regulamentou honorários de sucumbência" → ❌ descarta (interessa advogado, não cliente)

---

## Filtro 2 — É acionável?

Pergunta: **o cliente pode FAZER algo com essa informação?**

- ✅ Mantém se existe ação concreta (revisar, pedir, juntar documento, procurar advogado, esperar prazo)
- ❌ Descarta se é "só pra saber" sem desdobramento prático

Exemplo:
- "Novo prazo para pedir revisão da vida toda" → ✅ ação clara
- "Discussão acadêmica sobre natureza jurídica do BPC" → ❌ sem ação

---

## Filtro 3 — É didatizável em 3-5 min?

Pergunta: **dá pra explicar num reels de 90s, carrossel de 8 slides ou artigo de 4 min?**

- ✅ Mantém se o núcleo cabe em formato curto/médio
- ❌ Descarta se precisa de 30 min de contexto pra fazer sentido

Dica: se você precisa explicar 3 conceitos técnicos antes de chegar no ponto, a pauta está crua demais — precisa de recorte mais específico.

---

## Filtro 4 — Ainda é atual?

Pergunta: **a pauta ainda "pega" na timeline do cliente?**

- ✅ Mantém se é de até 30 dias OU se é evergreen (tema permanente)
- ❌ Descarta se é decisão/notícia de 60+ dias e já foi coberta pela imprensa

Exceção: pautas antigas podem virar **série educativa** (ex: "top 5 decisões que todo aposentado deveria conhecer").

---

## Filtro 5 — É seguro pela OAB (Prov. 205/2021)?

Pergunta: **posso publicar sem ferir ética profissional?**

Checklist rápido:
- [ ] Não promete resultado ("você vai ganhar")
- [ ] Não compara com concorrente nominalmente
- [ ] Não expõe cliente (mesmo que anonimizado)
- [ ] Não captura cliente de forma mercantilizada
- [ ] Não usa linguagem sensacionalista/apelativa
- [ ] Não induz a litigância desnecessária

Se a pauta **precisa** furar alguma regra pra ser interessante, descarte. Não vale o risco.

---

## Filtro 6 — Tem ângulo novo ou é repetição?

Pergunta: **essa pauta já foi coberta 50x pelos concorrentes com o mesmo ângulo?**

- ✅ Mantém se você consegue dar ângulo novo (recorte diferente, persona diferente, dado novo)
- ❌ Descarta se vai ser "mais um post igual aos outros"

Dica: pauta repetida + ângulo novo > pauta original + ângulo batido.

---

## Matriz de decisão rápida

| Filtro | Peso | Pauta passa? |
|---|---|---|
| 1. Afeta persona | Bloqueante | Sim/Não |
| 2. Acionável | Bloqueante | Sim/Não |
| 3. Didatizável | Alto | Sim/Parcial/Não |
| 4. Atual | Médio | Sim/Evergreen/Não |
| 5. OAB-seguro | Bloqueante | Sim/Não |
| 6. Ângulo novo | Médio | Sim/Não |

**Regra de ouro:** se qualquer filtro bloqueante dá Não → descarta. Se os 3 bloqueantes passam mas os médios falham → tenta reangular antes de descartar.

---

## Taxa saudável

De 20-40 itens brutos na varredura, espere:
- 8-15 pautas aprovadas
- 5-10 descartadas por filtros bloqueantes
- 5-10 arquivadas ("talvez um dia")

Curadoria boa **descarta sem culpa**. Banco de pautas inflado vira banco de pautas travado.
