# Banco de Pautas — [Nome do Escritório]

> Documento gerado pela skill `curar-conteudo`.
> Última atualização: [data]
> Próxima revisão: [data + 7 dias]

---

## Legenda

- 🔥 **Urgente** — publicar em até 7 dias
- 🌳 **Evergreen** — publicar quando fizer sentido, vale sempre
- 📅 **Sazonal** — publicar próximo ao evento

---

## Pautas Urgentes 🔥

### Pauta #[N] — [Título curto]

- **Fonte:** [link]
- **Resumo:** [1-2 linhas do fato bruto]
- **Ângulo para a persona:** [como essa pauta vira conteúdo pra cliente-tipo]
- **Formato sugerido:** [reels / carrossel / artigo / vídeo longo]
- **Tom sugerido:** [alerta / didático / reflexivo]
- **Objeção que ataca:** [qual medo/dúvida da persona resolve]
- **OAB:** [atenção especial? nenhuma?]
- **Prazo sugerido para publicação:** [data]

---

### Pauta #[N] — [Título curto]
[Repetir estrutura]

---

## Pautas Evergreen 🌳

### Pauta #[N] — [Título curto]

- **Tema:** [descrição]
- **Por que é evergreen:** [razão]
- **Ângulo para a persona:** [...]
- **Formato sugerido:** [...]
- **Pode virar série:** [sim/não + ideia]

---

## Pautas Sazonais 📅

### Pauta #[N] — [Título curto]

- **Evento/data:** [mês/data específica]
- **Antecedência ideal de publicação:** [2 semanas / 30 dias antes]
- **Ângulo:** [...]

---

## Arquivo (pautas descartadas)

| Pauta | Motivo do descarte | Data |
|---|---|---|
| [título] | [velha / fora do nicho / risco OAB / duplicada] | [data] |

---

## Status

- **Pautas no banco ativo:** [N]
- **Pautas publicadas nos últimos 30 dias:** [N]
- **Taxa de conversão (banco → publicado):** [%]
