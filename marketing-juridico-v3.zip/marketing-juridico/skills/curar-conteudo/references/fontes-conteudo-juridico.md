# Fontes de Conteúdo Jurídico por Nicho

Catálogo de fontes primárias e secundárias para curadoria. Priorize 5-8 fontes por escritório — mais que isso vira ruído.

---

## Fontes transversais (servem pra qualquer nicho)

**Institucionais:**
- STF — portal.stf.jus.br (decisões, pauta de julgamento)
- STJ — stj.jus.br (decisões, informativos)
- CNJ — cnj.jus.br (normativos, datajud, estatísticas)
- OAB — oab.org.br (ética, eventos, comunicados)

**Imprensa jurídica (gratuitas e pagas):**
- JOTA — jota.info (grátis com limite, pago premium)
- Conjur — conjur.com.br (gratuito)
- Migalhas — migalhas.com.br (gratuito)
- Valor Econômico — valor.globo.com (pago, caderno legal forte)

**Agregadores:**
- Google Alerts (grátis, por palavra-chave)
- Google Scholar (pesquisa de teses recentes)

---

## Previdenciário

**Institucionais:**
- TNU — Turma Nacional de Uniformização (turmas recursais federais)
- INSS — gov.br/inss (instruções normativas, portarias)
- TRF1-6 (TRFs de cada região)
- STJ — súmulas e informativos previdenciários

**Imprensa setorial:**
- IBDP — Instituto Brasileiro de Direito Previdenciário
- Blog do Direito Previdenciário (vários)
- Portal Previdenciarista

**Ferramentas de monitoramento:**
- Plugin `captar-djen` (alertas de publicação por OAB)

---

## Trabalhista

**Institucionais:**
- TST — tst.jus.br (súmulas, OJs, decisões, informativo)
- TRTs regionais (decisões locais)
- MPT — Ministério Público do Trabalho
- SRT — Superintendências Regionais do Trabalho

**Setorial:**
- Anamatra
- Revista LTr
- Juslaboris (biblioteca TST)

---

## Família

**Institucionais:**
- STJ — 3ª e 4ª Turmas (precedentes de família)
- CNJ — resoluções sobre guarda, alienação parental
- IBDFAM — Instituto Brasileiro de Direito de Família

**Eventos e comunidade:**
- Congresso IBDFAM (anual)
- Periódicos: Revista Brasileira de Direito de Família

---

## Consumidor

**Institucionais:**
- STJ — 3ª e 4ª Turmas (pioneiras em CDC)
- Senacon — Secretaria Nacional do Consumidor
- Procons estaduais (ranking de reclamações)

**Setorial:**
- IDEC — Instituto de Defesa do Consumidor (pautas fortes)
- Brasilcon
- Portal do Consumidor

---

## Criminal

**Institucionais:**
- STF — 1ª e 2ª Turmas, plenário
- STJ — 5ª e 6ª Turmas
- CNMP — Conselho Nacional do Ministério Público
- TJs estaduais

**Setorial:**
- IBCCRIM — Instituto Brasileiro de Ciências Criminais
- ABRACRIM
- Boletim IBCCRIM (mensal)

---

## Tributário / Empresarial

**Institucionais:**
- STF — Plenário (temas de repercussão geral)
- STJ — 1ª Seção (tributário)
- CARF — Conselho Administrativo de Recursos Fiscais
- Receita Federal (instruções normativas, soluções de consulta)
- Sefaz estaduais

**Setorial:**
- IBDT — Instituto Brasileiro de Direito Tributário
- ETCO
- Valor Tributário

---

## Bancário

**Institucionais:**
- BACEN — banco central (normativos, circulares)
- STJ — 2ª Seção (direito bancário)
- CVM — Comissão de Valores Mobiliários

**Setorial:**
- Reclame Aqui (tendências de reclamações)
- Procons (ranking de bancos)

---

## Imobiliário

**Institucionais:**
- STJ — 3ª e 4ª Turmas
- Registros de Imóveis (CNJ)
- Abrainc (Associação Brasileira de Incorporadoras)

**Setorial:**
- Sindicato da Construção (SindusCon)
- Portal VGV (mercado imobiliário)

---

## Saúde (paciente)

**Institucionais:**
- ANS — Agência Nacional de Saúde Suplementar
- Anvisa
- CFM — Conselho Federal de Medicina

**Setorial:**
- IDEC (negativas de plano)
- ABENFARMA (medicamentos)

---

## Startups / LGPD / Tech

**Institucionais:**
- ANPD — Autoridade Nacional de Proteção de Dados
- STJ — 3ª e 4ª Turmas (casos emergindo)
- STF — controle constitucional sobre LGPD

**Setorial:**
- ABStartups
- FPC — Fórum de Proteção de Crédito (dados)
- IAPP Brasil
- Distrito (cenário startup)

---

## Como escolher 5-8 fontes iniciais

1. **1-2 institucionais** do nicho (ex: STF + STJ para previdenciário)
2. **1-2 imprensa setorial** (JOTA + Migalhas)
3. **1 específica do nicho** (IBDP, IBDFAM, IDEC)
4. **1-2 de autoridade pessoal** (perfil LinkedIn de jurista-referência)
5. **1 de comunidade** (grupo Telegram, podcast forte)

Não se iluda achando que vai acompanhar 20 fontes. Curador que cura demais não publica nada.

---

## Ferramentas de monitoramento

**Grátis:**
- Google Alerts (palavra-chave → email diário/semanal)
- Feedly (RSS)
- Notion web clipper (salvar links rápido)

**Pagas:**
- LexisNexis / Thomson Reuters (jurisprudência enterprise)
- Plataformas jurídicas brasileiras (JusBrasil Pro, LegalBot, Jurid)
