---
name: editorial-linha
description: Define a linha editorial do escritório — pilares temáticos, tom de voz, formatos recorrentes, proporção entre tipos de conteúdo (autoridade / educação / conexão / conversão) e regras de consistência. Use SEMPRE que o advogado mencionar: "linha editorial", "pilares de conteúdo", "do que vou falar sempre", "identidade de conteúdo", "tom das postagens", "posicionamento de conteúdo", "como não parecer aleatório nas redes", "conteúdo coerente", "pillar content", "estratégia editorial", "voz do escritório". Essencial para dar consistência antes de montar calendário editorial.
---

# Linha Editorial

Esta skill define a **espinha dorsal** do conteúdo do escritório: pilares fixos, tom, formatos, proporções. Sem isso, o calendário vira colcha de retalhos e o público não consegue "guardar" quem você é.

## Por que isso importa

Conteúdo aleatório não cria autoridade. Autoridade vem de **repetição com variação**: mesmos temas-âncora, abordagens diferentes, tom consistente. A linha editorial é o contrato que o escritório faz com a audiência.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — define tom de voz macro
- `produto-nicho.md` — define escopo temático
- `personas.md` — define pra quem você fala
- `pesquisa-mercado.md` — mostra o gap que você vai ocupar

## Workflow

### Bloco 1 — Definir 3-5 pilares temáticos

Pilar = macro-tema que o escritório vai martelar por 12+ meses. Cada pilar responde a uma **dor ou interesse persistente** da persona.

Exemplo (escritório previdenciário, persona = pré-aposentado):
1. **Planejamento previdenciário** (como organizar antes de pedir)
2. **Revisões e recálculos** (o que você pode ter direito depois de aposentado)
3. **BPC-LOAS** (benefício assistencial que ninguém explica)
4. **Direitos do segurado** (o que o INSS não conta)
5. **Histórias & bastidores** (cases anonimizados + rotina do escritório)

Regra: **3-5 pilares, nem menos nem mais.** Menos que 3 enjoa. Mais que 5 dispersa.

### Bloco 2 — Definir proporção entre tipos de conteúdo

Todo post serve a **um objetivo de funil**. Proporcione:

| Tipo | Função | % sugerida |
|---|---|---|
| **Autoridade** | provar competência técnica | 25% |
| **Educação** | ensinar direito de forma didática | 35% |
| **Conexão** | humanizar, bastidor, valores | 20% |
| **Conversão** | CTA claro, oferta, agenda consulta | 20% |

Ajuste conforme fase do escritório:
- Escritório novo sem autoridade → aumentar autoridade + educação (70%)
- Escritório consolidado com baixa venda → aumentar conversão (30%)
- Escritório "frio" → aumentar conexão (30%)

### Bloco 3 — Definir formatos recorrentes

Escolha 2-4 formatos que o escritório vai **dominar**. Não tenta fazer tudo.

**Opções:**
- Carrossel educativo (didático, 8-10 slides)
- Reels de 60-90s (explicação rápida / mito-verdade)
- Vídeo-responde-dúvida (pergunta do seguidor → resposta curta)
- Artigo de blog (SEO, profundidade)
- Stories de bastidor (rotina, equipe)
- Lives / Youtube longo (autoridade profunda)
- Email/newsletter (relacionamento)

Regra: **2-4 formatos.** Mais que isso = dispersão de produção.

### Bloco 4 — Definir tom de voz editorial (específico de conteúdo)

Pegue o tom macro do `manual-marca.md` e traduza para conteúdo:

- **Como abre um post?** (pergunta? afirmação? dado?)
- **Usa emoji? Quais?**
- **Usa gírias? Quais sim, quais não?**
- **Tutea ou "você"?**
- **Assina os posts? Como?**
- **Responde comentários de que forma?**

Exemplo:
> Tom = "próximo mas com autoridade". Abre com pergunta que a persona se faz. Usa "você". Zero juridiquês. Emoji pontual (máximo 2 por post). Assina "Dra. [Nome]" no final de conteúdo de autoridade, sem assinatura em conteúdo educativo (vira do escritório).

### Bloco 5 — Definir regras de consistência

Regras fixas que todo post obedece:

- **Identidade visual:** paleta do manual, tipografia, logo posicionado onde
- **Hashtags-âncora:** 3-5 fixas + 5-10 variáveis
- **Frequência mínima:** X posts/semana em cada formato
- **Horários de publicação:** baseados em quando a persona está ativa
- **Restrições OAB:** o que nunca entra (promessa, comparação, case identificado)

## Gerando o entregável

Use `references/template-linha-editorial.md`. Gere `linha-editorial.md` com:
- 3-5 pilares temáticos
- Proporção de tipos de conteúdo
- 2-4 formatos recorrentes
- Tom de voz editorial
- Regras de consistência

## Integração com skills downstream

O `linha-editorial.md` alimenta:
- `calendario-editorial` (distribui pilares e formatos no calendário)
- `criar-copy` (pega tom e regras)
- `roteiros-video` (pega formato e tom)
- `qa-marca` (checa se peça está dentro da linha)

## Armadilha comum

Linha editorial bonita mas impraticável. Se o escritório tem 1 pessoa produzindo 5h/semana, não adianta definir 4 formatos + 5 pilares + 7 posts/semana. Calibre a linha editorial pelo **tempo real de produção** disponível.
