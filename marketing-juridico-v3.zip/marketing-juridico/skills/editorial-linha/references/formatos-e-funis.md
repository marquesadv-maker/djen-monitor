# Formatos de Conteúdo × Etapa do Funil

Guia para casar formato certo com objetivo certo. Escolha 2-4 formatos no total — não tente fazer todos.

---

## Topo do funil (atrair / descobrir)

**Reels 15-30s**
- Função: alcance e descoberta
- Força: algoritmo empurra
- Fraqueza: raso, difícil converter

**Reels 60-90s**
- Função: autoridade + alcance
- Força: explicação completa de 1 ponto
- Fraqueza: exige produção mais cuidada

**TikTok**
- Função: alcance orgânico em público novo
- Atenção: flerte com limite OAB é alto na plataforma

---

## Meio do funil (engajar / educar)

**Carrossel de Instagram (8-10 slides)**
- Função: educação profunda, salvamentos
- Força: usuário rola no ritmo dele, absorve mais
- Fraqueza: produção mais lenta

**Artigo de blog (SEO)**
- Função: captar busca ativa no Google
- Força: tráfego orgânico recorrente
- Fraqueza: exige SEO + demora 3-6 meses pra ranquear

**Vídeo-responde-dúvida**
- Função: conexão + autoridade
- Força: parece conversa real
- Fraqueza: depende de fluxo de perguntas do público

**YouTube longo (5-15 min)**
- Função: autoridade profunda
- Força: eterna, SEO no YouTube, recorrência
- Fraqueza: produção pesada

---

## Fundo do funil (converter)

**Stories com enquete / caixinha**
- Função: qualificar lead quente
- Força: interação direta, conversão alta
- Fraqueza: efêmero

**Live / webinar**
- Função: conversão em massa
- Força: interação direta, autoridade alta
- Fraqueza: exige audiência pré-aquecida

**Email / WhatsApp nutrição**
- Função: conversão 1-a-1
- Força: alto controle, conversão alta
- Fraqueza: exige lista própria (LGPD!)

**Post conversão direta (CTA claro)**
- Função: pedir ação
- Força: simples
- Fraqueza: chato se em excesso

---

## Matriz de escolha rápida

| Escritório | Formato principal sugerido | Secundário |
|---|---|---|
| Novo, baixa autoridade | Carrossel educativo | Reels 60s |
| Consolidado, quer vender mais | Stories caixinha + carrossel CTA | Email |
| Quer alcance orgânico | Reels + TikTok | Carrossel |
| Nicho B2B (tributário, empresarial) | Artigo + LinkedIn | YouTube longo |
| Nicho emocional (família, criminal) | Reels storytelling + vídeo-responde | Carrossel |
| SEO-first | Artigo blog | YouTube |

---

## Combinações que funcionam

**Combo 1 — Autoridade rápida:**
Carrossel educativo (2x/sem) + Reels 60s (2x/sem) + Stories diário

**Combo 2 — SEO e longo prazo:**
Artigo blog (1x/sem) + YouTube longo (1x/mês) + Reels (2x/sem)

**Combo 3 — Relacionamento:**
Stories diário + Live quinzenal + Email mensal

**Combo 4 — Alcance orgânico:**
Reels (5x/sem) + TikTok (3x/sem) + Carrossel (1x/sem)

---

## Regra da produção realista

Cada formato tem um custo:

| Formato | Horas de produção (médio) |
|---|---|
| Reels 60s | 2-3h (roteiro + gravação + edição) |
| Carrossel 8 slides | 2-3h (copy + design) |
| Artigo 1500 palavras | 3-5h (pesquisa + escrita + SEO) |
| YouTube 10 min | 6-10h |
| Stories diário | 15-30 min/dia |
| Live 30 min | 2-4h (preparo + gravação) |

Calcule o tempo semanal disponível do escritório e case com o combo. **Linha editorial que não cabe no dia vira frustração em 30 dias.**
