# Sugestões de Pilares Editoriais por Nicho

Catálogo de pilares testados por nicho. Use como ponto de partida — adapte ao posicionamento do escritório.

---

## Previdenciário

1. Planejamento previdenciário (antes de aposentar)
2. Revisões e recálculos (pós-aposentadoria)
3. BPC-LOAS e benefícios assistenciais
4. Auxílios (doença, acidente, reclusão)
5. Direitos do segurado que o INSS não conta

---

## Trabalhista (empregado)

1. Direitos na demissão
2. Assédio moral e sexual
3. Horas extras e banco de horas
4. Acidente de trabalho e doença ocupacional
5. Trabalhador uberizado / PJ / intermitente

---

## Família

1. Divórcio e partilha
2. Guarda e convivência
3. Pensão alimentícia
4. Planejamento sucessório / holding familiar
5. União estável e pacto antenupcial

---

## Consumidor

1. Negativa de plano de saúde / seguro
2. Problemas com bancos e financeiras
3. Produtos e serviços defeituosos
4. Cobrança indevida / nome sujo
5. Viagens e transporte aéreo

---

## Criminal

1. Direitos do investigado/acusado
2. Tranca de prisão e HC
3. Execução penal (progressão, livramento)
4. Crimes patrimoniais
5. Direito penal econômico / empresarial

---

## Tributário / Empresarial

1. Planejamento tributário
2. Execuções fiscais e defesas
3. Regime tributário (Simples, Lucro Real)
4. Recuperação de créditos
5. Compliance e gestão de risco

---

## Imobiliário

1. Compra, venda e financiamento
2. Contratos de locação
3. Usucapião e regularização
4. Condomínios e disputas de vizinhança
5. Distrato e atrasos de obra

---

## Bancário

1. Revisão de contratos e juros abusivos
2. Negativação indevida
3. Golpes e fraudes bancárias
4. Desbloqueio de conta / PIX
5. Superendividamento

---

## Saúde (paciente)

1. Negativas de plano de saúde
2. Medicamentos de alto custo
3. Cirurgias e tratamentos negados
4. Erro médico
5. SUS e direito à saúde

---

## Como escolher os seus 3-5

Critérios:
1. **Volume de interesse** — há pauta suficiente pra 12 meses?
2. **Afinidade com persona primária** — ataca a dor principal?
3. **Gap no mercado** — concorrente não cobre bem?
4. **Fit com o escritório** — vocês dominam esse subtema?
5. **Estoque de casos/exemplos** — vocês têm repertório pra produzir?

Não escolha pilar que você "deveria cobrir" mas não domina. Autoridade falsa desmonta.
