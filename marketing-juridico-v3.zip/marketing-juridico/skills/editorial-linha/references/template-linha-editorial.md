# Linha Editorial — [Nome do Escritório]

> Documento gerado pela skill `editorial-linha`.
> Última atualização: [data]
> Revisão sugerida: trimestral

---

## 1. Pilares Temáticos (3-5)

### Pilar 1 — [Nome]
- **Descrição:** [1-2 linhas]
- **Dor/interesse da persona que ataca:** [...]
- **Exemplos de pautas:** [3-5 exemplos]

### Pilar 2 — [Nome]
[repetir]

### Pilar 3 — [Nome]
[repetir]

---

## 2. Proporção de Tipos de Conteúdo

| Tipo | % alvo | Função |
|---|---|---|
| Autoridade | __% | Provar competência |
| Educação | __% | Ensinar |
| Conexão | __% | Humanizar |
| Conversão | __% | Gerar lead/consulta |

**Justificativa da proporção:** [por que essa distribuição faz sentido pra fase atual do escritório]

---

## 3. Formatos Recorrentes (2-4)

### Formato 1 — [Ex: Carrossel educativo]
- **Estrutura:** [8-10 slides, abertura com gancho, corpo didático, CTA]
- **Frequência:** [X por semana]
- **Responsável pela produção:** [quem faz]

### Formato 2 — [Ex: Reels 60-90s]
[repetir]

---

## 4. Tom de Voz Editorial

- **Abertura de post:** [pergunta / afirmação / dado / história]
- **Pronome de tratamento:** [você / tu / senhor]
- **Uso de emoji:** [sim, pontual / não / específicos]
- **Uso de gírias:** [quais sim / quais não]
- **Juridiquês:** [zero / traduzido / mínimo]
- **Assinatura:** [quando assina como Dr(a)., quando como escritório]
- **Resposta a comentários:** [tom e prazo]

---

## 5. Regras de Consistência

**Identidade visual:**
- Paleta: [cores do manual]
- Tipografia: [fontes]
- Posição do logo: [onde]

**Hashtags-âncora fixas:** [3-5]
**Hashtags variáveis:** [5-10 por tema]

**Frequência mínima:**
- [X] posts/semana no formato 1
- [X] posts/semana no formato 2

**Horários de publicação:**
- [dias e horários alinhados com persona]

**Restrições OAB (nunca entra):**
- Promessa de resultado
- Comparação nominal com concorrente
- Case identificado ou identificável
- [outras específicas do escritório]

---

## 6. Capacidade de Produção Realista

- **Horas/semana disponíveis:** [X]
- **Volume total viável por semana:** [N posts]
- **Alerta:** se produção cair abaixo de __/semana por 2 semanas seguidas, revisar linha editorial
