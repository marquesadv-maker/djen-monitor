# Iscas Digitais Testadas por Nicho Jurídico

Catálogo de iscas que funcionam, organizadas por nicho. Use como ponto de partida.

---

## Previdenciário

**Alta conversão:**
- ✅ "Calculadora de tempo de contribuição" (online)
- ✅ "Checklist: 8 documentos para pedir sua aposentadoria"
- ✅ "Quiz: você tem direito à revisão da vida toda?"
- ✅ "Guia: 5 situações em que o INSS pagou a menos"

**Média conversão:**
- E-book: "Tudo sobre aposentadoria em 2026"
- Modelo de requerimento administrativo

---

## Trabalhista

**Alta conversão:**
- ✅ "Checklist: o que verificar antes de assinar a rescisão"
- ✅ "Calculadora de verbas rescisórias"
- ✅ "Quiz: sua demissão foi justa?"
- ✅ "Guia rápido: horas extras que seu empregador esqueceu"

**Média conversão:**
- E-book: "Direitos na justa causa"
- Modelo de declaração de testemunha

---

## Família

**Alta conversão:**
- ✅ "Calculadora de pensão alimentícia"
- ✅ "Checklist: documentos para divórcio consensual"
- ✅ "Quiz: seu caso serve para guarda compartilhada?"
- ✅ "Guia: 5 erros caros no divórcio"

**Média conversão:**
- E-book: "Planejamento sucessório familiar"
- Modelo de acordo de convivência

---

## Consumidor

**Alta conversão:**
- ✅ "Modelo de reclamação pro plano de saúde"
- ✅ "Checklist: o que fazer nas primeiras 24h após negativação indevida"
- ✅ "Quiz: seu caso dá indenização por dano moral?"
- ✅ "Guia: 7 cláusulas abusivas comuns em contratos bancários"

---

## Tributário (PF e PJ)

**Alta conversão:**
- ✅ "Checklist para declarar IR 2026 sem errar"
- ✅ "Calculadora de Simples Nacional vs Lucro Presumido"
- ✅ "Guia: como parcelar dívida com a Receita"

---

## Imobiliário

**Alta conversão:**
- ✅ "Checklist antes de assinar contrato de compra"
- ✅ "Modelo de notificação de atraso de obra"
- ✅ "Quiz: você tem direito à usucapião?"

---

## Bancário / Superendividamento

**Alta conversão:**
- ✅ "Calculadora de juros abusivos"
- ✅ "Checklist: como sair do nome sujo"
- ✅ "Guia: passo a passo do superendividamento (Lei 14.181)"

---

## Saúde (paciente)

**Alta conversão:**
- ✅ "Modelo de recurso administrativo para plano de saúde"
- ✅ "Checklist de documentos para negativa de medicamento"
- ✅ "Guia: o que fazer quando o SUS nega tratamento"

---

## Regras gerais para iscas de alta conversão

### 1. Específica, não genérica
❌ "Guia completo sobre direitos trabalhistas"
✅ "Checklist: 5 coisas a conferir na rescisão antes de assinar"

### 2. Promete entrega concreta
- Checklist → "você vai ter uma lista pronta para usar amanhã"
- Calculadora → "você vai ter um número estimado em 2 minutos"
- Quiz → "você vai saber se seu caso se encaixa em 1 minuto"

### 3. Curta e direta
- Checklist: 1-2 páginas
- E-book: 10-20 páginas (mais que isso = ninguém lê)
- Quiz: 5-10 perguntas
- Calculadora: 3-5 campos

### 4. Design profissional
- Diagramação clean
- Marca do escritório aplicada
- Sem marcas d'água genéricas
- PDF bem estruturado

### 5. CTA interno
Dentro do próprio material, inclua: "Quer analisar seu caso específico? Agende uma conversa."

---

## Formatos que NÃO convertem bem em jurídico

❌ Curso completo (longo demais, baixa conclusão)
❌ Desafio de 30 dias (não cabe no jurídico)
❌ Cupom de desconto (viola OAB)
❌ Whitepaper denso (afasta leigo)

---

## Teste A/B recomendado

Rode 2 iscas em paralelo por 4 semanas:
- Versão A: checklist (curto, simples)
- Versão B: quiz (interativo)

Mede: conversão da LP + qualidade do lead gerado.
Continua com o vencedor.
