# Plano de Captura de Lead — [Nome da Isca]

> Gerado pela skill `captura-lead`.
> Persona-alvo: [...]
> Tema: [...]
> Canal principal: [LP + WhatsApp / LP + Email]

---

## Isca Digital

**Tipo:** [checklist / e-book / calculadora / quiz / webinar / modelo]
**Título da isca:** [título-gancho]
**Entrega:** [PDF, link, email]
**Tempo de produção:** [horas]
**Por que essa isca:** [justificativa]

---

## Formulário

**Campos:**
- [ ] Nome
- [ ] Email OU WhatsApp
- [ ] Aceite LGPD ✓
- [ ] [campos extras, se houver]

**Texto do aceite LGPD:**
> [texto conforme modelo]

---

## Fluxo Pós-Cadastro

### D+0 (imediato)
**Canal:** email automático + WhatsApp (opcional)
**Mensagem:** [cole texto aqui]
**Ação:** entregar link/PDF da isca

### D+1
**Canal:** [email/WhatsApp]
**Mensagem:** [...]
**Objetivo:** confirmar que recebeu + abrir diálogo

### D+3
**Canal:** email
**Mensagem:** [conteúdo complementar: "5 dúvidas comuns sobre [tema]"]
**CTA:** ler / responder

### D+7
**Canal:** email
**Mensagem:** [case anonimizado + insight]
**CTA:** agendar conversa (suave)

### D+14
**Canal:** email/WhatsApp
**Mensagem:** [convite pra consulta ou webinar]
**CTA:** agendar

### D+30
**Canal:** email
**Mensagem:** [checkin final — última da sequência]
**CTA:** agendar ou sair da lista

---

## Critérios de Qualificação

| Sinal | Classificação |
|---|---|
| Responde rápido + descreve problema concreto | 🔥 Lead quente |
| Abre emails, não responde | 🟡 Morno |
| Não abre nenhum email | ❄️ Frio |

**Ação por classificação:**
- 🔥 Agendar consulta em 24-48h
- 🟡 Manter nutrição, tentar conversa rápida no dia 14
- ❄️ Continuar sequência padrão; se 30 dias sem interação, mover pra lista dormente

---

## Templates de Mensagens

### Mensagem de boas-vindas (D+0)
[texto completo]

### Checkin (D+1)
[texto completo]

### Nutrição 1 (D+3)
[texto completo]

### Nutrição 2 (D+7)
[texto completo]

### Convite consulta (D+14)
[texto completo]

### Checkin final (D+30)
[texto completo]

---

## Checklist LGPD

- [ ] Checkbox de aceite não pré-marcado
- [ ] Política de privacidade linkada
- [ ] Finalidade do uso declarada no momento da coleta
- [ ] Opção de revogar consentimento em cada mensagem
- [ ] Dados armazenados em plataforma segura
- [ ] Unsubscribe funcional em todo email
- [ ] Encarregado de dados definido

---

## Checklist OAB

- [ ] Mensagens não prometem resultado
- [ ] Nenhum comparativo com concorrente
- [ ] CTA é orientativo
- [ ] Cases apresentados são anonimizados
- [ ] Advogado responsável identificado (OAB)

---

## KPIs para monitorar

- Taxa de conversão da LP (visitante → lead)
- Taxa de abertura de email (D+0 a D+30)
- Taxa de resposta de WhatsApp
- Taxa de agendamento de consulta (lead → consulta)
- Custo por lead (se ads)
- Taxa de conversão final (lead → cliente)
