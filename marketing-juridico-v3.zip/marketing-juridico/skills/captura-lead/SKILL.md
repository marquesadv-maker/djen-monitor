---
name: captura-lead
description: Estrutura estratégia de captura de leads para escritórios de advocacia — iscas digitais (e-book, checklist, calculadora), fluxo pós-cadastro, qualificação inicial, LGPD e integração com WhatsApp/email/CRM. Use SEMPRE que o advogado mencionar: "captar leads", "gerar leads", "pegar contatos", "lista de emails", "isca digital", "lead magnet", "e-book", "checklist", "formulário", "captação de clientes", "funil de entrada", "converter visitante em lead", "estratégia de aquisição". Complementa landing-pages com o fluxo de conversão e qualificação.
---

# Captura e Qualificação de Leads

Esta skill monta o **fluxo de entrada** de contatos interessados — da isca digital até a qualificação inicial, respeitando LGPD e Provimento 205/2021.

## Por que capturar leads (e não só aguardar contato direto)

- Cliente jurídico decide devagar (3-8 semanas em média)
- Poucos contratam na primeira visita
- Lista de leads = ativo próprio do escritório
- Nutrição transforma curioso em cliente ao longo do tempo

## Pré-requisitos

Leia antes:
- `personas.md` — que material atrai cada persona
- `produto-nicho.md` — tema da isca
- `linha-editorial.md` — tom da isca
- `landing-pages.md` — LP onde a isca será oferecida

## Workflow

### Bloco 1 — Escolher a isca digital certa

**Tipos de isca eficazes em jurídico:**

| Tipo | Esforço | Conversão | Uso |
|---|---|---|---|
| Checklist (1-2 páginas) | Baixo | Alta | "5 documentos para pedir aposentadoria" |
| E-book (10-20 páginas) | Médio | Média | Guia completo sobre um tema |
| Calculadora online | Alto | Alta | Simulador de pensão/tempo de contribuição |
| Quiz/diagnóstico | Médio | Alta | "Você tem direito à revisão?" |
| Webinar gravado | Alto | Média | Aula sobre tema denso |
| Modelo de documento | Baixo | Média | Modelo de carta de próprio punho |
| Mini-curso por email | Médio | Média | 5 emails em 10 dias |

**Critérios para escolher:**
- **Dor mais quente da persona primária**
- **Tempo de produção que o escritório tem**
- **Capacidade de entrega pós-captura**

### Bloco 2 — Definir formulário mínimo

Cada campo reduz conversão. Comece enxuto:

**Nível 1 — Captura simples (padrão):**
- Nome
- Email OU WhatsApp (escolher 1)
- Aceite LGPD ✓

**Nível 2 — Qualificação inicial (se a isca for densa):**
- + Estado/Cidade
- + Assunto de interesse (dropdown)

**Nível 3 — Lead quente:**
- + Descrição breve da situação

**Regra:** começar pelo nível 1. Se o lead está frio demais, subir para nível 2. Nunca começar em 3.

### Bloco 3 — Fluxo pós-cadastro (automação)

Imediatamente após o cadastro:

**Passo 1 — Entrega automática:**
- Email com link do material (ou PDF anexo, se curto)
- Mensagem de confirmação
- Explicação breve do que vem a seguir

**Passo 2 — Primeiro contato (D+0 a D+1):**
- Mensagem de WhatsApp ou email humanizada
- Perguntar se o material foi útil
- Oferecer ajuda sem pressão

**Passo 3 — Nutrição (D+3 a D+30):**
- Sequência de 3-7 emails/mensagens
- Conteúdo complementar
- Cases anonimizados
- CTA suave para consulta (só no meio/fim da sequência)

**Passo 4 — Classificação:**
- **Lead frio:** não responde, deixa seguindo nutrição
- **Lead morno:** interage mas não agenda, oferecer conversa rápida
- **Lead quente:** pergunta sobre consulta, agendar

### Bloco 4 — Mensagem de boas-vindas (template)

**Email/WhatsApp imediato:**

> Oi, [Nome]! Obrigada por baixar [nome do material].
>
> Aqui está o link: [link]
>
> Esse [checklist/e-book/guia] foi pensado para responder as dúvidas mais comuns sobre [tema]. Se depois de ler você tiver uma pergunta específica sobre sua situação, é só responder essa mensagem que te ajudo a entender os próximos passos.
>
> Abraço,
> [Nome do advogado]
> OAB/[UF] [nº]

**Regra:** mensagem assinada por pessoa, não "equipe". Humanizar aumenta resposta.

### Bloco 5 — Qualificação do lead

Ao responder interação do lead, identifique:

| Pergunta | O que revela |
|---|---|
| "Há quanto tempo está com esse problema?" | Urgência |
| "Já procurou outro escritório?" | Estágio de decisão |
| "Tem documentos organizados?" | Preparo |
| "Qual sua expectativa?" | Alinhamento |

**Leads para priorizar:**
- Urgência alta + problema bem definido
- Documentos organizados
- Expectativas realistas

**Leads para educar mais:**
- Sem urgência
- Problema vago
- Expectativa irrealista (promessa de ganho rápido/alto)

### Bloco 6 — LGPD obrigatório

Checklist legal:
- [ ] Aceite explícito (checkbox não pré-marcado)
- [ ] Política de privacidade linkada e clara
- [ ] Finalidade do uso do dado declarada
- [ ] Direito de revogação do consentimento
- [ ] Dados armazenados com segurança
- [ ] Encarregado de dados definido (ou advogado responsável)
- [ ] Opção de unsubscribe em todo email

**Texto modelo de aceite:**

> ☐ Autorizo o uso dos meus dados para receber comunicações do escritório sobre [tema]. Posso revogar a qualquer momento. Leia a [Política de Privacidade].

## Gerando o entregável

Use `references/template-plano-captura-lead.md`. Estruture:
- Isca escolhida + justificativa
- Formulário de captura
- Fluxo de 7-14 dias pós-cadastro
- Templates de mensagens
- Critérios de qualificação
- Checklist LGPD

## Integração com skills downstream

Plano de captura alimenta:
- `landing-pages` (LP da isca)
- `nutricao-whatsapp-email` (detalha as mensagens)
- `criar-copy` (escreve as mensagens de nutrição)
- `criar-criativos` (design da isca em PDF)

## Armadilha comum

**Isca genérica que não qualifica.** "Guia sobre direitos trabalhistas" atrai todo mundo e ninguém. Melhor: "Checklist para quem vai ser demitido essa semana" — público restrito, lead quente. Isca específica = lead de qualidade.
