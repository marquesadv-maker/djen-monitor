---
name: mapear-personas
description: Constrói personas detalhadas do cliente ideal do escritório de advocacia, indo além de demografia para mapear dor, gatilho de busca, jornada emocional, objeções e vocabulário real do cliente. Use SEMPRE que o advogado mencionar: "criar persona", "mapear persona", "definir público", "quem é meu cliente ideal", "perfil de cliente", "ICP", "customer persona", "não sei quem atender", "meu conteúdo não converte", "não conheço meu cliente", "mapear dor do cliente", "entender o cliente", "jornada do cliente jurídico", "avatar do cliente", "segmentar público". Também acione quando outra skill do marketing-juridico precisar de persona definida (criar-copy, roteiros-video, ads, landing page) e o arquivo personas.md não existir. Essencial antes de criar conteúdo ou anúncio.
---

# Mapear Personas do Cliente Jurídico

Esta skill constrói personas do cliente ideal do escritório, focadas em **como o cliente pensa, busca e decide** — não em demografia genérica.

## Por que isso importa

Persona jurídica mal feita = "homem ou mulher, 30-60 anos, classe B/C". Isso não serve pra nada. O conteúdo que sai desse perfil é genérico, o anúncio não converte, a copy não conecta.

Persona bem feita = entender **o momento exato** em que o cliente começa a procurar um advogado, **que palavras ele usa** no Google, **que medo o paralisa**, **que objeção ele tem** antes de contratar. Isso transforma marketing jurídico.

## Pré-requisito

Antes de começar, leia:
- `produto-nicho.md` (gerado pela skill `definir-produto-nicho`) — **obrigatório**. Sem nicho definido, a persona fica genérica.
- `manual-marca.md` (se existir) — entende o tom que será usado com essa persona.
- `perfil-escritorio.md` (se existir, do Dr. Cláudio) — contexto do escritório.

Se `produto-nicho.md` não existir, **pare e recomende** rodar a skill `definir-produto-nicho` antes. Persona sem nicho-foco é trabalho perdido.

## Workflow

Crie **1 persona primária** (o cliente ideal do nicho primário) + opcionalmente **1 persona secundária** (do nicho secundário). Não mais que isso. Persona demais = foco de menos.

Para cada persona, conduza a entrevista com o advogado em **6 blocos**.

### Bloco 1 — Quem é (rápido)

Apenas o básico para contexto:
- Nome fictício + idade aproximada
- Gênero (se relevante para o nicho)
- Classe social / faixa de renda estimada
- Cidade / região
- Situação profissional (CLT, autônomo, aposentado, empresário...)

**Não gaste tempo aqui.** Dois minutos. O valor da persona está nos próximos blocos.

### Bloco 2 — Gatilho de busca

Pergunta-chave: "**O que acontece na vida dessa pessoa que a faz procurar um advogado?**"

Exemplos:
- Previdenciário: "recebeu carta de indeferimento do INSS", "acabou de completar 60 anos", "parou de conseguir trabalhar e não sabe se tem direito"
- Trabalhista: "foi demitido hoje", "descobriu que trabalhou 2 anos sem carteira"
- Família: "decidiu se separar e não sabe por onde começar", "o pai faleceu e deixou imóvel sem inventário"

Esse gatilho é o **evento** que dispara a busca. É aqui que mora o ouro da persona.

### Bloco 3 — Como busca

Pergunta: "**O que essa pessoa digita no Google?**"

Liste 5-10 buscas reais, nas palavras do cliente (não do advogado):
- "advogado perto de mim pra aposentadoria"
- "como saber se tenho direito ao bpc"
- "fui mandado embora sem justa causa, e agora"
- "quanto custa um divórcio"
- "posso dar entrada no inss sozinho"

**Regra de ouro:** se a busca parece "linguagem de advogado" (ex: "concessão de benefício previdenciário"), não é persona — é formalismo. Reescreva nas palavras do leigo.

### Bloco 4 — Jornada emocional

Pergunta: "**Como essa pessoa se sente quando procura o escritório?**"

Mapeie 3 estados:
- **Sentimento dominante** (medo, raiva, insegurança, vergonha, esperança, pressa...)
- **O que ela tem medo de descobrir** (que não tem direito, que vai pagar caro, que vai ser enganada)
- **O que ela espera sentir depois da conversa** (alívio, clareza, segurança, controle)

Esse bloco define o **tom** do conteúdo e da copy. Pessoa com medo precisa de conteúdo acolhedor. Pessoa com raiva precisa de conteúdo que valide. Pessoa com pressa precisa de direto ao ponto.

### Bloco 5 — Objeções antes de contratar

Pergunta: "**O que essa pessoa pensa antes de contratar, que pode travar a decisão?**"

Objeções típicas (mapeie as 3-5 mais fortes):
- "Vai custar caro"
- "Vai demorar anos"
- "O advogado vai me abandonar depois que assinar"
- "Posso resolver sozinho pelo site do INSS"
- "Já tentei antes e não deu certo"
- "Não confio em advogado"
- "Vão me pedir documentos que eu não tenho"

Objeção mapeada = objeção respondida antes de aparecer, no conteúdo e no atendimento.

### Bloco 6 — Vocabulário real

Liste **10-15 palavras ou expressões** que **essa persona usa** (e que o advogado **não deve usar** se quiser parecer leigo) vs. termos técnicos:

| Persona fala | Advogado fala |
|---|---|
| "entrar com o inss" | "requerer benefício previdenciário" |
| "o juiz negou" | "sentença desfavorável" |
| "pensão alimentícia do meu filho" | "verba alimentar" |
| "pegar a herança" | "abrir inventário" |

Esse bloco alimenta TODO o conteúdo futuro — o advogado vai escrever usando a coluna esquerda, não a direita. É isso que faz o Google encontrar o conteúdo do escritório e não do concorrente.

## Gerando o entregável

Use `references/template-persona.md`. Gere `personas.md` com 1-2 personas, cada uma completa nos 6 blocos.

## Validação cruzada

Antes de fechar a persona, cruze com o advogado:
- "Essa persona bate com os 10 últimos clientes que você fechou?"
- "Se você lembrar do último caso, essa persona descreve ele?"

Se a resposta for "mais ou menos", ajuste. Persona é hipótese de trabalho — refine com dado real do escritório.

## Armadilhas comuns

1. **Persona desejada ≠ persona real.** O advogado quer atender empresários, mas os últimos 20 clientes foram aposentadas. A persona é aposentada, não empresário.
2. **Generalização.** "Pessoa com problemas jurídicos" não é persona. Tem que doer.
3. **Demasiadas personas.** 4+ personas = ninguém é prioridade = marketing espalhado.
4. **Pular o bloco de vocabulário.** Sem vocabulário real, conteúdo vira juridiquês. Juridiquês não vende.

## Próximos passos

Depois de `personas.md` pronto, a skill natural a rodar é `pesquisar-mercado` (entender concorrência e oportunidades) ou já ir direto pra `editorial-linha` (construir linha editorial usando vocabulário da persona).
