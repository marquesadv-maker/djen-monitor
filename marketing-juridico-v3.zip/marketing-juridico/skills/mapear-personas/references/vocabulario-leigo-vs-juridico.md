# Vocabulário Leigo vs. Jurídico

Tabela de referência para o Bloco 6 da entrevista de persona. A regra é simples: **conteúdo e copy usam coluna leigo. Petição e parecer usam coluna jurídica.**

O Google prioriza conteúdo que usa as palavras que as pessoas digitam. As pessoas digitam coluna leigo.

---

## Previdenciário

| Leigo (cliente digita) | Jurídico (advogado escreve) |
|---|---|
| dar entrada no inss | requerer benefício previdenciário |
| aposentadoria por idade | aposentadoria por idade urbana/rural |
| benefício de prestação continuada / bpc | LOAS / BPC-LOAS |
| auxílio-doença | benefício por incapacidade temporária |
| aposentadoria por invalidez | aposentadoria por incapacidade permanente |
| pensão por morte | pensão por morte |
| recurso do inss | recurso administrativo CRPS |
| processo pra ganhar mais na aposentadoria | revisão de benefício |
| ganhar o atrasado | verba retroativa |
| perícia médica do inss | perícia médica federal |
| dar entrada sozinho | requerimento administrativo |

---

## Trabalhista

| Leigo | Jurídico |
|---|---|
| fui mandado embora | rescisão contratual |
| fui mandado embora sem motivo | rescisão sem justa causa |
| o patrão não pagou | inadimplemento de verbas rescisórias |
| assinar a carteira | registro em CTPS |
| trabalhei sem carteira | vínculo empregatício sem registro |
| horas extras que não pagaram | horas extras inadimplidas |
| assédio no trabalho | assédio moral |
| fgts | FGTS |
| multa de 40% | multa rescisória |
| seguro-desemprego | seguro-desemprego |
| justa causa indevida | rescisão por justa causa aplicada indevidamente |

---

## Família

| Leigo | Jurídico |
|---|---|
| divórcio / me separar | dissolução do vínculo matrimonial |
| divórcio na amizade | divórcio consensual |
| divórcio brigado | divórcio litigioso |
| pensão do filho | pensão alimentícia |
| quem fica com a guarda | definição de guarda |
| guarda compartilhada | guarda compartilhada |
| pegar a herança | inventário e partilha |
| regularizar união | reconhecimento de união estável |
| mudar o nome no casamento | averbação de nome |
| alimentar o filho que não reconheço | ação de investigação de paternidade |

---

## Consumidor

| Leigo | Jurídico |
|---|---|
| me negativaram sem dever | inscrição indevida nos órgãos de proteção ao crédito |
| dano moral | danos morais |
| indenização | reparação civil |
| voo atrasou / cancelou | atraso/cancelamento de voo |
| bagagem sumiu | extravio de bagagem |
| plano negou | negativa de cobertura |
| produto com defeito | vício do produto |
| comprou e não entregaram | inadimplemento de compra e venda |
| empresa não devolveu o dinheiro | devolução em dobro |

---

## Família / Inventário

| Leigo | Jurídico |
|---|---|
| morreu e deixou imóvel | de cujus deixou bem imóvel a inventariar |
| partilha | partilha de bens |
| escritura de partilha | formal de partilha |
| testamento | disposição de última vontade |
| legítima | quota legítima dos herdeiros necessários |
| deserdar | exclusão da herança |

---

## Bancário

| Leigo | Jurídico |
|---|---|
| juros abusivos | taxa de juros acima da média de mercado |
| dívida com banco | inadimplemento contratual bancário |
| emprestimo sem pedir | contrato de mútuo sem anuência |
| empréstimo no contracheque | empréstimo consignado |
| tarifa que não sabia | cobrança de tarifa bancária |
| renegociar dívida | repactuação |

---

## Imobiliário

| Leigo | Jurídico |
|---|---|
| distrato de imóvel na planta | rescisão contratual de compra e venda na planta |
| construtora não entregou | descumprimento de prazo de entrega |
| regularizar imóvel | regularização imobiliária |
| usucapião | usucapião (OK, termo já entrou no leigo) |
| inquilino não paga | ação de despejo por falta de pagamento |
| vizinho barulhento | nuisance / dano em condomínio |

---

## Como usar no Bloco 6

1. Pegue o nicho primário da persona.
2. Mostre a tabela correspondente ao advogado.
3. Peça pra ele marcar quais expressões os **clientes dele** usam (nem tudo é universal — variação regional importa).
4. Adicione expressões específicas do escritório que não estão na tabela.
5. Salve as 10-15 expressões mais usadas no `personas.md`.

**Validação final:** digite 3 das expressões da persona no Google. Aparece resultado jurídico? Aparece gente com a mesma dúvida? Se sim, o vocabulário tá calibrado.
