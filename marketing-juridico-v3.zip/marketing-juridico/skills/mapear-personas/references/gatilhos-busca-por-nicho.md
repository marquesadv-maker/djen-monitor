# Gatilhos de Busca por Nicho Jurídico

Catálogo de **eventos** que fazem o cliente começar a procurar um advogado. Use para calibrar o Bloco 2 da entrevista de persona.

Cada nicho tem gatilhos típicos. Se o advogado não souber responder o gatilho, consulte esta lista para sugerir hipóteses.

---

## Previdenciário

**Gatilhos emocionais (alta urgência):**
- Recebeu carta de indeferimento do INSS
- Foi afastado do trabalho e não sabe se consegue auxílio
- Perdeu o emprego aos 55-60 e está sem saber se tem direito a algo
- Descobriu que o benefício que recebe "parece pouco"

**Gatilhos temporais (média urgência):**
- Acabou de fazer 60/62/65 anos
- Está chegando em 15/20/30 anos de contribuição
- Vai aposentar o cônjuge e quer entender o próprio caso

**Gatilhos informacionais (baixa urgência):**
- Um conhecido ganhou revisão e ela quer saber se também tem
- Viu reportagem sobre BPC-LOAS e se reconheceu

---

## Trabalhista (empregado)

**Gatilhos emocionais (muito alta urgência):**
- Foi demitido hoje / essa semana
- Foi demitido por justa causa e discorda
- Sofreu acidente de trabalho
- Está passando por assédio moral no trabalho

**Gatilhos temporais:**
- Tá pedindo demissão e quer entender os direitos
- Empresa vai fechar e ele quer garantir os direitos

**Gatilhos informacionais:**
- Descobriu que um colega ganhou ação e quer saber se tem o mesmo direito
- Foi motorista de app por anos e ouviu falar que dá pra processar a plataforma

---

## Família

**Gatilhos emocionais (alta urgência, alta carga):**
- Decidiu se separar
- O cônjuge saiu de casa ou pediu separação
- Está em briga por guarda de filho
- O ex-cônjuge não paga pensão
- Morreu um familiar e existe disputa de herança

**Gatilhos de planejamento (baixa urgência):**
- Vai casar e quer fazer pacto antenupcial
- Quer planejar sucessão em vida
- Quer regularizar união estável longa

---

## Consumidor

**Gatilhos pontuais (muito alta urgência, evento único):**
- Negativação indevida / nome no SPC sem dívida real
- Voo atrasado ou cancelado, bagagem extraviada
- Plano de saúde negou cobertura
- Comprou produto com defeito e empresa não resolve
- Telefone / internet com cobrança errada

---

## Criminal

**Gatilhos emocionais (muito alta urgência):**
- Foi preso / alguém da família foi preso
- Foi intimado a depor na polícia
- Bateu o carro e vai responder por crime de trânsito
- Foi indiciado em algum processo

---

## Bancário

**Gatilhos emocionais (alta urgência):**
- Tá endividado e o banco não renegocia
- Teve cartão clonado e banco cobra valores
- Empréstimo consignado sem autorização apareceu no contracheque
- Nome negativado por dívida que ele não reconhece

---

## Imobiliário

**Gatilhos emocionais (média urgência):**
- Comprou imóvel na planta e construtora atrasou / não entregou
- Vai dar distrato e a construtora não devolve tudo
- Inquilino parou de pagar aluguel
- Está com problema de herança envolvendo imóvel

**Gatilhos temporais (baixa urgência):**
- Mora num imóvel há 15+ anos sem escritura e quer regularizar (usucapião)

---

## Tributário (B2B — decisor empresarial)

**Gatilhos racionais (baixa urgência, alto valor):**
- Contador sugeriu revisar tributação
- Recebeu autuação fiscal
- Viu decisão do STF sobre exclusão ICMS e quer saber se se aplica
- Vai vender a empresa e quer planejamento tributário

---

## Saúde (paciente)

**Gatilhos emocionais (muito alta urgência):**
- Plano negou cobertura de exame, cirurgia ou medicamento
- Hospital fez cobrança indevida
- SUS não forneceu medicamento
- Sofreu erro médico em procedimento

---

## Como usar este catálogo

1. Mostre ao advogado a lista do nicho dele.
2. Pergunte: "Qual desses mais parece com o cliente que chega no seu escritório?"
3. Refine o gatilho com detalhe regional/temporal específico.
4. Se nenhum da lista bater, escute a resposta do advogado — esse é o gatilho real dele.

**Lembrete:** quanto mais específico e emocional o gatilho, melhor o marketing vai converter. Gatilho genérico = conteúdo genérico.
