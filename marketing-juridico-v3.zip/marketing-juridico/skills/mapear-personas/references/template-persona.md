# Personas do Escritório — [Nome do Escritório]

> Documento gerado pela skill `mapear-personas`.
> Data: [data]
> Baseado em: `produto-nicho.md` + entrevista com advogado.

---

## Persona 1 — Primária

### Identificação rápida
- **Nome fictício:** [nome]
- **Idade:** [faixa]
- **Gênero:** [se relevante]
- **Classe social / renda:** [faixa]
- **Cidade/região:** [local]
- **Situação profissional:** [CLT / autônomo / aposentado / empresário / etc.]
- **Nicho atendido:** [primário]

### Gatilho de busca (o evento)

O que acontece na vida dessa pessoa que a faz procurar um advogado:

[Descreva o evento específico em 2-3 frases, na 3ª pessoa.]

### Como ela busca — buscas reais no Google

Termos que ela digita (na linguagem dela):

1. [busca]
2. [busca]
3. [busca]
4. [busca]
5. [busca]

### Jornada emocional

- **Sentimento dominante ao procurar:** [medo / raiva / insegurança / vergonha / esperança / pressa]
- **O que ela tem medo de descobrir:** [medos específicos]
- **O que ela espera sentir depois de conversar com o advogado:** [alívio / clareza / segurança / controle]

### Objeções principais (antes de fechar)

1. **[Objeção 1]** — resposta do escritório: [como o escritório responde]
2. **[Objeção 2]** — resposta: [como responde]
3. **[Objeção 3]** — resposta: [como responde]

### Vocabulário real

| Como a persona fala | Como o advogado fala (evitar) |
|---|---|
| [expressão] | [termo técnico] |
| [expressão] | [termo técnico] |
| [expressão] | [termo técnico] |
| [expressão] | [termo técnico] |
| [expressão] | [termo técnico] |

### Onde encontrar essa persona

- **Canais digitais onde está presente:** [Instagram / Facebook / YouTube / WhatsApp / TikTok / Google]
- **Horários de atividade:** [manhã / noite / fim de semana]
- **Influenciadores ou conteúdos que ela consome:** [tipo de conteúdo]

---

## Persona 2 — Secundária (opcional)

[Repetir todos os blocos acima, mais enxuto. Só criar se o escritório tiver nicho secundário relevante em volume.]

---

## Checagem de realidade

- [ ] Essa persona bate com os 10 últimos clientes fechados pelo escritório?
- [ ] O vocabulário foi revisado com quem atende o cliente (recepção/secretária)?
- [ ] As buscas foram testadas no Google para ver se retornam resultados relevantes?

---

## Próximos passos

- [ ] Usar este documento como base para `editorial-linha` (linha editorial)
- [ ] Usar vocabulário da persona em todo `criar-copy` e `roteiros-video`
- [ ] Antecipar objeções em `cro-landing-page` e `captions-conversao`
