---
name: definir-produto-nicho
description: Define o produto-foco e o nicho estratégico do escritório de advocacia para direcionar todo o marketing. Descobre quais serviços o escritório oferece, prioriza usando matriz de volume × ticket × conversão × fit, identifica nichos primário e secundário, mapeia casos a recusar por risco ético ou operacional. Use SEMPRE que o advogado mencionar: "definir nicho", "escolher produto foco", "qual área priorizar no marketing", "carteira de serviços", "carro-chefe do escritório", "em que nicho investir", "qual especialidade focar", "preciso focar meu marketing", "matriz de produtos jurídicos", "priorizar oferta", "qual serviço divulgar", "oferta principal do escritório", "não sei em qual área apostar", "meu marketing tá espalhado demais". Também acione quando outra skill do marketing-juridico detectar que não há produto/nicho definido no perfil do escritório.
---

# Definir Produto e Nicho Estratégico

Esta skill guia o advogado a escolher **um produto-foco** e **um nicho estratégico** antes de sair criando conteúdo, anúncio ou landing page. Sem essa definição, o marketing vira colcha de retalhos: fala de tudo, converte em nada.

## Por que isso importa

Advogado que tenta vender "previdenciário + família + trabalhista + tributário" ao mesmo tempo não vende nada bem. Marketing jurídico que funciona é **vertical**: uma dor, uma promessa, uma entrega. O escritório pode atender clientes de qualquer área, mas o marketing comunica **um foco**.

O entregável dessa skill é o arquivo `produto-nicho.md`, que vai alimentar toda decisão subsequente: quem é a persona, que conteúdo produzir, que palavra-chave buscar, que oferta montar.

## Integração

Antes de começar, leia (se existirem):
- `perfil-escritorio.md` (do plugin Dr. Cláudio) — contexto geral do escritório
- `manual-marca.md` (gerado pela skill `construir-manual-marca`) — posicionamento e tom

Se ambos existirem, puxe o contexto e valide com o advogado antes de perguntar dados que você já tem. Não peça informação duas vezes.

Se **nenhum** dos dois existir, siga normalmente — essa skill funciona de forma autônoma.

## Workflow

Conduza a conversa em **4 blocos**, uma pergunta por vez. Não despeje formulário. O advogado tem tempo curto, paciência menor, e cansa fácil.

### Bloco 1 — Mapeamento da carteira atual

Objetivo: listar **todos** os serviços que o escritório já entrega hoje.

Perguntas:
1. "Quais áreas do direito você atende hoje?" — listar tudo, sem filtro
2. "Dentro de cada área, que tipo de caso você pega?" — aprofundar (ex: previdenciário pode ser aposentadoria por idade, BPC-LOAS, revisão de benefício, auxílio-doença)
3. "Tem algum serviço que você gostaria de parar de atender?" — dor oculta

Saída mental: lista de 5-15 serviços específicos.

### Bloco 2 — Avaliação por critério

Para cada serviço mapeado, avaliar em **4 critérios** (escala 1-5):

| Critério | Pergunta |
|---|---|
| **Volume/demanda** | Quanto desse tipo de caso chega no escritório hoje? |
| **Ticket** | Qual honorário médio desse serviço? |
| **Conversão** | De cada 10 pessoas que procuram sobre isso, quantas fecham? |
| **Fit/prazer** | Você gosta de trabalhar com esse tipo de caso? |

**Atalho prático:** se o advogado tem 10+ serviços, não avalie todos. Peça pra ele listar os **3 que mais dão dinheiro** e os **3 que mais dão volume**, e avalie só esses 6.

Consulte `references/matriz-priorizacao-servicos.md` para o framework completo de pontuação.

### Bloco 3 — Escolha do produto-foco e nicho

Com base na avaliação, proponha:

1. **Nicho primário (carro-chefe)** — o serviço que tem melhor combinação de volume + ticket + conversão + fit. Esse vai ser o **foco do marketing**.
2. **Nicho secundário** — segundo melhor. Aparece em conteúdos complementares, mas não é o foco.
3. **Demais serviços** — o escritório continua atendendo, mas não são tema de marketing.

Apresente sua proposta com justificativa clara ("você pontuou alto em X, Y, Z por isso sugiro esse como primário"). Deixe o advogado aceitar ou ajustar — a palavra final é dele.

Consulte `references/nichos-juridicos-brasil.md` para características de cada nicho (demanda, concorrência, ticket médio, ciclo de venda, sensibilidade ética).

### Bloco 4 — Casos a recusar

Pergunta direta: "Tem algum tipo de caso que você **não quer mais atender**, mesmo que apareça?"

Razões comuns:
- Risco ético (cliente pede coisa limítrofe)
- Baixo ticket que consome tempo
- Desgaste emocional (ex: alguns casos de criminal ou família)
- Fora da especialidade

Liste esses casos no entregável como "casos a recusar". O marketing **não atrai** esse tipo de cliente — filtra na origem.

Consulte `references/sensibilidade-etica-por-nicho.md` para nichos com maior risco de demanda limítrofe.

## Gerando o entregável

Ao final dos 4 blocos, gere o arquivo `produto-nicho.md` usando `references/template-produto-nicho.md`. Inclua:

- Declaração de foco ("O marketing desse escritório fala sobre **X** pra atender **quem tem Y**")
- Nicho primário com justificativa
- Nicho secundário com papel
- Lista de casos a recusar
- Links com os próximos passos (qual skill rodar depois — provavelmente `mapear-personas`)

## Quando alguém não sabe responder

Se o advogado não souber o ticket médio, a taxa de conversão ou o volume, tudo bem. Use aproximações: "mais que R$3k ou menos?", "mais que metade fecha ou menos?". Não trave a conversa esperando precisão — o exercício é **estratégico**, não contábil.

Se o advogado tiver **só uma área** (ex: só previdenciário), o trabalho é escolher o **subproduto-foco** dentro dela (ex: BPC-LOAS vs aposentadoria por idade vs revisão). Não force uma segunda área artificialmente.

## Sinalização ética

Nichos com maior sensibilidade OAB (criminal, família em casos de guarda, consumidor em ações contra bancos, previdenciário com concessão de benefício) exigem comunicação mais cuidadosa. Sinalize isso no entregável pra que skills de conteúdo e copy downstream apliquem o filtro certo.
