# Matriz de Priorização de Serviços Jurídicos

Framework para avaliar quais serviços do escritório devem virar foco de marketing.

## Os 4 critérios

### 1. Volume / Demanda (peso 25%)

Quanto desse tipo de caso chega espontaneamente hoje?

| Nota | Descrição |
|---|---|
| 5 | Todo dia tem cliente procurando |
| 4 | Várias vezes por semana |
| 3 | Algumas vezes por mês |
| 2 | Raro, mas acontece |
| 1 | Quase nunca |

**Por que importa:** volume alto = mercado aquecido = menor custo de educação do cliente. Volume baixo exige mais investimento em conteúdo pra criar consciência.

### 2. Ticket Médio (peso 30%)

Qual honorário médio desse serviço no escritório?

| Nota | Ticket |
|---|---|
| 5 | Acima de R$ 15.000 |
| 4 | R$ 8.000 – R$ 15.000 |
| 3 | R$ 3.000 – R$ 8.000 |
| 2 | R$ 1.000 – R$ 3.000 |
| 1 | Abaixo de R$ 1.000 |

**Por que importa:** CAC (custo de aquisição de cliente) precisa caber no ticket. Serviço de ticket baixo só fecha conta se o volume for muito alto e o processo for escalável.

**Ajuste para êxito:** em causas com honorários de êxito (previdenciário, consumidor, trabalhista), considere o **valor médio real recebido** por caso, não o contratual.

### 3. Conversão (peso 25%)

De cada 10 pessoas que procuram sobre esse serviço, quantas fecham contrato?

| Nota | Taxa de conversão |
|---|---|
| 5 | 7 ou mais em 10 |
| 4 | 5-6 em 10 |
| 3 | 3-4 em 10 |
| 2 | 1-2 em 10 |
| 1 | Menos de 1 em 10 |

**Por que importa:** conversão reflete o fit entre oferta e demanda. Conversão alta = serviço que o mercado quer. Conversão baixa = educação, preço ou concorrência travando.

### 4. Fit / Prazer (peso 20%)

O advogado gosta de trabalhar com esse tipo de caso?

| Nota | Descrição |
|---|---|
| 5 | Ama, faria de graça (quase) |
| 4 | Gosta muito |
| 3 | Neutro, faz porque paga |
| 2 | Chato, faz porque precisa |
| 1 | Detesta, tem que forçar |

**Por que importa:** marketing de nicho demanda **anos** de produção de conteúdo sobre o mesmo tema. Sem fit pessoal, o advogado abandona antes de colher.

---

## Cálculo da pontuação

```
Pontuação Total = (Volume × 0,25) + (Ticket × 0,30) + (Conversão × 0,25) + (Fit × 0,20)
```

**Interpretação:**
- **4,0 – 5,0** → candidato forte a nicho primário
- **3,0 – 3,9** → candidato a nicho secundário
- **2,0 – 2,9** → manter no escritório, fora do marketing
- **Abaixo de 2,0** → considerar sair desse serviço

---

## Empate técnico

Quando dois serviços empatam na pontuação, desempate por:

1. **Recorrência do cliente** — cliente que volta ou indica vale mais
2. **Ciclo de venda** — mais curto ganha (menos investimento em nutrição)
3. **Diferenciação** — onde o escritório tem autoridade única
4. **Saturação do mercado** — nicho menos saturado = mais espaço

---

## Quando NÃO aplicar a matriz

- **Escritório monotemático** (só previdenciário, só trabalhista): pule a comparação entre áreas, aplique a matriz nos **subprodutos** dentro da área.
- **Escritório novo sem histórico**: use estimativas do mercado (referências do Sebrae, CNJ, FGV) para os critérios de volume e ticket, e pontue fit normalmente.
- **Serviço emocional ou ético-sensível** (criminal grave, família com violência): mesmo com boa pontuação, pondere se o escritório quer **expor esse nicho em marketing aberto**.
