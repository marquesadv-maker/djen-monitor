# Catálogo de Nichos Jurídicos no Brasil

Referência rápida sobre características de mercado dos principais nichos de advocacia no Brasil. Use para calibrar expectativas de volume, ticket, ciclo e sensibilidade OAB.

> Dados qualitativos baseados em padrões de mercado. Ajuste à realidade regional do escritório.

---

## Previdenciário

**Demanda:** muito alta (envelhecimento populacional + lentidão do INSS)
**Ticket médio típico:** R$ 2.500 – R$ 6.000 (contratual) + êxito (10-30% do retroativo)
**Ciclo de venda:** curto a médio (1-4 semanas)
**Concorrência em marketing:** muito alta — nicho saturado
**Cliente típico:** 50+ anos, classes C/D, busca orientação básica
**Sensibilidade OAB:** média — não prometer concessão, cuidar com valor exato de retroativo
**Subnichos viáveis:** BPC-LOAS, aposentadoria rural, auxílio-doença, revisão da vida toda, aposentadoria do professor

---

## Trabalhista (empregado)

**Demanda:** alta
**Ticket médio típico:** honorário de êxito (20-30%) + contratual simbólico
**Ciclo de venda:** curto (dias)
**Concorrência em marketing:** alta
**Cliente típico:** 25-55 anos, acabou de ser demitido, urgência emocional
**Sensibilidade OAB:** média — não prometer valores, cuidar com expectativa
**Subnichos viáveis:** rescisão indevida, assédio moral, horas extras, motorista de app, terceirizado, bancário

---

## Família

**Demanda:** alta e constante
**Ticket médio típico:** R$ 3.000 – R$ 15.000 (varia muito por complexidade patrimonial)
**Ciclo de venda:** médio (2-6 semanas, decisão emocional)
**Concorrência em marketing:** alta
**Cliente típico:** 30-55 anos, momento de crise emocional
**Sensibilidade OAB:** alta — casos de guarda, violência e alienação exigem muito cuidado
**Subnichos viáveis:** divórcio consensual, divórcio litigioso, guarda, pensão alimentícia, inventário, união estável, planejamento sucessório

---

## Consumidor

**Demanda:** altíssima (pulverizada)
**Ticket médio típico:** baixo (R$ 500 – R$ 2.500 contratual) + êxito
**Ciclo de venda:** muito curto (1-3 dias)
**Concorrência em marketing:** altíssima — nicho comoditizado
**Cliente típico:** 25-60 anos, problema pontual
**Sensibilidade OAB:** média-alta — cuidar com ações contra bancos/empresas específicas por nome
**Subnichos viáveis:** dano moral aéreo, negativação indevida, plano de saúde, produto vício, superendividamento

---

## Tributário

**Demanda:** média (PJ > PF)
**Ticket médio típico:** R$ 10.000+ (consultivo mensal) / R$ 20.000+ (contencioso)
**Ciclo de venda:** longo (1-6 meses, decisão racional)
**Concorrência em marketing:** média
**Cliente típico:** empresário, CFO, contador (B2B)
**Sensibilidade OAB:** baixa-média
**Subnichos viáveis:** recuperação de crédito tributário, exclusão ICMS da base, planejamento tributário, defesa fiscal

---

## Empresarial / Societário

**Demanda:** média
**Ticket médio típico:** R$ 5.000+ (consultivo) / R$ 15.000+ (contencioso)
**Ciclo de venda:** longo
**Concorrência em marketing:** média
**Cliente típico:** empresário, sócio, investidor
**Sensibilidade OAB:** baixa
**Subnichos viáveis:** contratos, M&A, societário, recuperação judicial, startups

---

## Criminal

**Demanda:** constante
**Ticket médio típico:** R$ 5.000 – R$ 50.000+ (muito variável)
**Ciclo de venda:** muito curto (urgência) ou longo (investigação)
**Concorrência em marketing:** baixa-média (muitos advogados evitam marketing aberto)
**Cliente típico:** acusado ou família, alta carga emocional
**Sensibilidade OAB:** **muito alta** — jamais sugerir garantia de absolvição, cuidar com exposição de casos
**Subnichos viáveis:** direção perigosa, lei Maria da Penha (defesa), crimes empresariais, tráfico (muito sensível)

---

## Imobiliário

**Demanda:** média-alta
**Ticket médio típico:** R$ 3.000 – R$ 10.000
**Ciclo de venda:** médio
**Concorrência em marketing:** média
**Cliente típico:** comprador, inquilino, proprietário
**Sensibilidade OAB:** baixa-média
**Subnichos viáveis:** distrato de imóvel na planta, usucapião, regularização, despejo, condomínio

---

## Bancário

**Demanda:** alta
**Ticket médio típico:** honorário de êxito principalmente
**Ciclo de venda:** curto
**Concorrência em marketing:** alta
**Cliente típico:** superendividado, negativado
**Sensibilidade OAB:** alta — cuidar com promessas de revisão e citação de bancos por nome
**Subnichos viáveis:** revisão de juros, dívida abusiva, cláusulas abusivas, superendividamento (Lei 14.181)

---

## Saúde (Direito Médico — lado do paciente)

**Demanda:** média-alta (crescente)
**Ticket médio típico:** R$ 5.000+ + êxito
**Ciclo de venda:** curto-médio (urgência)
**Concorrência em marketing:** média
**Cliente típico:** paciente negado por plano, família
**Sensibilidade OAB:** alta — não prometer resultado, cuidar com exposição médica
**Subnichos viáveis:** negativa de cobertura, erro médico, medicamento de alto custo, cirurgia pelo SUS

---

## Startups / LGPD / Tech

**Demanda:** nicho específico, crescente
**Ticket médio típico:** R$ 5.000+ (consultivo mensal) / R$ 15.000+ (projeto)
**Ciclo de venda:** longo
**Concorrência em marketing:** baixa-média (mercado emergindo)
**Cliente típico:** fundador de startup, CTO, CLO
**Sensibilidade OAB:** baixa
**Subnichos viáveis:** contratos de SaaS, LGPD, proteção de dados, societário de startup, contratos de investimento

---

## Como escolher entre vários nichos bons

Quando dois nichos parecem equivalentes, pergunte:

1. **Onde o escritório tem autoridade real?** (cases, publicações, especialização formal)
2. **Onde o advogado tem prazer de falar todo dia pelos próximos 2 anos?**
3. **Qual nicho tem menor saturação na região?** (Google "advogado [nicho] [cidade]")
4. **Qual dor é mais urgente pro cliente?** (urgência = conversão mais rápida)
