# Produto & Nicho Estratégico — [Nome do Escritório]

> Documento gerado pela skill `definir-produto-nicho` do plugin `marketing-juridico`.
> Data: [data]
> Próxima revisão recomendada: 6 meses

---

## 1. Declaração de Foco

**O marketing deste escritório fala sobre [TEMA CENTRAL] para atender [PÚBLICO] que precisa de [RESULTADO/TRANSFORMAÇÃO].**

Exemplo:
> "O marketing deste escritório fala sobre **aposentadoria e benefícios do INSS** para atender **pessoas que trabalharam a vida inteira e não sabem que direitos têm** que precisam de **clareza e orientação segura sobre o que pedir e como**."

---

## 2. Nicho Primário (Carro-Chefe do Marketing)

**Nicho:** [nome do nicho]
**Subproduto específico:** [se aplicável]

### Por que foi escolhido

| Critério | Nota (1-5) | Observação |
|---|---|---|
| Volume/demanda | | |
| Ticket médio | | |
| Conversão | | |
| Fit/prazer | | |
| **Total** | **/20** | |

### Características do nicho

- **Ticket médio real do escritório:** R$ [valor]
- **Ciclo de venda:** [curto / médio / longo — dias/semanas]
- **Sazonalidade:** [se aplicável]
- **Concorrência local:** [baixa / média / alta]

### O que este nicho resolve para o cliente

[1-2 frases descrevendo a transformação que o cliente vive — o "antes e depois" da contratação]

---

## 3. Nicho Secundário (Apoio)

**Nicho:** [nome]
**Papel no marketing:** aparece em conteúdos complementares, posts de autoridade cruzada, mas não é tema de anúncio nem landing page dedicada.

---

## 4. Demais Serviços

O escritório continua atendendo, mas estes serviços **não são tema de marketing**:

- [serviço 1]
- [serviço 2]
- [serviço 3]

---

## 5. Casos a Recusar

O marketing **não atrai** este tipo de cliente. Filtro na origem.

| Caso | Motivo |
|---|---|
| [descrição] | [ético / baixo ticket / desgaste / fora da especialidade] |
| | |

---

## 6. Sensibilidade Ética

**Nível de atenção OAB para o nicho primário:** [baixo / médio / alto]

**Cuidados específicos para este nicho:**
- [ex: não prometer concessão de benefício]
- [ex: não usar fotos de clientes reais]
- [ex: não mencionar valores específicos de condenação]

Estes cuidados devem ser aplicados em todo conteúdo, copy e criativo gerado para este escritório.

---

## 7. Próximos Passos

- [ ] Rodar skill `mapear-personas` para detalhar o perfil de cliente ideal deste nicho
- [ ] Rodar skill `pesquisar-mercado` para entender concorrência e oportunidades
- [ ] Usar o `manual-marca.md` + este documento como base para toda criação de conteúdo
