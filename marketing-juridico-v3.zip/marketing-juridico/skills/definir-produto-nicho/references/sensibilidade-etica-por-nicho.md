# Sensibilidade Ética por Nicho — Provimento 205/2021

Guia rápido dos pontos de atenção OAB por nicho. Use para sinalizar no `produto-nicho.md` quais cuidados aplicar em conteúdo, copy e criativo.

---

## Alta sensibilidade — cuidado redobrado

### Criminal

**Riscos:**
- Prometer absolvição ou redução de pena
- Expor caso em andamento (mesmo com anonimização)
- Usar tom sensacionalista sobre crimes
- Aparecer fotografado com cliente ou em cena de crime

**Linguagem segura:**
- "Atuação estratégica em defesa criminal"
- "Análise técnica do caso"
- "Acompanhamento em todas as fases processuais"

### Família — guarda, violência, alienação

**Riscos:**
- Prometer obtenção de guarda
- Expor crianças (foto, nome, história)
- Tom persuasivo emocional sobre conflito familiar
- Usar casos reais mesmo anonimizados

**Linguagem segura:**
- "Orientação especializada em guarda de filhos"
- "Mediação familiar com foco no bem-estar da criança"
- "Análise jurídica do seu caso"

### Saúde — erro médico e negativas de plano

**Riscos:**
- Mencionar hospitais, médicos ou planos por nome em conteúdo aberto
- Prometer indenização ou obtenção de tratamento
- Usar imagens de pacientes, cirurgias, prontuários
- Tom sensacionalista sobre sofrimento

**Linguagem segura:**
- "Atuação em direito do paciente"
- "Defesa de direitos à saúde"
- "Orientação sobre cobertura contratual"

---

## Média sensibilidade — atenção padrão

### Previdenciário

**Riscos:**
- Prometer concessão do benefício
- Prometer valor exato de retroativo
- Usar fotos de idosos clientes
- Linguagem que sugira "golpe" contra o INSS

**Linguagem segura:**
- "Análise do seu direito previdenciário"
- "Cálculo técnico do melhor benefício"
- "Revisão de benefício concedido"

### Trabalhista (empregado)

**Riscos:**
- Prometer valores de indenização
- Citar empresas específicas em conteúdo
- Tom de "vou processar seu patrão"

**Linguagem segura:**
- "Defesa dos direitos do trabalhador"
- "Análise da sua rescisão"
- "Orientação após demissão"

### Consumidor

**Riscos:**
- Citar empresas e bancos por nome em anúncios
- Prometer indenização por dano moral
- Sugerir "processar todo mundo que te negativou"

**Linguagem segura:**
- "Defesa do consumidor em situações abusivas"
- "Análise de dívidas e cobranças"

### Bancário

**Riscos:**
- Citar bancos por nome
- Prometer revisão total da dívida
- Tom "pare de pagar" (limítrofe)

**Linguagem segura:**
- "Análise de contratos bancários"
- "Orientação sobre dívidas"

---

## Baixa sensibilidade — atenção geral OAB

### Tributário, Empresarial, Startups, Imobiliário

Estes nichos têm **baixa sensibilidade específica**, mas seguem as regras gerais do Provimento 205:

- Não usar superlativos ("melhor", "maior", "nº 1")
- Não garantir resultados
- Não comparar com concorrentes
- Não oferecer consulta gratuita como chamariz principal
- Não usar tom mercantilista ("promoção", "desconto")

---

## Regra universal

**Antes de publicar qualquer peça de marketing, passe pelo filtro:**

1. Estou prometendo resultado? → remover
2. Estou usando superlativo sem base técnica? → remover
3. Estou expondo cliente (mesmo anonimizado)? → pedir autorização expressa ou remover
4. Estou comparando com concorrente? → remover
5. Estou oferecendo vantagem comercial (brinde, desconto)? → remover
6. Estou usando tom mercantilista? → reescrever
7. O conteúdo é **informativo** ou **persuasivo-comercial**? → se for o segundo, rever

Todo conteúdo **informativo** passa. Todo conteúdo **persuasivo-comercial** exige revisão.

---

## Sinalização no `produto-nicho.md`

Na seção 6 do template, registre:

```markdown
**Nível de atenção OAB:** [baixo / médio / alto]
**Cuidados específicos:**
- [cuidado 1 tirado deste documento]
- [cuidado 2]
```

Essa informação será consultada por todas as skills de criação downstream (copy, roteiros, criativos, landing pages).
