---
name: criar-copy
description: Redige copy de posts, carrosséis, legendas e conteúdo escrito para redes sociais do escritório de advocacia. Aplica linha editorial, tom de voz da marca, restrições OAB (Prov. 205/2021) e estrutura de 3 ângulos (dor/autoridade/curiosidade). Use SEMPRE que o advogado mencionar: "escrever copy", "criar post", "redigir carrossel", "texto do post", "legenda para instagram", "copy de conteúdo", "escrever conteúdo", "me ajuda a escrever", "versões de texto", "variações de copy", "traduzir juridiquês", "post educativo". Gera 2-3 variações com ângulos diferentes por padrão.
---

# Criar Copy

Esta skill transforma uma pauta + briefing em **copy final** publicável, com 2-3 variações de ângulo diferente (dor, autoridade, curiosidade) para o advogado escolher.

## Por que 3 ângulos

Mesma pauta vende de formas diferentes dependendo de quem lê:
- **Ângulo dor** converte quem já sente o problema
- **Ângulo autoridade** converte quem está pesquisando quem contratar
- **Ângulo curiosidade** atrai quem nem sabia que tinha direito

Entregar 3 dá ao advogado repertório de escolha + possibilita testar qual converte melhor ao longo do tempo.

## Pré-requisitos

Leia antes:
- `manual-marca.md` — tom de voz
- `linha-editorial.md` — pilares e regras de consistência
- `personas.md` — vocabulário da persona primária
- `calendario-editorial.md` — pauta específica a ser trabalhada (pilar, formato, tipo, CTA)

Sem tom e persona definidos, a copy sai genérica.

## Workflow

### Bloco 1 — Entender o briefing do post

Confirme com o advogado (ou leia do calendário):
- **Pauta:** qual o tema específico?
- **Formato:** carrossel / reels / stories / legenda Instagram / post LinkedIn?
- **Pilar:** a qual pilar editorial pertence?
- **Tipo de funil:** autoridade / educação / conexão / conversão?
- **CTA desejado:** o que o leitor deve fazer ao final?
- **Restrições específicas:** algo que não pode ser dito?

### Bloco 2 — Extrair o core do post

Destile a pauta em:
- **1 frase de ideia central** (o que o leitor precisa aprender)
- **1 insight contraintuitivo** (o que a maioria não sabe)
- **1 ação concreta** (o que fazer depois)

Se não consegue destilar nessas 3 linhas, a pauta está crua — volte à curadoria.

### Bloco 3 — Gerar 3 variações

Para cada ângulo, escreva a copy completa respeitando o formato.

**Variação 1 — Ângulo DOR**
- Abertura: validar a dor do leitor ("Se você já...")
- Corpo: mostrar consequência de não agir
- Fecho: CTA direto ("procure orientação")

**Variação 2 — Ângulo AUTORIDADE**
- Abertura: dado, lei ou decisão específica
- Corpo: explicação técnica traduzida em linguagem leiga
- Fecho: CTA baseado em confiança ("fale com quem entende")

**Variação 3 — Ângulo CURIOSIDADE**
- Abertura: pergunta inesperada ou mito-verdade
- Corpo: revelar informação que surpreende
- Fecho: CTA suave ("salva esse post pra não esquecer")

### Bloco 4 — Aplicar filtro OAB

Checklist obrigatório antes de entregar cada variação:
- [ ] Não promete resultado
- [ ] Não garante ganho de causa
- [ ] Não compara com outro escritório
- [ ] Não expõe caso identificável
- [ ] Não usa linguagem sensacionalista
- [ ] Não capta cliente de forma mercantilizada
- [ ] Usa sempre "orientação jurídica" em vez de "conseguir o que é seu"

### Bloco 5 — Ajustar formato

**Carrossel (8-10 slides):**
- Slide 1: gancho
- Slides 2-7: desenvolvimento (1 ideia por slide)
- Slide 8-9: síntese + CTA
- Slide 10: assinatura + próximo passo

**Reels (legenda):**
- Gancho na primeira linha (antes do "... mais")
- 2-3 parágrafos de contexto
- CTA + hashtags

**Stories:**
- Texto curtíssimo
- 1 pergunta/enquete
- 1 caixinha ou CTA de arrasta

**Post Instagram (feed simples):**
- 1 frase de impacto
- 2-4 parágrafos
- CTA

**LinkedIn:**
- Abertura com 1-2 frases impactantes (antes do "ver mais")
- Parágrafos curtos, quebra visual
- Hashtag 3-5 ao final

## Gerando o entregável

Use `references/template-copy-3-angulos.md`. Entregue as 3 variações lado a lado, cada uma com:
- Ângulo (dor/autoridade/curiosidade)
- Copy pronta para publicar
- Hashtags sugeridas
- Observação de qual ângulo tende a converter melhor para esse tipo de persona

## Integração com skills downstream

O output é consumido por:
- `criar-criativos` (design aplica a copy aprovada)
- `qa-etico-oab` (checa se passou no filtro OAB)
- `qa-marca` (checa se está alinhado ao tom)

## Armadilha comum

Entregar 3 variações que são a mesma coisa com palavras diferentes. Variação boa = **estrutura, abertura e promessa realmente diferentes**. Se dá pra trocar a primeira linha entre as 3 sem quebrar, não são 3 ângulos — é 1 copy com 3 paráfrases.
