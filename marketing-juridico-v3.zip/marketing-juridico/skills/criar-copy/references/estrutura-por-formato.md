# Estrutura de Copy por Formato

Guia detalhado por tipo de peça. Use como referência ao adaptar copy.

---

## Carrossel Instagram (8-10 slides)

**Slide 1 — Gancho (capa)**
- Frase curta (máx. 8 palavras)
- Pergunta, provocação ou dado chocante
- Deve fazer o usuário parar de rolar
- Ex: "Seu INSS pagou menos do que devia?"

**Slide 2 — Contexto**
- Amplia a provocação em 1-2 frases
- Situa o leitor no problema

**Slides 3-6 — Desenvolvimento**
- 1 ideia por slide
- Progressão lógica (causa → efeito → solução)
- Uso de numeração quando couber ("1 de 4")

**Slide 7 — Virada ou insight**
- Dado que surpreende
- Revelação do que pouca gente sabe

**Slide 8 — Síntese**
- Recapitula em bullets
- "Guarda esses 3 pontos"

**Slide 9 — CTA**
- Ação clara: salvar / comentar / compartilhar / DM
- NÃO promete resultado

**Slide 10 — Assinatura**
- Quem escreveu (Dr./Dra. nome + OAB)
- Escritório + canal de contato (sem mercantilização)

---

## Reels (legenda de vídeo 30-90s)

**Primeira linha (pré "ver mais"):**
- Gancho em 60-80 caracteres
- Deve estimular o clique

**Parágrafo 1:**
- Expandir o gancho
- Trazer o contexto

**Parágrafo 2:**
- Informação principal (o "quê")

**Parágrafo 3 (opcional):**
- Como aplicar / próximo passo

**Fecho:**
- CTA + 5-10 hashtags

---

## Stories

**Regra:** texto curtíssimo. Ninguém lê parágrafo em story.

**Formato 1 — Enquete/mito:**
- 1 pergunta forte
- Enquete sim/não
- Revelar resposta no story seguinte

**Formato 2 — Dica rápida:**
- 3 slides sequenciais
- 1 dica por slide
- Último slide com CTA (arrasta / DM)

**Formato 3 — Bastidor:**
- Foto/vídeo real
- Legenda conversacional
- Humaniza sem perder profissionalismo

---

## Post de feed (imagem única)

- **Frase de impacto** na primeira linha
- **2-4 parágrafos** de desenvolvimento
- **Parágrafos curtos** (máx. 3 linhas cada)
- **CTA** no penúltimo parágrafo
- **Hashtags** no último

---

## LinkedIn (formato longo)

- **Abertura:** 1-2 frases antes do "ver mais"
- **Estrutura em bloco:**
  - Problema
  - Contexto
  - Posição / insight
  - Fecho
- **Parágrafos de 1-2 frases** (quebra visual é tudo no LinkedIn)
- **Hashtags:** 3-5 ao final
- **Evitar:** emoji em excesso, linguagem informal demais

---

## Newsletter / Email

- **Assunto:** até 60 caracteres, sem gatilho de spam
- **Pre-header:** complementa o assunto
- **Abertura:** saudação + gancho (1 parágrafo)
- **Corpo:** 200-500 palavras
- **CTA único:** 1 por email (não pedir 3 ações)
- **P.S.:** reforço do CTA ou informação extra

---

## Artigo de blog (SEO)

- **Título H1:** keyword + benefício (até 60 caracteres)
- **Meta description:** 150-160 caracteres
- **Introdução:** 2-3 parágrafos, posiciona o problema
- **H2/H3 estruturados:** cada seção responde a uma sub-pergunta
- **Extensão:** 1.200-3.000 palavras para ranqueamento
- **Internal links:** 2-5 para outros artigos do site
- **CTA no fim:** agendar consulta ou baixar material

---

## Regras transversais

- **Zero juridiquês** em Instagram/TikTok (é pro leigo)
- **Juridiquês mínimo e traduzido** em LinkedIn/artigo (pode ter público B2B)
- **Frases curtas** (máx. 20 palavras)
- **Voz ativa** ("você tem direito" > "o direito é seu")
- **Nunca** usar "garanto", "com certeza ganha", "processo certo"
