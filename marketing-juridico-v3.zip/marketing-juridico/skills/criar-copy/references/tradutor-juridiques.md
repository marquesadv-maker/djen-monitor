# Tradutor de Juridiquês → Linguagem do Cliente

Tabela de referência. Sempre que aparecer o termo técnico na copy, substitua pelo leigo (ou explique na sequência).

---

## Previdenciário

| Juridiquês | Linguagem do cliente |
|---|---|
| RGPS | aposentadoria pelo INSS |
| Segurado | quem paga INSS |
| Carência | tempo mínimo de contribuição |
| DIB | data que a aposentadoria começa |
| Revisão da vida toda | recálculo usando salários antigos |
| Tempo de contribuição | tempo que você pagou INSS |
| Fator previdenciário | cálculo que pode reduzir o valor |
| BPC-LOAS | benefício de 1 salário mínimo pra quem não pagou INSS |
| Aposentadoria por invalidez | hoje chamada "aposentadoria por incapacidade permanente" |
| Auxílio-doença | hoje chamado "benefício por incapacidade temporária" |

---

## Trabalhista

| Juridiquês | Linguagem do cliente |
|---|---|
| Verbas rescisórias | o que a empresa te deve quando você sai |
| Estabilidade | direito de não ser demitido |
| Justa causa | demissão por falta grave |
| Aviso prévio | tempo que você trabalha (ou recebe) depois de avisado |
| Dano moral | indenização por sofrimento causado |
| Horas in itinere | horas no transporte da empresa |
| Dissídio | reajuste negociado da categoria |
| FGTS | dinheiro que a empresa guarda pra você na Caixa |
| Acordo extrajudicial | combinar direto sem juiz |
| Homologação | juiz confirmar que o acordo vale |

---

## Família

| Juridiquês | Linguagem do cliente |
|---|---|
| Guarda unilateral | um dos pais fica com a criança |
| Guarda compartilhada | decisões divididas entre os dois pais |
| Regime de bens | como os bens do casal são divididos |
| Pensão alimentícia | valor que um paga pra sustentar o filho |
| Partilha | divisão dos bens no divórcio |
| Alienação parental | quando um pai manipula o filho contra o outro |
| União estável | relacionamento sério sem casamento no papel |
| Inventário | processo para dividir bens de quem morreu |
| Testamento | documento que organiza a herança |

---

## Consumidor

| Juridiquês | Linguagem do cliente |
|---|---|
| CDC | Código de Defesa do Consumidor |
| Vício oculto | defeito que só aparece depois |
| Fato do produto | dano causado pelo produto |
| Solidariedade | tanto loja quanto fábrica respondem |
| Inversão do ônus da prova | a empresa tem que provar, não você |
| Repetição do indébito | receber de volta em dobro |
| Cláusula abusiva | regra injusta no contrato |
| Negativação indevida | nome sujo sem motivo |

---

## Criminal

| Juridiquês | Linguagem do cliente |
|---|---|
| Inquérito | investigação da polícia |
| Denúncia | acusação formal do MP |
| Flagrante | preso no ato |
| Prisão preventiva | prisão durante a investigação |
| HC | pedido pra soltar |
| Progressão de regime | mudar de fechado pra semi/aberto |
| Livramento condicional | sair da cadeia com condições |
| Prescrição | tempo que o Estado tem pra processar |

---

## Regras de uso

1. **Na copy de Instagram/TikTok:** use SEMPRE a versão leiga. Nunca o termo técnico.

2. **No LinkedIn/artigo:** pode usar o termo técnico, mas **sempre traduza entre parênteses na primeira aparição**.

3. **Em carrossel didático:** ensine o termo técnico num slide próprio (vira conteúdo).

4. **Regra geral:** se sua mãe não entende, o cliente não entende. Traduza.

---

## Exemplos antes/depois

**❌ Errado:**
> "Você tem direito à revisão da vida toda do seu RGPS, considerando salários anteriores a julho de 1994 no cálculo do salário-de-benefício."

**✅ Certo:**
> "Se você se aposentou pelo INSS, pode ter direito a recalcular sua aposentadoria usando seus salários mais antigos — e receber mais todo mês."

---

**❌ Errado:**
> "Requer-se a nulidade da justa causa aplicada, tendo em vista a ausência de prova robusta da falta grave imputada ao obreiro."

**✅ Certo:**
> "A empresa demitiu por justa causa sem conseguir provar o que o funcionário teria feito de errado. Isso pode virar reversão da demissão na Justiça."
