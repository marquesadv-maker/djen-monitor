# Copy — [Título da Pauta]

> Gerado pela skill `criar-copy`.
> Formato: [carrossel / reels / stories / feed / linkedin]
> Pilar: [nome do pilar]
> Tipo: [autoridade / educação / conexão / conversão]
> CTA desejado: [...]

---

## Ideia central

[1 frase sobre o que o leitor precisa aprender]

**Insight contraintuitivo:** [o que surpreende]
**Ação concreta:** [o que fazer depois]

---

## Variação 1 — Ângulo DOR

**Recomendado para:** leitor que já está sofrendo o problema.

**Copy:**

[copy completa no formato correto]

**Hashtags:**
[hashtags-âncora + 3-5 variáveis]

---

## Variação 2 — Ângulo AUTORIDADE

**Recomendado para:** leitor pesquisando quem contratar.

**Copy:**

[copy completa no formato correto]

**Hashtags:**
[...]

---

## Variação 3 — Ângulo CURIOSIDADE

**Recomendado para:** leitor que ainda não sabia do tema.

**Copy:**

[copy completa no formato correto]

**Hashtags:**
[...]

---

## Checklist OAB aplicado

- [ ] Nenhuma promessa de resultado
- [ ] Nenhuma comparação com outro escritório
- [ ] Nenhum caso identificável
- [ ] Sem sensacionalismo
- [ ] CTA orientativo (não mercantil)

---

## Observação de uso

- **Melhor ângulo para a persona primária:** [qual dos 3 tende a converter mais]
- **Ângulo sugerido para A/B test:** [qual usar primeiro]
