# OAB + Políticas de Plataforma — Ads Jurídicos

Guia de conformidade para rodar anúncios de advocacia em Google, LinkedIn e YouTube respeitando Provimento 205/2021 e políticas das plataformas.

---

## Provimento 205/2021 CFOAB — o que proíbe

1. **Captação mercantilizada de clientela**
   - Não usar "contrate agora", "oferta", "desconto", "promoção"
2. **Promessa de resultado**
   - Não afirmar que vai ganhar, que vai receber X, que resolve
3. **Divulgação de valor de indenização conquistada**
   - Mesmo anonimizada, fere o provimento
4. **Comparação com outros escritórios**
   - "Melhor que", "mais rápido que", "único"
5. **Uso de imagens de clientes identificáveis**
6. **Divulgação de áreas não habilitadas**
7. **Uso de depoimento que exponha cliente**

---

## Linguagem SEGURA para ads jurídicos

### ✅ PODE
- "Orientação especializada em [área]"
- "Análise do seu caso"
- "Escritório com atuação em [área] desde [ano]"
- "Agende consulta"
- "Tire suas dúvidas"
- "Entenda seus direitos"

### ❌ NÃO PODE
- "Receba sua indenização"
- "Ganhe seu processo"
- "Melhor advogado de [cidade]"
- "Garantimos o resultado"
- "Consulta grátis + desconto"
- "R$ 50.000 conquistados para cliente"

---

## Google Ads — política "Legal Services"

**Requisitos de verificação:**
- Em alguns países, Google exige verificação LSA (Local Services Ads)
- No Brasil, não há LSA para advogados, mas anúncios passam por revisão adicional

**Pontos de atenção na revisão:**
- Reivindicações de sucesso devem ser comprováveis
- Nome do advogado + OAB na LP (não apenas no anúncio)
- Landing page com política de privacidade + termos
- Sem claims médicos/financeiros absolutos

**Motivos comuns de reprovação:**
- Headline com "garantido", "100%", "sempre"
- URL final quebrada ou redirecionamento
- LP sem política de privacidade
- Keywords + copy desalinhados

---

## LinkedIn Ads — política

**Mais permissivo, mas:**
- Copy excessivamente emocional é reprovado
- Clickbait ("você não vai acreditar") é reprovado
- Não promover conteúdo enganoso

**Best practices B2B jurídico:**
- Tom institucional > tom emocional
- Autoridade técnica > urgência
- Case anonimizado institucional > história pessoal

---

## YouTube Ads — política

Segue política Google Ads + política YouTube:
- Vídeo não pode ter texto com claims proibidos
- Voz/narração sujeita às mesmas restrições
- Thumbnail não pode ter promessa de resultado
- Card de CTA segue regras de copy

**Formatos recomendados para jurídico:**
- Bumper Ads (6s) — reforço de marca
- In-stream skippable (15-30s) — autoridade
- Discovery Ads — captura de busca ativa

---

## Checklist pré-subida (aplicar em toda campanha)

### Copy do anúncio
- [ ] Sem verbos de promessa (garanto, ganho, resolvo)
- [ ] Sem valores monetários de indenização
- [ ] Sem comparação com concorrentes
- [ ] Sem urgência mercantilizada
- [ ] CTA orientativo

### Criativo visual
- [ ] Sem imagem de cliente identificável
- [ ] Sem selo fake de "melhor escritório"
- [ ] Sem valor R$ estampado
- [ ] Marca do escritório aplicada

### Landing page
- [ ] Nome advogado + OAB visível
- [ ] Política de privacidade linkada
- [ ] Termos de uso linkados
- [ ] Sem promessa de resultado na LP
- [ ] Formulário com finalidade declarada (LGPD)

### Configuração técnica
- [ ] Keywords negativas: grátis, curso, emprego, vaga, salário
- [ ] Pixel/tag de conversão instalado e testado
- [ ] Conversão primária definida (lead form / agendamento)
- [ ] Geolocalização correta
- [ ] Horário de exibição ajustado (evitar madrugada se horário comercial)

---

## Quando acionar `qa-etico-oab`

**Obrigatório antes de subir qualquer campanha.** Ads é o canal mais arriscado porque exposição é alta e fiscalização OAB prioriza reclamações sobre publicidade paga.
