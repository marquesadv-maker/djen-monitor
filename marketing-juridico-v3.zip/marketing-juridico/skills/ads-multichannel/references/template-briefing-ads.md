# Briefing de Campanha — [Nome do Escritório / Nicho]

> Gerado pela skill `ads-multichannel`.
> Canais escolhidos: [Google Search / LinkedIn / YouTube]
> Orçamento total: R$ [...]/mês
> Duração inicial do teste: [14 / 21 / 30] dias

---

## 1. Objetivo da campanha

- **Objetivo primário:** [leads qualificados / agendamentos / awareness]
- **Meta numérica:** [X leads/mês ao CPL de R$ Y]
- **Serviço promovido:** [...]
- **LP de destino:** [link]

---

## 2. Canais escolhidos + justificativa

| Canal | % do orçamento | Justificativa |
|---|---|---|
| Google Search | [...]% | [...] |
| LinkedIn | [...]% | [...] |
| YouTube | [...]% | [...] |

---

## 3. Arquitetura de campanha — Google Search

### Campanha 1: [Nome]
- Orçamento diário: R$ [...]
- Localização: [cidade/estado]
- Idioma: PT-BR
- Bidding: [Manual CPC / Max Conversions]

**Grupo de anúncios 1.1: [Tema]**
- Keywords (frase):
  - "[keyword 1]"
  - "[keyword 2]"
  - "[keyword 3]"
- Keywords negativas: grátis, emprego, vaga, curso
- Anúncios (3 variações):
  - Variação A (ângulo dor)
  - Variação B (ângulo autoridade)
  - Variação C (ângulo curiosidade)

[Repetir para outros grupos]

---

## 4. Copy dos anúncios

### Google Search — Anúncio 1
**Headlines (até 30 caracteres):**
- H1: [...]
- H2: [...]
- H3: [...]
- H4: [...]
- H5: [...]

**Descrições (até 90 caracteres):**
- D1: [...]
- D2: [...]

**URL final:** [...]

[Repetir 3x por grupo de anúncios]

---

## 5. LinkedIn Ads — Estrutura

### Campanha: [Nome]
- Objetivo: [Lead Gen / Traffic / Awareness]
- Orçamento: R$ [...]/dia
- Formato: [Single Image / Video / Document]

**Segmentação:**
- Cargo: [...]
- Setor: [...]
- Tamanho empresa: [...]
- Localização: [...]

**Copy:**
- Intro: [...]
- Headline: [...]
- CTA: [...]

---

## 6. Criativos necessários

| Canal | Formato | Dimensões | Quantidade |
|---|---|---|---|
| Google Display | Retângulo | 300x250, 728x90, 160x600 | 3 |
| LinkedIn Single Image | Quadrado | 1200x1200 | 2 |
| YouTube | Vídeo 15-30s | 1920x1080 | 1 |

---

## 7. KPIs e plano de otimização

**Metas (primeiros 21 dias):**
- CPL: R$ [...]
- CTR: >[...]%
- Taxa conversão LP: >[...]%
- Leads qualificados/mês: [...]

**Cadência de revisão:**
- Dia 7: revisar Search Terms + pausar keywords caras
- Dia 14: avaliar CPL, pausar anúncios com CTR <1%
- Dia 21: decidir escalar, ajustar ou pausar

---

## 8. Checklist OAB + plataforma

- [ ] Nenhum headline/descrição promete resultado
- [ ] Nenhuma menção a valor de indenização
- [ ] Nenhuma comparação com outros escritórios
- [ ] Nenhuma urgência mercantilizada
- [ ] Nome do advogado + OAB visível na LP
- [ ] Verificação Google Ads Legal Services iniciada (se aplicável)
- [ ] LP específica (não site institucional)
- [ ] Pixel/tag de conversão instalado
- [ ] Keywords negativas configuradas

---

## 9. Integração com skills posteriores

Esta campanha requer aprovação via `qa-etico-oab` antes de subir.
Copies detalhados em `criar-copy`. Headlines em `headlines-ganchos`. Criativos em `criar-criativos`. LP em `landing-pages`.
