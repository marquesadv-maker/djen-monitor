---
name: ads-multichannel
description: Estrutura estratégia de mídia paga multi-canal para escritórios de advocacia (Google Ads, LinkedIn Ads, YouTube Ads) respeitando Provimento 205/2021. Define objetivos, públicos, criativos, orçamento, bidding e KPIs. Use SEMPRE que o advogado mencionar: "anunciar no Google", "anúncios Google Ads", "LinkedIn Ads", "YouTube Ads", "mídia paga", "campanha de ads", "anúncio pago", "investir em anúncios", "Google Meu Negócio", "search ads", "display ads", "tráfego pago fora do Meta". Não cobre Meta Ads (escopo Nave ADS) — foco em Google + LinkedIn + YouTube.
---

# Ads Multichannel (Google / LinkedIn / YouTube)

Esta skill estrutura campanhas pagas fora do Meta Ads — concentrando em **Google Search** (intenção ativa), **LinkedIn Ads** (B2B jurídico) e **YouTube Ads** (autoridade/awareness). Respeita restrições de Google Ads para categorias sensíveis + OAB.

## Por que esses canais

| Canal | Força | Quando usar |
|---|---|---|
| Google Search | Captura intenção ativa (cliente já busca solução) | Sempre que o nicho tem busca alta no Google |
| Google Display | Alcance + retargeting | Complementa search |
| LinkedIn Ads | B2B, tomadores de decisão | Tributário, empresarial, trabalhista-empregador |
| YouTube Ads | Autoridade + storytelling | Quando há bom conteúdo de vídeo |

## Pré-requisitos

Leia antes:
- `personas.md` — perfil, demografia, canal preferido
- `produto-nicho.md` — serviço a promover
- `landing-pages.md` — LP de destino
- `seo-juridico.md` — keywords já mapeadas

## Workflow

### Bloco 1 — Escolher o(s) canal(is) certo(s)

**Critério de escolha:**

- **Nicho com busca alta + decisão rápida** (trabalhista, previdenciário, consumidor) → **Google Search** primeiro
- **B2B / empresarial / tributário PJ** → **LinkedIn Ads**
- **Escritório já tem volume de conteúdo em vídeo** → **YouTube Ads** (retargeting + authority)
- **Orçamento limitado (<R$ 3k/mês)** → **Google Search only**
- **Orçamento médio (R$ 3-15k/mês)** → Google Search + Display retargeting
- **Orçamento alto (R$ 15k+/mês)** → multi-canal

### Bloco 2 — Conformidade OAB + políticas de Google/LinkedIn

**Google Ads — categoria "Serviços Jurídicos" (Legal Services):**
- Requer verificação adicional em alguns países
- Proíbe: promessa de resultado, sensacionalismo, promessas de indenização
- Reivindicações de sucesso devem ser substanciadas

**LinkedIn Ads:**
- Mais permissivo, mas segue OAB do Brasil
- Formato principal: Sponsored Content + Message Ads

**YouTube Ads:**
- Segue política Google Ads
- Cuidado extra com claims visuais em vídeo

**Regra OAB aplicada a ads:**
- [ ] Headline não promete resultado
- [ ] Descrição não usa valor de indenização conquistada
- [ ] Não compara com outros escritórios
- [ ] Não usa urgência mercantilizada ("última chance")
- [ ] CTA é orientativo
- [ ] Exibe nome do advogado + OAB (no criativo ou na LP)

### Bloco 3 — Estruturar campanha Google Search

**Arquitetura:**
```
Conta
└── Campanha (por objetivo/área)
    └── Grupos de anúncios (por tema específico)
        └── Keywords + Anúncios
```

**Exemplo (escritório previdenciário):**
- Campanha: Revisões (R$ X/dia)
  - Grupo: Revisão da vida toda
    - Keywords: 10-30 long tail
    - Anúncios: 3 variações
  - Grupo: Revisão do teto
    - [similar]
- Campanha: BPC-LOAS (R$ Y/dia)
  - Grupos temáticos

**Tipos de match:**
- **Exato [palavra]** → alta relevância, baixo volume
- **Frase "palavra"** → equilíbrio
- **Amplo modificado** → descoberta, exige monitoria pesada

**Bidding inicial:**
- Manual CPC → mais controle quando começa
- Maximizar conversões (tCPA) → depois de ter 30+ conversões/mês

### Bloco 4 — Criar anúncios Google Search

**Anatomia:**
- **Headlines (3-15):** até 30 caracteres cada
- **Descrições (2-4):** até 90 caracteres cada
- **URL final:** LP específica

**Regras headlines:**
- H1: keyword principal + benefício
- H2: credencial/autoridade
- H3: CTA suave

**Exemplo (previdenciário):**
- H1: "Revisão de Aposentadoria INSS"
- H2: "Escritório com 15 Anos de Atuação"
- H3: "Agende Consulta Online"

**Descrições:**
- D1: explicação do serviço (sem promessa)
- D2: diferencial + CTA

### Bloco 5 — Estruturar LinkedIn Ads (B2B)

**Objetivos recomendados:**
- Lead generation (formulário nativo LinkedIn)
- Website traffic (para LP)
- Brand awareness (conteúdo de autoridade)

**Segmentação:**
- Cargo (RH, Financeiro, Jurídico)
- Setor (indústria, serviços, tecnologia)
- Tamanho da empresa
- Senioridade
- Formação

**Formatos:**
- Single Image Ad
- Video Ad
- Document Ad (carrossel)
- Message Ad (1:1, mais caro)

**Criativo B2B:**
- Mais técnico, menos emocional
- Autoridade > dor
- Case institucional anonimizado > depoimento emocional

### Bloco 6 — Definir orçamento e investimento

**Regra inicial:**
- Começar com teste de R$ 30-100/dia em 1 canal
- Rodar 14-21 dias antes de tirar conclusão
- 30 conversões/mês = ponto de escalada

**Distribuição de orçamento:**
- 60% search (intenção ativa)
- 25% display/video retargeting
- 15% prospecção/awareness

### Bloco 7 — KPIs por canal

| Métrica | Google Search | LinkedIn | YouTube |
|---|---|---|---|
| CPL (custo por lead) | R$ 30-200 | R$ 80-400 | R$ 40-150 |
| CTR | >3% | >0,5% | >2% (in-stream) |
| Taxa conversão LP | >5% | >3% | >4% |
| CPA (custo por agendamento) | R$ 100-500 | R$ 200-800 | R$ 150-600 |

**Ignorar (métricas de vaidade):**
- Impressões, cliques, alcance isolados
- CTR sem contexto de conversão

## Gerando o entregável

Use `references/template-briefing-ads.md`. Estruture:
- Canais escolhidos + justificativa
- Arquitetura de campanha
- Keywords/públicos
- Copy dos anúncios (3+ variações)
- Criativos
- Orçamento e bidding
- KPIs e plano de otimização

## Integração com skills downstream

Briefing alimenta:
- `criar-copy` (copy dos anúncios)
- `headlines-ganchos` (headlines de search/display)
- `criar-criativos` (artes de display/video)
- `landing-pages` (LP destino específica para tráfego pago)
- `qa-etico-oab` (aprovação obrigatória antes de subir)

## Armadilhas comuns

1. **Rodar ads sem LP específica.** Mandar tráfego pago pro site institucional geral → queima orçamento. Toda campanha precisa de LP dedicada.

2. **Keywords amplas demais.** "Advogado" é caríssimo e genérico. "Advogado previdenciário revisão aposentadoria [cidade]" converte 10x melhor.

3. **Ignorar Search Terms Report.** Em 14 dias, revisar o que está acionando o anúncio e adicionar negativas.

4. **Comparar com Meta Ads.** Google é search (intenção), Meta é interrupção (descoberta). Métricas e lógicas são diferentes.
