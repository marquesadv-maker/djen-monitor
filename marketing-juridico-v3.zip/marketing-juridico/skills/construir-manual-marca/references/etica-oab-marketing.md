# Ética OAB Aplicada a Marketing Jurídico

Guia prático do Provimento 205/2021 do Conselho Federal da OAB, que regulamenta a publicidade da advocacia. Esta referência é consultada pela skill construir-manual-marca e por todas as outras skills do plugin marketing-juridico que produzem conteúdo.

## O que o Provimento 205/2021 permite

- Publicidade **informativa** (esclarecer, educar, orientar)
- Comunicação em redes sociais, blog, YouTube, podcast
- Uso de fotos do escritório, da equipe, de ambiente de trabalho
- Menção a áreas de atuação, artigos publicados, participações em eventos
- Conteúdo jurídico explicativo (com sobriedade)
- Agendamento de consulta (sem pressão, sem promessa)
- Divulgação de contato profissional

## O que o Provimento 205/2021 PROÍBE

### 1. Captação de clientela
- ❌ "Contrate nosso escritório"
- ❌ "Me contrate"
- ❌ "Fale já com nosso advogado especialista"
- ❌ Abordagem ativa de cliente específico com proposta

### 2. Mercantilização
- ❌ Sorteios, promoções, descontos
- ❌ Ofertas tipo "consulta por R$ 99"
- ❌ Linguagem de varejo ("aproveite", "condição especial")

### 3. Promessa de resultado
- ❌ "Garanto sua aposentadoria"
- ❌ "Você vai ganhar esse processo"
- ❌ "100% de êxito nos casos"
- ❌ "Resultado garantido"

### 4. Autopromoção excessiva / superlativos
- ❌ "O melhor advogado"
- ❌ "O maior escritório"
- ❌ "Número 1 em X"
- ❌ "Líder de mercado" (sem dado comprovado)
- ❌ "Especialista renomado" (sem comprovação objetiva)

### 5. Comparação com outros profissionais
- ❌ "Diferente dos outros escritórios"
- ❌ "Não caia em advogado amador"
- ❌ Comparativos diretos ou indiretos que depreciem colegas

### 6. Exibição de causas ganhas para autopromoção
- ❌ "Recuperamos R$ 2 milhões pro cliente X"
- ❌ "Veja o print da sentença"
- ❌ Publicar decisão favorável sem autorização e de forma autopromotiva

### 7. Uso de símbolos de forma inadequada
- ❌ Uso indevido do símbolo da OAB (marca registrada)
- ⚠️ Cuidado com balança/martelo em excesso (estereótipo, sem proibição formal)

## CTAs permitidos (soft e éticos)

✅ "Salva esse post"
✅ "Compartilha com alguém que precisa"
✅ "Comenta sua dúvida"
✅ "Manda DM com a palavra X"
✅ "Se inscreve na newsletter"
✅ "Baixa o guia gratuito"
✅ "Agende uma conversa" (quando for genuinamente informacional/sem pressão)
✅ "Acompanhe nosso conteúdo"

## Linguagem segura (positiva + informativa)

Em vez de autopromoção, posicione-se por **informação**:

- "Aqui a gente explica o que diz a lei sobre X" (em vez de "sou especialista")
- "Veja os 3 erros mais comuns no pedido de aposentadoria" (em vez de "sou o melhor")
- "Entenda seus direitos antes de decidir" (em vez de "contrate agora")

## Uso de depoimentos e cases

- ⚠️ Depoimento é permitido, mas com **cautela**:
  - Precisa ser verdadeiro e não sensacionalista
  - Cliente precisa autorizar expressamente (de preferência por escrito)
  - Não pode prometer o mesmo resultado pra outros clientes
  - Evitar exibir valores de causa
  - Focar na **experiência** do cliente com o escritório, não no "resultado garantido"

- ✅ **Formato seguro:**
  > "Fui muito bem atendida no escritório. A Dra. Marina explicou tudo com calma e paciência. Me senti acolhida no processo." — Cliente que autorizou

- ❌ **Formato proibido:**
  > "Ganhei R$ 180 mil graças ao escritório! Melhor advocacia do Brasil!"

## Matriz rápida de decisão

Antes de publicar, passe cada peça por este filtro:

1. **É informativo ou vendedor?** → Só publica se for informativo.
2. **Promete resultado?** → Não publica.
3. **Compara com outro escritório?** → Não publica.
4. **Usa superlativo sem dado?** → Reescreve.
5. **Tem CTA de contratação direta?** → Substitui por CTA soft.
6. **Expõe causa ganha pra autopromoção?** → Reescreve ou remove.
7. **Tem depoimento sem autorização?** → Remove até autorizar.

Se passar nos 7, pode publicar.

## Observação final

A OAB vem intensificando fiscalização em redes sociais. Processos éticos por publicidade irregular geram advertência, censura, suspensão ou até exclusão dos quadros. Não vale o risco.

**Princípio-guia:** publicidade da advocacia é **informativa, discreta e sóbria** — não vendedora, barulhenta ou comparativa.
