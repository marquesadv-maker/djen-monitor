# Arquétipos de Marca Aplicados ao Contexto Jurídico

Arquétipo é um "personagem-base" que define a personalidade da marca. A marca não É o arquétipo literalmente — ela se inspira nele. Escritório de advocacia costuma navegar entre 4 arquétipos principais, mas os 12 clássicos estão listados aqui pra referência.

## Os 4 mais comuns em advocacia

### 1. Sábio (The Sage)
**Essência:** Busca a verdade, ensina, referência técnica.
**Palavras-chave:** conhecimento, análise, profundidade, entendimento.
**Exemplos em advocacia:** escritórios tributários, societários, constitucionalistas.
**Tom:** professoral sem ser arrogante, preciso, cita fontes.
**Cuidado:** pode soar frio e distante.
**CTA típico:** "Entenda mais", "Aprofunde", "Saiba o que a lei diz".

### 2. Protetor / Cuidador (The Caregiver)
**Essência:** Cuida, acolhe, defende o vulnerável.
**Palavras-chave:** proteção, acolhimento, segurança, tranquilidade.
**Exemplos em advocacia:** previdenciário (idosos), família, consumidor, saúde.
**Tom:** próximo, empático, humano, reconforta.
**Cuidado:** pode soar paternalista ou infantilizador.
**CTA típico:** "Fique tranquilo", "Estamos aqui", "Proteja os seus".

### 3. Herói (The Hero)
**Essência:** Enfrenta batalhas, coragem, superação.
**Palavras-chave:** luta, conquista, coragem, justiça.
**Exemplos em advocacia:** trabalhista (empregado), consumidor contra grandes empresas, direitos humanos.
**Tom:** firme, motivador, combativo, encoraja ação.
**Cuidado:** pode soar arrogante ou beligerante demais.
**CTA típico:** "Lute pelo que é seu", "Vamos à luta", "Sua batalha também é nossa".

### 4. Aliado / Amigo (The Regular Guy + Caregiver)
**Essência:** Companheiro de jornada, próximo, sem hierarquia.
**Palavras-chave:** parceria, caminhada, acessível, de confiança.
**Exemplos em advocacia:** escritórios jovens, advocacia popular, PME, startup.
**Tom:** descontraído-profissional, informal, usa analogias do cotidiano.
**Cuidado:** pode soar pouco sério se exagerado.
**CTA típico:** "Bora conversar", "Tô aqui pra te ajudar", "Me chama no WhatsApp".

---

## Os outros 8 arquétipos (raros em advocacia mas possíveis)

### 5. Inocente (The Innocent)
**Essência:** Simplicidade, otimismo, honestidade. Raro em advocacia pela complexidade do serviço.

### 6. Explorador (The Explorer)
**Essência:** Independência, descoberta, novas fronteiras. Pode funcionar em advocacia de inovação/tech/startup.

### 7. Fora-da-Lei / Rebelde (The Outlaw)
**Essência:** Disrupção, quebra de regras. Pode funcionar em advocacia ativista/causas sociais — com cuidado OAB.

### 8. Mago (The Magician)
**Essência:** Transformação, visão, resultados extraordinários. Cuidado: pode esbarrar em "promessa de resultado" (proibido pela OAB).

### 9. Amante (The Lover)
**Essência:** Conexão, intimidade, beleza. Raro em advocacia, mais aplicável a direito da moda ou eventos.

### 10. Bobo da Corte / Alegre (The Jester)
**Essência:** Humor, descontração, prazer. Arriscado em advocacia — pode soar pouco profissional.

### 11. Criador (The Creator)
**Essência:** Inovação, criatividade, expressão. Funciona em escritórios de propriedade intelectual, entretenimento, autoral.

### 12. Governante (The Ruler)
**Essência:** Controle, prestígio, liderança, ordem. Funciona em escritórios de elite, grandes bancas, M&A.

---

## Como escolher o arquétipo certo

**Passo 1:** Pergunte ao advogado quais adjetivos descrevem o escritório.
**Passo 2:** Pergunte quais NÃO descrevem.
**Passo 3:** Cruze com as essências acima.
**Passo 4:** Valide: "Se o seu escritório fosse uma pessoa no velório de um cliente, como ele se comportaria?"
- Explicando a ciência do caso → Sábio
- Abraçando a família → Protetor
- Prometendo justiça → Herói
- Oferecendo companhia → Aliado

**Passo 5:** Permita combinação (primário + secundário). Ex: Protetor + Sábio = cuidador com autoridade técnica (ótimo pra previdenciário).
