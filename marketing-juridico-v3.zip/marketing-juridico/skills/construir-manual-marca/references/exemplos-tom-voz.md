# Exemplos de Tom de Voz — Ganchos, CTAs e Calibração

## Fórmulas de gancho (como começar um conteúdo)

### Gancho contraintuitivo
> "Seu pai cuida da sua avó acamada? Então LEIA isso. Ela pode ter direito a R$ 1.412 por mês sem nunca ter contribuído com o INSS."

### Gancho de dor
> "Todo mês você paga INSS e, quando chega a hora de se aposentar, descobre que vai receber menos do que achava. Isso tem um nome: erro de cálculo do próprio INSS."

### Gancho de autoridade
> "Em 12 anos atuando com direito previdenciário, vi o mesmo erro se repetir em 8 a cada 10 pedidos de aposentadoria. Deixa eu te mostrar qual."

### Gancho de curiosidade
> "Existe um benefício do INSS que paga R$ 1.412 por mês, e quase ninguém sabe que tem direito. Nem médicos do posto de saúde costumam saber explicar."

### Gancho de história
> "Seu Raimundo, 72 anos, chegou no escritório chorando. A filha dele tinha dito que 'não adiantava'. Dois meses depois, ele recebeu o primeiro depósito."

### Gancho de dado
> "73% das aposentadorias no Brasil são concedidas com valor menor do que o devido por lei. Você sabe como conferir a sua?"

---

## Fórmulas de CTA ético (respeita OAB)

### Soft CTA (topo de funil)
- "Salva esse post pra não esquecer."
- "Manda pra alguém que precisa saber."
- "Compartilha com sua mãe, com sua avó."
- "Se fez sentido, comenta aqui embaixo."

### Medium CTA (meio de funil)
- "Comenta 'QUERO SABER' que eu te explico mais em vídeo."
- "Tem dúvida específica? Me manda DM que eu respondo."
- "Baixa o guia completo no link da bio."
- "Se inscreve na newsletter pra receber atualizações."

### CTA proibido (NÃO USAR)
- ❌ "Contrate nosso escritório"
- ❌ "Me contrate"
- ❌ "Garanto que você vai ganhar"
- ❌ "Sou o melhor advogado da região"
- ❌ "Clique aqui e contrate"

### CTA limítrofe (usar com cautela)
- ⚠️ "Agende uma conversa" — ok se for consulta sem cobrança
- ⚠️ "Fale com a gente" — ok, não é captação direta
- ⚠️ "Consulte um advogado" — ok se for genérico (pode ser qualquer advogado)

---

## Calibração por eixo de tom

### Eixo Formal ←→ Informal

**Nível 1 (muito formal):**
> "Conforme disposto no art. 201, § 7º da Constituição Federal, o segurado faz jus ao benefício previdenciário."

**Nível 3 (equilibrado):**
> "A Constituição garante o direito à aposentadoria quando você cumpre as regras do tempo de contribuição."

**Nível 5 (muito informal):**
> "Tá no direito? Tá. A Constituição fala isso lá no artigo 201. Agora bora ver se o INSS vai cumprir."

---

### Eixo Técnico ←→ Acessível

**Nível 1 (muito técnico):**
> "O indeferimento baseou-se na ausência de qualidade de segurado por perda do período de graça, nos termos do art. 15 da Lei 8.213/91."

**Nível 5 (muito acessível):**
> "O INSS negou porque diz que você parou de contribuir por muito tempo. Mas tem jeito de provar que você continuou sendo segurado."

---

### Eixo Próximo ←→ Institucional

**Nível 1 (institucional):**
> "O escritório analisará o caso apresentado e retornará em até 48 horas úteis."

**Nível 5 (próximo):**
> "Me manda aí os documentos. Até quarta eu te falo o que dá pra fazer."

---

## Matriz de tom por canal (sugestão padrão)

| Canal | Formal | Técnico | Próximo | Observação |
|---|---|---|---|---|
| Instagram post | 3 | 3 | 4 | Equilíbrio |
| Instagram reels | 4 | 4 | 5 | Mais informal |
| LinkedIn | 2 | 2 | 3 | Mais formal |
| Blog/artigo | 2 | 2 | 3 | Profundidade técnica |
| Email newsletter | 3 | 3 | 4 | Mais pessoal |
| WhatsApp | 4 | 4 | 5 | Muito próximo |
| Site institucional | 2 | 3 | 3 | Confiabilidade |
