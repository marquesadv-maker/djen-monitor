# Sugestões Visuais por Nicho Jurídico

Quando o advogado não tiver identidade visual definida, use estas sugestões como ponto de partida. Cada nicho tem 3 direções, sempre com justificativa do por quê.

---

## Previdenciário

### Direção A — Autoridade Clássica
- **Paleta:** Azul-marinho (#0F2744) + Dourado (#C9A961) + Branco-gelo (#F8F5EF)
- **Tipografia:** Títulos em Playfair Display · Corpo em Inter
- **Sensação:** tradição, confiança, experiência
- **Quando usar:** escritório veterano, clientela acima dos 60

### Direção B — Cuidado Humano
- **Paleta:** Verde-floresta (#2C5F4C) + Creme (#F5EDE0) + Terracota (#C96F4A)
- **Tipografia:** Títulos em Merriweather · Corpo em Source Sans Pro
- **Sensação:** acolhimento, natureza, tranquilidade
- **Quando usar:** foco em BPC, idosos, famílias

### Direção C — Moderno e Próximo
- **Paleta:** Azul-petróleo (#1E5F74) + Coral (#F76F5F) + Cinza-claro (#E8E8E8)
- **Tipografia:** Títulos em Poppins · Corpo em Open Sans
- **Sensação:** contemporâneo, acessível, digital-first
- **Quando usar:** escritório jovem, público mais jovem cuidando de pais/avós

---

## Trabalhista

### Direção A — Firmeza Institucional
- **Paleta:** Azul-escuro (#1A2E4A) + Vermelho-vinho (#8B1A2B) + Branco (#FFFFFF)
- **Tipografia:** Montserrat + Lato
- **Sensação:** força, seriedade, combate
- **Quando usar:** foco em grandes causas, coletivas

### Direção B — Herói do Trabalhador
- **Paleta:** Laranja-queimado (#D35400) + Cinza-escuro (#2C3E50) + Creme (#FDF6E3)
- **Tipografia:** Oswald (títulos) + Roboto (corpo)
- **Sensação:** energia, luta, movimento
- **Quando usar:** advocacia popular, causas individuais

### Direção C — Profissional Moderno
- **Paleta:** Verde-esmeralda (#0D6E5B) + Grafite (#333333) + Off-white (#FAFAFA)
- **Tipografia:** Inter (tudo)
- **Sensação:** contemporâneo, organizado, confiável
- **Quando usar:** escritório híbrido, atende empresa e empregado

---

## Família

### Direção A — Acolhimento Delicado
- **Paleta:** Rosa-terroso (#D4A5A5) + Bege (#E8D5C4) + Verde-salva (#B5C9A8)
- **Tipografia:** Libre Baskerville (títulos) + Lora (corpo)
- **Sensação:** delicadeza, afeto, discrição
- **Quando usar:** divórcio, guarda, foco feminino

### Direção B — Cuidado Sereno
- **Paleta:** Azul-sereno (#7BA5C4) + Cinza-azulado (#ADB9C7) + Branco (#FFFFFF)
- **Tipografia:** Cormorant Garamond + Nunito
- **Sensação:** calma, equilíbrio, transição
- **Quando usar:** sucessões, planejamento sucessório, mediação

### Direção C — Contemporâneo e Humano
- **Paleta:** Verde-oliva (#8B9D5F) + Mostarda (#D4A84B) + Creme (#F5F0E8)
- **Tipografia:** Fraunces + Work Sans
- **Sensação:** moderno, humano, sem estigma
- **Quando usar:** famílias plurais, divórcio colaborativo, novos modelos

---

## Tributário / Empresarial / Societário

### Direção A — Elite Clássica
- **Paleta:** Preto (#0A0A0A) + Dourado-velho (#A68936) + Marfim (#F5F2E8)
- **Tipografia:** Didot/Bodoni + Garamond
- **Sensação:** prestígio, excelência, alto padrão
- **Quando usar:** escritório grande porte, M&A, contencioso tributário

### Direção B — Sobriedade Corporativa
- **Paleta:** Azul-corporativo (#003366) + Cinza-médio (#7A7A7A) + Branco (#FFFFFF)
- **Tipografia:** Helvetica/Inter + Georgia
- **Sensação:** confiável, institucional, global
- **Quando usar:** clientela PJ média-grande

### Direção C — Modernidade Discreta
- **Paleta:** Verde-escuro (#1C3B2E) + Bronze (#8B6F47) + Papel (#EDE7DC)
- **Tipografia:** DM Serif Display + DM Sans
- **Sensação:** moderno sem ostentação, sustentável
- **Quando usar:** escritório boutique, ESG, startups

---

## Consumidor

### Direção A — Voz do Povo
- **Paleta:** Vermelho (#E63946) + Azul-navy (#1D3557) + Bege (#F1FAEE)
- **Tipografia:** Bebas Neue + Inter
- **Sensação:** combativo, acessível, "do lado do consumidor"
- **Quando usar:** causas de massa, atendimento direto

### Direção B — Confiança Próxima
- **Paleta:** Amarelo-mostarda (#E6B800) + Cinza-escuro (#333333) + Branco (#FFFFFF)
- **Tipografia:** Rubik + Open Sans
- **Sensação:** atenção, alerta, próximo
- **Quando usar:** advocacia de nicho (bancário, aéreo, telecom)

### Direção C — Tech e Clean
- **Paleta:** Azul-elétrico (#0077B6) + Verde-menta (#90E0EF) + Branco (#FFFFFF)
- **Tipografia:** Space Grotesk + Inter
- **Sensação:** digital, moderno, resolutivo
- **Quando usar:** processos online, JEC digital, automação

---

## Regras gerais de apresentação

Quando apresentar as 3 direções ao advogado:

1. **Mostre as 3 simultaneamente.** Nunca ofereça só uma.
2. **Dê nome a cada uma.** "Autoridade Clássica", "Cuidado Humano", etc.
3. **Explique a sensação.** Não só as cores — o que ela transmite.
4. **Diga quando usar cada.** Ajuda o advogado a se ver no perfil.
5. **Deixe claro que é ponto de partida.** Designer profissional pode refinar.

## Fontes seguras (Google Fonts — gratuitas e compatíveis)

**Serifas (autoridade/tradição):**
Playfair Display, Merriweather, Libre Baskerville, Lora, Cormorant Garamond, Fraunces, DM Serif Display, Crimson Pro

**Sans-serif (moderno/acessível):**
Inter, Open Sans, Lato, Montserrat, Poppins, Roboto, Work Sans, DM Sans, Space Grotesk, Nunito

**Display (títulos marcantes — usar com parcimônia):**
Oswald, Bebas Neue, Rubik
