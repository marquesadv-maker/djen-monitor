# Manual de Marca — [Nome do Escritório]

> Documento-mãe da marca. Consultado por toda a operação de marketing.
> Última atualização: [DATA] · Versão: [v1.0]

---

## PARTE 1 — POSICIONAMENTO DE MARCA

### 1.1 Essência

**Propósito**
[Por que o escritório existe, além de ganhar dinheiro]

**Missão**
[O que fazemos no dia a dia, em uma frase]

**Visão**
[Onde queremos chegar em 5 anos]

**Valores**
1. [Valor 1 + 1 frase do que significa na prática]
2. [Valor 2 + prática]
3. [Valor 3 + prática]
4. [Valor 4 + prática]
5. [Valor 5 + prática]

### 1.2 Posicionamento Competitivo

**Promessa única:** [O que só nós entregamos]

**Público principal:** [Descrição do cliente-alvo]

**Categoria de disputa:** [Em que "campeonato" jogamos]

**Diferencial defensável:** [O que o concorrente não copia]

**Declaração de Posicionamento:**
> Para [persona] que [dor], o [escritório] é o [categoria] que [benefício único] porque [razão que sustenta].

### 1.3 Territórios de Marca

**Temas que são nossos:**
- [Tema 1]
- [Tema 2]
- [Tema 3]
- [Tema 4]

**O que não somos (anti-territórios):**
- [O que recusamos ser associados]

---

## PARTE 2 — IDENTIDADE VERBAL

### 2.1 Personalidade

**Arquétipo principal:** [Sábio / Protetor / Herói / Aliado / outro]
**Arquétipo secundário (opcional):** [arquétipo]

**5 adjetivos que nos descrevem:**
[1, 2, 3, 4, 5]

**5 adjetivos que NÃO nos descrevem:**
[1, 2, 3, 4, 5]

### 2.2 Tom de Voz

Eixos (escala 1-5):
- Formal (1) ←→ Informal (5): **[valor]**
- Sério (1) ←→ Divertido (5): **[valor]**
- Técnico (1) ←→ Acessível (5): **[valor]**
- Próximo (1) ←→ Institucional (5): **[valor]**
- Ousado (1) ←→ Conservador (5): **[valor]**

**Síntese do tom:** [frase de 1-2 linhas que resume]

### 2.3 Manual de Linguagem

**Palavras que USAMOS (vocabulário preferencial):**
[lista]

**Palavras que EVITAMOS:**
[lista — juridiquês, clichês, jargão]

**Expressões PROIBIDAS (risco OAB):**
- "O melhor escritório"
- "Garantimos resultado"
- "Contrate já"
- [outras específicas]

**Uso de gírias:** [sim/não/quais contextos]
**Uso de emojis:** [sim/não/quais contextos]

### 2.4 Padrões de Copy

**Fórmulas de gancho (como começamos):**
1. [Pergunta provocativa]
2. [Dado surpreendente]
3. [História curta]

**Fórmulas de CTA ético (como fechamos):**
1. [Salvar para depois]
2. [Comentar dúvida]
3. [Enviar DM com palavra-chave]

**Como nos apresentamos:**
- Bio Instagram: [modelo]
- Assinatura email: [modelo]

---

## PARTE 3 — IDENTIDADE VISUAL

### 3.1 Logotipo
**Versão principal:** [descrição/link]
**Versões secundárias:** [horizontal/vertical/monocromático]
**Área de proteção:** [espaço mínimo]
**Tamanho mínimo:** [px/mm]
**Usos proibidos:** [distorção, sobreposição, cor errada]

### 3.2 Paleta de Cores

**Cores primárias:**
- [Nome] · HEX: [#] · RGB: [] · Uso: []
- [Nome] · HEX: [#] · RGB: [] · Uso: []

**Cores secundárias:**
- [Nome] · HEX: [#]
- [Nome] · HEX: [#]

**Cores de apoio e neutras:**
- [listar]

### 3.3 Tipografia
**Fonte de títulos:** [nome, peso, uso]
**Fonte de corpo:** [nome, peso, uso]
**Fonte auxiliar (digital):** [nome]

**Hierarquia:**
- H1: [tamanho, peso]
- H2: [tamanho, peso]
- Body: [tamanho, peso]
- Caption: [tamanho, peso]

### 3.4 Grafismos e Elementos Visuais
[ícones, formas, padrões, texturas]

### 3.5 Fotografia e Imagem
**Estilo:** [corporativo/humano/candid]
**Tratamento:** [filtro, temperatura]
**Imagens proibidas:** [martelos, balanças genéricas, stock óbvio]

### 3.6 Templates por Canal
- **Instagram (post):** [grid, margens, logo]
- **Instagram (carrossel):** [capa/miolo/contracapa/CTA]
- **Instagram (story):** [áreas seguras]
- **Instagram (reels):** [thumbnail, legenda sobreposta]
- **LinkedIn:** [capa, post, artigo]
- **Email:** [header, footer, botões]
- **Site/LP:** [hero, seções]
- **WhatsApp Business:** [foto, status, catálogo]

---

## PARTE 4 — APLICAÇÃO E GOVERNANÇA

### 4.1 Do's and Don'ts Verbais

✅ **Exemplos on-brand:**
- [exemplo 1]
- [exemplo 2]
- [exemplo 3]

❌ **Exemplos off-brand:**
- [exemplo 1 + motivo]
- [exemplo 2 + motivo]
- [exemplo 3 + motivo]

### 4.2 Do's and Don'ts Visuais

✅ **Permitido:** [lista]
❌ **Proibido:** [lista]

### 4.3 Matriz de Decisão

| Contexto | Versão do logo | Cor predominante | Tom de voz |
|---|---|---|---|
| Post educativo | Horizontal | Primária | Acessível |
| Peça institucional | Vertical | Primária + neutra | Formal |
| Story do dia | Ícone | Secundária | Próximo |
| [outros] | | | |

### 4.4 Casos de Uso Proibidos (Ética OAB)

A marca NUNCA:
- Promete deferimento ou resultado de processo
- Compara com outros escritórios
- Usa captação direta ("contrate-nos", "me contrate")
- Usa superlativos vazios ("o melhor", "o maior", "número 1")
- Exibe valores de causa ganhos para autopromoção
- Participa de contexto que conflite com o Código de Ética da OAB

---

*Este manual é vivo. Revisão anual recomendada ou sempre que houver mudança estratégica no escritório.*
