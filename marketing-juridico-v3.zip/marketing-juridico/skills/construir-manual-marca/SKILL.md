---
name: construir-manual-marca
description: Constrói o Manual de Marca completo de escritórios de advocacia brasileiros — posicionamento, identidade verbal (tom de voz, vocabulário, arquétipo), identidade visual (logotipo, paleta, tipografia, templates por canal) e governança de marca (do's and don'ts, matriz de decisão). Conduz entrevista guiada, sugere opções quando o advogado não souber responder, valida compliance OAB e gera artefato manual-marca.md que é consultado por todas as outras skills do plugin marketing-juridico.
---

# Skill: construir-manual-marca

Esta skill conduz o advogado brasileiro pela construção completa do Manual de Marca do escritório — o documento-mãe que padroniza posicionamento, voz, visual e governança. O manual gerado é o artefato central consultado por todas as outras skills do plugin `marketing-juridico`: sem ele, o marketing do escritório fica genérico.

O público desta skill é advogado brasileiro — nem sempre familiarizado com jargões de marketing/design. A entrevista deve ser didática, usar linguagem informal-profissional em português BR, evitar anglicismos desnecessários e explicar termos quando necessário.

## Por que esta skill existe

Escritório de advocacia sem manual de marca produz conteúdo inconsistente: às vezes formal, às vezes descontraído; paleta muda a cada post; promessas que a OAB proíbe aparecem sem querer. O manual resolve isso uma vez só — e depois todas as outras skills (copy, roteiro, revisão, QA de marca) consultam esse documento.

Este manual também respeita a ética da OAB (Provimento 205/2021 e Código de Ética): nada de promessa de resultado, captação direta, comparação com outros escritórios ou autopromoção exagerada.

## Fluxo de trabalho

### Etapa 0 · Verificar integrações

Antes de começar, verifique se o escritório já configurou o Dr. Cláudio. Procure por:

- `perfil-escritorio.md` na pasta do projeto do usuário
- Qualquer arquivo em `~/.claude/` ou diretório do projeto que tenha dados do escritório (nicho, nome, região, produtos jurídicos)

**Se o perfil do Dr. Cláudio existir:**
- Leia esses dados e aproveite: nome, nicho, região, produtos, estilo de escrita
- Confirme com o advogado: "Identifiquei seu perfil do Dr. Cláudio. Vamos aproveitar: [resumo]. Podemos seguir assim?"
- Pule as perguntas cujas respostas você já tem

**Se não existir:** siga o fluxo completo a partir da Etapa 1.

### Etapa 1 · Apresentação e calibração (2 min)

Explique ao advogado, de forma direta:

- O que vamos construir: um Manual de Marca completo em 4 partes (Posicionamento, Verbal, Visual, Governança)
- Quanto tempo leva: aproximadamente 20-30 minutos de entrevista
- O que ele precisa ter à mão: logotipo atual (se houver), alguns posts/conteúdos antigos pra referência, uma ideia de valores do escritório
- Que você vai sugerir opções quando ele não souber responder

Pergunte antes de começar:
- "Você já tem identidade visual definida (logo, paleta, fontes) ou vamos criar do zero?"
- "Prefere fazer tudo agora de uma vez ou em blocos separados?"

### Etapa 2 · Bloco 1 · Posicionamento de Marca (~8 min)

Conduza estas perguntas, uma por vez, esperando resposta antes da próxima:

**Essência:**
1. "Por que seu escritório existe, além de ganhar dinheiro? Qual causa ou transformação move você?" → Propósito
2. "Se fosse descrever o que vocês fazem no dia a dia em uma frase, qual seria?" → Missão
3. "Onde você quer que seu escritório esteja em 5 anos?" → Visão
4. "Me dá 3 a 5 valores que são inegociáveis no seu escritório — princípios que você não abriria mão nem por cliente bom." → Valores

**Posicionamento competitivo:**
5. "O que só o seu escritório entrega, que nenhum concorrente entrega igual?" → Promessa única
6. "Quem é o cliente ideal? Descreva como se fosse pra um amigo." → Público principal
7. "Com quem vocês competem de verdade? Grandes escritórios, solos, híbridos?" → Categoria de disputa
8. "Qual o diferencial que um concorrente não consegue copiar facilmente?" → Diferencial defensável

**Territórios de marca:**
9. "Quais 3 a 5 temas são claramente 'seus'? Assuntos que quando alguém pensa, pensa em você?" → Territórios
10. "Tem algum tema ou associação que vocês recusam? Coisas que não querem ser lembrados?" → Anti-territórios

**Ao final do Bloco 1**, monte a **Declaração de Posicionamento** usando a fórmula:

> "Para [persona] que [dor], o [escritório] é o [categoria] que [benefício único] porque [razão que sustenta]."

Apresente a declaração e pergunte se faz sentido. Itere se necessário.

### Etapa 3 · Bloco 2 · Identidade Verbal (~7 min)

**Personalidade (arquétipo):**

Apresente os 4 arquétipos mais comuns em advocacia, com descrição curta:

- **Sábio** (expertise profunda, ensina, referência técnica)
- **Protetor** (cuida, acolhe, defende o vulnerável)
- **Herói** (enfrenta batalhas, peito aberto, coragem)
- **Aliado** (companheiro de jornada, próximo, acessível)

Pergunte qual combina mais com o escritório e por quê. Se o advogado não decidir, peça que escolha 3-5 adjetivos que descrevem o escritório e 3-5 que definitivamente NÃO descrevem — você deduzirá o arquétipo.

Veja `references/arquetipos-marca.md` para aplicar arquétipos ao contexto jurídico.

**Tom de voz (eixos):**

Apresente 5 eixos, peça que o advogado posicione o escritório de 1 a 5 em cada:

- Formal (1) ←→ Informal (5)
- Sério (1) ←→ Divertido (5)
- Técnico (1) ←→ Acessível (5)
- Próximo (1) ←→ Institucional (5)
- Ousado (1) ←→ Conservador (5)

Se o advogado hesitar, ofereça 3 perfis prontos:

- **Conservador-Sóbrio** (3/1/2/2/2) — escritórios tradicionais, societário, tributário
- **Técnico-Acessível** (3/2/4/3/3) — previdenciário, consumidor, trabalhista
- **Próximo-Humano** (4/3/5/5/3) — família, sucessões, causas sociais

**Manual de linguagem:**

Pergunte:
- "Me dá 5 palavras que você gosta de usar, que fazem parte do jeito de falar de vocês."
- "Me dá 5 palavras que você NÃO quer ver no conteúdo de vocês (juridiquês, clichês, jargão)."
- "Usa gírias? Em qual contexto?"
- "Usa emojis? Quais sim, quais não?"

**Padrões de copy:**

Sugira 2-3 fórmulas de gancho e 2-3 fórmulas de CTA ético, pergunte quais combinam. Veja `references/exemplos-tom-voz.md`.

### Etapa 4 · Bloco 3 · Identidade Visual (~8 min)

**Este bloco é onde mais advogados têm lacunas.** Siga a regra: quando o advogado não souber, sugira 3 opções com justificativa.

**Logotipo:**
- Se já tem: peça pra descrever ou colar imagem/link
- Se não tem: anote como [DEFINIR — recomendar criação com designer] e siga

**Paleta de cores:**

Pergunte: "Já tem cores definidas para o escritório?"
- Se sim: peça os HEX ou descrição das cores
- Se não: use `references/sugestoes-visuais-por-nicho.md` pra sugerir 3 paletas alinhadas ao nicho

Exemplo de apresentação: "Pro seu nicho (previdenciário), sugiro 3 direções: (A) Azul-marinho + dourado → autoridade clássica; (B) Verde-floresta + creme → tranquilidade e cuidado; (C) Azul-petróleo + coral → moderno e humano. Qual combina mais?"

**Tipografia:**

Mesma lógica. Sugira 3 combinações de fontes (título + corpo) com link do Google Fonts e justificativa de cada.

**Grafismos e elementos:**

Pergunte sobre ícones, formas, padrões. Se não tiver opinião, sugira 3 estilos (geométrico-clean / orgânico-humano / serifa-clássico).

**Fotografia:**

Defina estilo (corporativo, humano, candid, institucional) e o que evitar (martelos, balança em excesso, stock genérico).

**Templates por canal:**

Liste os canais ativos do escritório (Instagram, LinkedIn, site, email, WhatsApp Business, apresentações). Para cada, registre especificações básicas. Se o advogado não tiver, deixe como [A DESENVOLVER] e sinalize como prioridade.

### Etapa 5 · Bloco 4 · Aplicação e Governança (~4 min)

**Do's and Don'ts verbais:**
Gere 3 exemplos on-brand e 3 off-brand com base nos blocos anteriores. Mostre ao advogado e peça confirmação.

**Do's and Don'ts visuais:**
Liste usos permitidos e proibidos (cores erradas, logo distorcido, fundos conflitantes).

**Matriz de decisão contextual:**
Monte tabela simples: em qual contexto usar versão horizontal/vertical do logo, quando usar cor primária vs secundária, etc.

**Casos proibidos (crítico pra OAB):**
Registre explicitamente o que a marca NUNCA faz, derivado do Provimento 205/2021:

- Não promete deferimento ou resultado de processo
- Não compara com outros escritórios
- Não usa captação direta ("me contrate", "contrate nosso escritório")
- Não usa superlativos vazios ("o melhor", "o maior", "número 1")
- Não exibe valores de causa ganhos para autopromoção

### Etapa 6 · Geração do manual-marca.md

Com tudo coletado, gere o arquivo final seguindo o template em `references/template-manual-marca.md`. Salve na pasta do projeto do usuário (ou na raiz, se não houver).

Apresente o arquivo ao advogado com:
- Link computer:// para o arquivo
- Resumo em 5 bullets do que foi definido
- Recomendação: revisar o manual uma vez por ano ou quando houver mudança estratégica

### Etapa 7 · Validação final

Faça 3 perguntas de fechamento:
1. "Tem algo que você mudaria antes de fechar?"
2. "Sente que esse manual reflete mesmo a cara do seu escritório?"
3. "Tem alguma coisa importante sobre o escritório que ficou de fora?"

Itere se necessário. O manual é a fundação de todo o marketing — melhor investir 10 min extras agora do que reescrever depois.

## Regras de conduta durante a entrevista

- **Uma pergunta por vez.** Nunca dispare 5 perguntas juntas. Advogado perde o foco.
- **Valide respostas curtas.** Se o advogado responder "não sei", nunca pressione. Ofereça 3 opções com justificativa.
- **Traduza jargão.** Se usar termo de marketing, explique em uma frase. Ex: "Arquétipo é tipo um 'personagem-base' da sua marca — tipo o Sábio, o Herói, o Protetor."
- **Use exemplos do nicho.** Adapte exemplos ao nicho do advogado (previdenciário, família, tributário, etc.).
- **Não invente ética OAB.** Se tiver dúvida sobre um item do Provimento 205, consulte `references/etica-oab-marketing.md`.
- **Não prometa design visual automático.** A skill define direção e recomenda, mas logotipo/paleta bem construídos pedem designer profissional. Deixe claro.

## Output esperado

Um arquivo markdown `manual-marca.md` com 4 partes, gerado a partir do template, salvo na pasta do projeto do usuário, contendo:

1. Posicionamento completo (essência, competitivo, territórios, declaração)
2. Identidade verbal completa (arquétipo, tom, linguagem, padrões)
3. Identidade visual (o que existe + o que recomendar desenvolver)
4. Governança (do's/don'ts, matriz, casos proibidos)

O arquivo precisa estar pronto pra ser consultado pelas outras skills do plugin `marketing-juridico`. Ou seja: estruturado, seções claras, sem placeholders vazios sem justificativa.

## Arquivos de referência

- `references/template-manual-marca.md` — template completo do output final
- `references/arquetipos-marca.md` — 12 arquétipos aplicados ao contexto jurídico
- `references/exemplos-tom-voz.md` — fórmulas de gancho, CTAs éticos, exemplos por eixo
- `references/sugestoes-visuais-por-nicho.md` — 3 paletas + 3 tipografias por nicho jurídico
- `references/etica-oab-marketing.md` — Provimento 205/2021 aplicado a marketing

## Integrações

- **Lê** `perfil-escritorio.md` do Dr. Cláudio se existir, pra não duplicar perguntas
- **É lido por** todas as skills do plugin `marketing-juridico` que geram conteúdo (copy, roteiro, legenda, revisão, QAs)
- **Complementa** `configurar-marketing` (perfil operacional) — o manual foca na marca, o configurar foca na operação (canais, metas, região)
