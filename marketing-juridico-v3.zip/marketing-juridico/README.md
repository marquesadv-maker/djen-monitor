# Marketing Jurídico — Plugin Completo

Plugin Claude Code que opera como um departamento de marketing inteiro dentro de um escritório de advocacia brasileiro. 22 skills, 7 pilares, compliance OAB embutido.

## Os 7 Pilares

### Pilar 1 — Fundação estratégica
- `pesquisar-mercado` — análise de nicho, concorrência, oportunidade
- `construir-manual-marca` — tom de voz, identidade, vocabulário
- `mapear-personas` — cliente ideal, dor, linguagem, canal
- `definir-produto-nicho` — serviço, oferta, proposta de valor

### Pilar 2 — Planejamento editorial
- `editorial-linha` — pilares de conteúdo, formatos, funil
- `calendario-editorial` — cadência, datas sazonais, distribuição
- `curar-conteudo` — filtros de relevância para pauta

### Pilar 3 — Criação & copy
- `criar-copy` — 3 ângulos (dor/autoridade/curiosidade)
- `headlines-ganchos` — 8 fórmulas testadas
- `roteiros-video` — Reels, YouTube, Shorts
- `criar-criativos` — briefing visual OAB-safe

### Pilar 4 — SEO & distribuição
- `seo-juridico` — keywords, on-page, meta
- `distribuicao-multiplataforma` — âncora → derivativos

### Pilar 5 — Conversão & CRO
- `landing-pages` — 8 seções, formulário calibrado
- `captura-lead` — iscas digitais + LGPD
- `nutricao-whatsapp-email` — sequências 7/14/30 dias

### Pilar 6 — Mídia paga
- `ads-multichannel` — Google / LinkedIn / YouTube (não cobre Meta)

### Pilar 7 — Governança & QA
- `qa-etico-oab` — auditoria Provimento 205/2021 (bloqueante)
- `qa-marca` — consistência de voz e visual
- `qa-performance` — análise de resultado
- `gestao-crise-reputacao` — protocolo de crise
- `governanca-marketing` — papéis, rituais, fluxos

## Compliance OAB

Toda skill respeita:
- Provimento 205/2021 CFOAB
- Código de Ética e Disciplina
- Estatuto da Advocacia (Lei 8.906/94)
- LGPD

`qa-etico-oab` é **bloqueante**: nenhuma peça publica sem passar por ela.

## Integração

Complementa o plugin **Dr. Cláudio** (atuação jurídica/petições) e convive com **Nave ADS** (Meta Ads). Este plugin foca em Google/LinkedIn/YouTube + conteúdo orgânico + CRO.

## Como usar

1. Comece por `pesquisar-mercado` + `construir-manual-marca` (fundação)
2. Rode `governanca-marketing` para estruturar papéis e rituais
3. Ative as skills conforme necessidade

Cada skill tem seu próprio SKILL.md com workflow detalhado e references com templates prontos.
